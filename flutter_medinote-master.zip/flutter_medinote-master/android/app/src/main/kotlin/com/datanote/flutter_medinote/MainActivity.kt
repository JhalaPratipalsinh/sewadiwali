package com.datanote.flutter_medinote

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
