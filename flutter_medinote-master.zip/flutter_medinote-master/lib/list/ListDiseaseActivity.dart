
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_medinote/response/CommonResponse.dart';
import 'package:flutter_medinote/response/DiseaseDataListingResponse.dart';
import 'package:flutter_medinote/response/SaveDiseaseDataResponse.dart';
import 'package:flutter_medinote/utils/AppColors.dart';
import 'package:flutter_medinote/utils/CustomAlertTextDialog.dart';
import 'package:flutter_medinote/utils/VariableBag.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;

import '../utils/PreferenceManager.dart';

class ListDiseaseActivity extends StatefulWidget {
  const ListDiseaseActivity({Key? key}) : super(key: key);

  @override
  State<ListDiseaseActivity> createState() => _ListDiseaseActivityState();
}

class _ListDiseaseActivityState extends State<ListDiseaseActivity> {

  var _isLoading = true;
  var userId,searchText="",customerId="",page_index="1";
  var dataList;
  late ScaffoldMessengerState _scaffoldMessengerState;
  TextEditingController controller = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _isLoading = true;
    setPreferenceValue();
  }
  setPreferenceValue() async {
    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {
      userId = value;
      getDiseaseListing("");
    }));
  }

  Future getDiseaseListing(String searchText) async {


    Map data ={
      'customer_id' : customerId,
      'user_id' : userId,
      'search_text' : searchText,
      'page_index' : page_index,
    };
    
    await Future.wait(
      [http.post(Uri.parse(BASE_URL+"MobileApp/MediNoteDiseaseDataListing"),body: data)]
    ).then((respons) {
      var jasonData = null;

      setState((){
        _isLoading = false;
      });

      if(respons[0].statusCode == 200){
        jasonData = jsonDecode(respons[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = DiseaseDataListingResponse.fromJson(map);
        if(response1.settings.success =="1"){
          dataList = DiseaseDataListingResponse.fromJson(map);
        }else{
          setState((){
            dataList = null;
            //_scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
          });
        }
      }else{
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Something went wrong please try again later.")));
      }

    },onError: (error){
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(
          msg: error.toString(),
          textColor: Colors.white,
          backgroundColor: Colors.red,
          gravity: ToastGravity.CENTER);
    });
  }

  @override
  Widget build(BuildContext context) {
    _scaffoldMessengerState = ScaffoldMessenger.of(context);
    return Scaffold(
      backgroundColor: grey_5,
      appBar: AppBar(title: Text("Disease"),backgroundColor: PrimaryColor,),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 15.0,right: 15.0,top: 10,bottom: 10),
            child: Row(
              children: [
                Flexible(
                  child: Container(
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10),),
                    child: TextFormField(
                      decoration: InputDecoration(
                        hintStyle: TextStyle(fontSize: 17),
                        hintText: 'Search...',
                        prefixIcon: Icon(Icons.search,color: PrimaryColor,),
                        contentPadding: const EdgeInsets.symmetric(vertical: 15.0, horizontal: 10.0),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: PrimaryColor)
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: PrimaryColor)
                        ),
                      ),
                      onChanged: (value){
                        filterSearchResults(value,dataList);

                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
          Flexible(
            child: _isLoading?Center(
              child: CircularProgressIndicator(),
            ): Container(child: dataList!=null? BuildDiseaseList(context,dataList): Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image(width: 100, height: 100, image: AssetImage('images/folder.png'),color: PrimaryColor,),
                  SizedBox(
                    height:10
                  ),
                  Align(
                    alignment: Alignment.center,
                      child: Text("Data not found",style: TextStyle(color: PrimaryColor,fontSize: 20.0),)),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          openTextDialog(context,controller,"","","","","Add Disease","Disease Name","1");
        },
        backgroundColor: PrimaryColor,
        child: Icon(Icons.add),
      ),
    );
  }

  Widget BuildDiseaseList(BuildContext context, DiseaseDataListingResponse diseaseDataListingResponse) {
    var value = diseaseDataListingResponse.data;
    return Container(
      child: Column(
        children: [

          Flexible(
            child: Padding(
              padding: const EdgeInsets.only(left: 15.0,right: 15.0,top: 10,bottom: 10),
              child: ListView.builder(
                  itemCount: value == null?0:value.length,
                  itemBuilder: (context,index){
                    return InkWell(
                      onTap: (){
                        openTextDialog(context,controller,value[index].diseaseId,value[index].diseaseName,"","","Edit Disease","Disease Name","2");
                      },
                      child: Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              Container(
                                width:50,
                                height: 50,
                                child: Image.asset('images/symtoms.png'),
                              ),
                              Flexible(
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 15.0,),
                                  child: Text(value[index].diseaseName,style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: PrimaryColor),),
                                ),
                              ),

                            ],
                          ),
                        ),
                      ),
                    );
                  }),
            ),
          ),
        ],
      ),
    );
  }

  void openTextDialog(BuildContext context, TextEditingController controller, String diseaseId, String diseaseName,String editTxtField2,String editTxtField3, String dialogTitle, String txtFiel1,String isEdit ) {
    showDialog(
        context: context,
        builder: (BuildContext context) => CustomAlertTextDialog(
          dialogTitle:dialogTitle,
          doneTitle: "Done",
          cancelTitle: "Cancel",
          onDelete: onDeleteClick,
          position: "1",
          onClick: onSelectionClick1,
          onCancel: onSelectionCancel1,
          relationController:controller,
          editId : diseaseId,
          editName : diseaseName,
          editTxtField2 : editTxtField2,
          editTxtField3 : editTxtField3,
          txtFiel1 : txtFiel1,
          txtFiel2IsVisible : false,
          txtFiel3IsVisible : false,
          isEdit : isEdit,
        ));
  }
  onSelectionClick1(
      String editId,
      String selectionName,
      String position,
      TextEditingController bloodGroupController,
      String textfield2Value,
      String txtfield3Value,
      ) {

    //bloodGroupController.text = selectionName;

   //print(selectedId);
    print("disease :"+selectionName);
    print("textField2Value :"+textfield2Value);

   // Navigator.pop(context);

    SaveDiseaseData(selectionName,editId);
  }

  onSelectionCancel1(String p1) {
  }

  onDeleteClick(String diseaseId) {
    //Navigator.pop(context);
    alertDeleteDiseaseDialog(diseaseId);
  }

  Future SaveDiseaseData(String selectionName, String editId) async{

    setState((){
      _isLoading = true;
    });

    Map data = {
      'customer_id' : customerId,
      'user_id' : userId,
      'dis_Id' : editId,
      'dis_name' : selectionName
    };

    await Future.wait(
      [http.post(Uri.parse(BASE_URL+'MobileApp/SaveMediNoteDiseaseData'),body: data)]
    ).then((response){

      var jasonData = null;
      setState((){
        _isLoading = false;
      });

      if(response[0].statusCode==200){

        jasonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = SaveDiseaseDataResponse.fromJson(map);

        if(response1.settings.success=="1"){
          setState((){
            _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message,style: TextStyle(fontSize: 14),)));
            getDiseaseListing("");
          });
        }
      }else{
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Something went wrong please try again later.")));
      }


    },onError: (error){
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(
          msg: error.toString(),
          textColor: Colors.white,
          backgroundColor: Colors.red,
          gravity: ToastGravity.CENTER);
    });
  }

  Future<bool> alertDeleteDiseaseDialog(String diseaseId) async{
    return await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Container(
              height: 120,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 10.0),
                    child: Text("Are you sure you want to delete this disease detail?"),
                  ),
                  SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            print('yes selected');
                            Navigator.of(context).pop();
                            DeleteDisease(diseaseId);
                          },
                          child: Text("Yes"),
                          style: ElevatedButton.styleFrom(primary: Colors.red.shade800),
                        ),
                      ),
                      SizedBox(width: 15),
                      Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              print('no selected');
                              Navigator.of(context).pop();
                            },
                            child: Text("No", style: TextStyle(color: Colors.black)),
                            style: ElevatedButton.styleFrom(
                              primary: Colors.white,
                            ),
                          ))
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }


  Future DeleteDisease(String diseaseId) async{

    Map data = {
      'customer_id' : customerId,
      'user_id' : userId,
      'dis_Id' : diseaseId
    };
    
    await Future.wait([
      http.post(Uri.parse(BASE_URL+'MobileApp/DeleteMediNoteDiseaseData'),body: data)
    ]).then((response) {

      var jsonData = null;

      setState((){
        _isLoading = true;
      });

      if(response[0].statusCode==200){
        jsonData = jsonDecode(response[0].body);
        var map =   Map<String,dynamic>.from(jsonData);
        var response1 = CommonResponse.fromJson(map);

        if(response1.settings.success=="1"){
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
          getDiseaseListing("");
        }else{
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message,
          style: TextStyle(fontFamily: "poppins_regular",fontSize: 14),)));
        }
      }else{
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text('Something went wrong please try again later.')));
      }

    },onError: (error){
      Fluttertoast.showToast(msg: error.toString(),textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.CENTER);
    });
  }

  Future filterSearchResults(String value, dataList, ) async{

    if(value.isNotEmpty){

      if(value.length>0){

        getDiseaseListing(value);
      }else{
        getDiseaseListing("");
      }
    }else{
      getDiseaseListing("");
    }
  }


}
