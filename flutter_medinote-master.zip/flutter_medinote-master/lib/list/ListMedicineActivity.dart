
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_medinote/medicine/EditMedicineActivity.dart';
import 'package:flutter_medinote/utils/AppColors.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../medicine/AddMedicineActivity.dart';
import '../response/MedicineDataResponse.dart';
import '../utils/PreferenceManager.dart';
import 'package:http/http.dart' as http;

import '../utils/VariableBag.dart';

class ListMedicineActivity extends StatefulWidget {
  const ListMedicineActivity({Key? key}) : super(key: key);

  @override
  State<ListMedicineActivity> createState() => _ListMedicineActivityState();
}

class _ListMedicineActivityState extends State<ListMedicineActivity> {

  var _isLoading = true;
  var userId,searchText="",customerId="",page_index="1";
  var dataList;
  late ScaffoldMessengerState _scaffoldMessengerState;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _isLoading = true;
    setPreferenceValue();
  }
  setPreferenceValue() async {
    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {
      userId = value;
      getMedicineList("");
    }));
  }

  Future getMedicineList(String searchtext) async{

    Map map ={
      'customer_id' : customerId,
      'user_id' : userId,
      'search_text' : searchtext,
      'page_index' : page_index,
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/MediNoteMedicineDataListing"),body: map)
    ]).then((response) {

      var jasonData  = null;

      setState((){
        _isLoading = false;
      });

      if(response[0].statusCode==200){

        jasonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = MedicineDataResponse.fromJson(map);

        if(response1.settings.success=="1"){

          dataList = MedicineDataResponse.fromJson(map);

        }else{
          setState((){
            dataList = null;
          });
        }
      }else{
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Something went wrong please try again later.")));
      }

    },onError: (error){
      setState((){
        _isLoading = false;
        Fluttertoast.showToast(msg: error.toString(),textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.CENTER);
      });
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Medicines"),backgroundColor: PrimaryColor,),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 15.0,right: 15.0,top: 10,bottom: 10),
            child: Row(
              children: [
                Flexible(
                  child: Container(
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10),),
                    child: TextFormField(
                      decoration: InputDecoration(
                        hintStyle: TextStyle(fontSize: 17),
                        hintText: 'Search...',
                        prefixIcon: Icon(Icons.search,color: PrimaryColor,),
                        contentPadding: const EdgeInsets.symmetric(vertical: 15.0, horizontal: 10.0),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: PrimaryColor)
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: PrimaryColor)
                        ),
                      ),
                      onChanged: (value){
                        filterSearchResults(value,dataList);

                      },
                    ),
                  ),
                ),

              ],
            ),
          ),
          Flexible(
            child: Center(

              child: _isLoading?Container(
                child: CircularProgressIndicator(),
              ):dataList!=null ? BuildMedicineList(context,dataList) : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image(
                      width: 100,
                      height: 100,
                      image: AssetImage("images/folder.png"),color: PrimaryColor),
                  SizedBox(
                    height: 10,
                  ),
                  Align(alignment: Alignment.center,
                      child: Text("Data not found",style: TextStyle(color: PrimaryColor,fontFamily: "poppins_regular",fontSize: 20.0),))
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async{

          final reLoadPage  =await Navigator.push(context, MaterialPageRoute(builder: (context) => AddMedicineActivity(),));

          if(reLoadPage){
            setState((){
              getMedicineList("");
            });

          }

        },
        backgroundColor: PrimaryColor,
        child: Icon(Icons.add),
      ),
    );
  }

  Widget BuildMedicineList(BuildContext context, MedicineDataResponse medicineDataResponse ) {
    var value = medicineDataResponse.data;
    return Container(
      child: ListView.builder(
        itemCount: value!=null && value.length>0 ? value.length : 0,
        itemBuilder: (context,index){
          return Padding(
            padding: const EdgeInsets.only(left: 15.0,right: 15.0,top: 10,bottom: 0),
            child: InkWell(
              onTap: () async {
                final reLoadPage = await Navigator.of(context).push(MaterialPageRoute(builder: (context)=>EditMedicineActivity(value[index].medicineId)));
                //Navigator.of(context).push(MaterialPageRoute(builder: (context)=>DemoClass()));

                if (reLoadPage) {
                  setState(() {
                    getMedicineList("");
                  });
                }

              },
              child: Card(
                elevation: 4,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Align(
                        alignment: Alignment.topLeft,
                        child: Container(
                          width: 30,
                          height: 30,
                          child:  _medicineImg(value[index].medicineType),
                        ),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 10.0),
                              child: Text(value[index].medicineName,style: TextStyle(fontSize: 18,color: grey_60,fontWeight: FontWeight.bold),),
                            ),

                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },),
    );
  }

  Widget _medicineImg(medicineType) {
    if (medicineType == "Capsule") {
      return Image.asset('images/ic_capsule__off.png',color: PrimaryColor,);
    } else if(medicineType == "Tablet") {
      return Image.asset('images/ic_tablet_onn.png',color: PrimaryColor,);;
    }else if(medicineType == "ML (Syrup)") {
      return Image.asset('images/ic_syrup_off.png',color: PrimaryColor,);
    } else {
      return Image.asset('images/ic_other_medicine_off.png',color: PrimaryColor,);
    }
  }

  Future filterSearchResults(String value, dataList, ) async{

    if(value.isNotEmpty){

      if(value.length>0){

        getMedicineList(value);
      }else{
        getMedicineList("");
      }
    }else{
      getMedicineList("");
    }
  }

}
