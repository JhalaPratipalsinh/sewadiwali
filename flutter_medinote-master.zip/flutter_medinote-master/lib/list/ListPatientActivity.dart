import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_medinote/patient/AddPatientActivity.dart';
import 'package:flutter_medinote/patient/DemoClass.dart';
import 'package:flutter_medinote/patient/EditPatientActivity.dart';
import 'package:flutter_medinote/response/PatientDataListingResponse.dart';
import 'package:flutter_medinote/utils/AppColors.dart';
import 'package:flutter_medinote/utils/VariableBag.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;

import '../utils/PreferenceManager.dart';


class ListPatientActivity extends StatefulWidget {
  const ListPatientActivity({Key? key}) : super(key: key);

  @override
  State<ListPatientActivity> createState() => _ListPatientActivityState();
}

class _ListPatientActivityState extends State<ListPatientActivity> {

  var _isLoading = true;
  var userId,searchText="",customerId="",page_index="1";
  var dataList;
  late ScaffoldMessengerState _scaffoldMessengerState;




  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _isLoading = true;
    setPreferenceValue();
  }

  setPreferenceValue() async {
    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {
      userId = value;
      getPatientValue("");
    }));
  }


  Future getPatientValue(String value)  async {

    Map data= {
      'customer_id' : customerId,
      'user_id' : userId,
      'search_text' : value,
      'page_index' : page_index,
    };


    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/MediNotePatientDataListing"),body: data)
    ]).then((response){

      var jasonData = null;

      setState((){
        _isLoading = false;
      });
      if(response[0].statusCode == 200) {

        jasonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = PatientDataListingResponse.fromJson(map);

        if(response1.settings.success =="1"){
          dataList = PatientDataListingResponse.fromJson(map);
        }else{
          setState((){
            dataList = null;
            //_scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
          });
        }
      } else {
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Something went wrong please try again later.")));
      }

    }, onError: (error) {
        setState(() {
          _isLoading = false;
        });
        Fluttertoast.showToast(
            msg: error.toString(),
            textColor: Colors.white,
            backgroundColor: Colors.red,
            gravity: ToastGravity.CENTER);
    });

  }

  @override
  Widget build(BuildContext context) {
    _scaffoldMessengerState = ScaffoldMessenger.of(context);

    return Scaffold(
      backgroundColor: grey_5,
      appBar: AppBar(title: Text("Patient"),backgroundColor:PrimaryColor,),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 15.0,right: 15.0,top: 10,bottom: 10),
            child: Row(
              children: [
                Flexible(
                  child: Container(
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10),),
                    child: TextFormField(
                      decoration: const InputDecoration(
                        hintStyle: TextStyle(fontSize: 17),
                        hintText: 'Search...',
                        prefixIcon: Icon(Icons.search,color: PrimaryColor,),
                        contentPadding: EdgeInsets.symmetric(vertical: 15.0, horizontal: 10.0),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: PrimaryColor)
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: PrimaryColor)
                        ),
                      ),
                      onChanged: (value){
                        filterSearchResults(value,dataList);

                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
          Flexible(
            child: _isLoading?const Center(child: CircularProgressIndicator(),
            ): dataList!=null ? BuildPatientList(context,dataList):Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: const [
                Image(
                    width: 100,
                    height: 100,
                    image: AssetImage('images/folder.png')),
                SizedBox(
                  height: 10,
                ),
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "Data not found",
                    style: TextStyle(
                        color: Color(0xFF555555),
                        fontFamily: "poppins_regular",
                        fontSize: 20.0),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: () async {

            final reLoadPage = await Navigator.push(context, MaterialPageRoute(builder: (context) => AddPatientActivity(),));

            if (reLoadPage) {
              setState(() {
                getPatientValue("");
              });
            }
          },
      backgroundColor: PrimaryColor,
      child: Icon(Icons.add)),
    );
  }

  Widget BuildPatientList(BuildContext context, dataList ) {
    var value = dataList.data;
    return Container(
      child: Column(
        children: [

          Flexible(
            child: Padding(
                padding: const EdgeInsets.only(left: 15.0,right: 15.0,top: 10,bottom: 10),
                child: ListView.builder(
                  itemCount: value == null ? 0: value.length , itemBuilder: (context, index) {
                  return InkWell(
                    onTap: () async {
                      final reLoadPage = await Navigator.of(context).push(MaterialPageRoute(builder: (context)=>EditPatientActivity(value[index].patientId)));
                      //Navigator.of(context).push(MaterialPageRoute(builder: (context)=>DemoClass()));

                      if (reLoadPage) {
                        setState(() {
                          getPatientValue("");
                        });
                      }

                    },
                    child: Card(
                      elevation: 4,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                            Expanded(
                              flex: 1,
                              child: Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width:95,
                                  height: 95,
                                  child: value[index].gender=="Male"? Image.asset("images/male_patient.png"):Image.asset("images/female_patient.png"),
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 2,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  //name
                                Text(value[index].patientName.toString().capitalize(),style: const TextStyle(
                                  fontSize: 18,
                                  color: grey_60,
                                  fontWeight: FontWeight.bold
                                ),),
                                const Padding(
                                  padding: EdgeInsets.only(top: 8.0,bottom: 8.0),
                                  child: Divider(
                                      thickness: 1, // thickness of the line
                                      indent: 0, // empty space to the leading edge of divider.
                                      endIndent: 0, // empty space to the trailing edge of the divider.
                                      color: grey_10, // The color to use when painting the line.
                                      height: 1, // The divider's height extent.
                                    ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 0.0),
                                  child: Text(value[index].patientContactNumber,style: const TextStyle(
                                    fontSize: 16,
                                    color:grey_60
                                  ),),
                                ),
                                const Padding(
                                  padding: EdgeInsets.only(top: 8.0,bottom: 8.0),
                                  child: Divider(
                                    thickness: 1, // thickness of the line
                                    indent: 0, // empty space to the leading edge of divider.
                                    endIndent: 0, // empty space to the trailing edge of the divider.
                                    color: grey_10, // The color to use when painting the line.
                                    height: 1, // The divider's height extent.
                                  ),
                                ),
                                //emailid
                                Padding(
                                  padding: const EdgeInsets.only(top: 0.0),
                                  child: Text(value[index].patientEmailId,style: TextStyle(
                                    fontSize: 16,
                                    color: grey_60
                                  ),),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 8.0,bottom: 8.0),
                                  child: const Divider(
                                    thickness: 1, // thickness of the line
                                    indent: 0, // empty space to the leading edge of divider.
                                    endIndent: 0, // empty space to the trailing edge of the divider.
                                    color: grey_10, // The color to use when painting the line.
                                    height: 1, // The divider's height extent.
                                  ),
                                ),
                                //relation

                                IntrinsicHeight(
                                  child: Row(
                                    children: [
                                      Text(value[index].relationWithUser.toUpperCase(),style: TextStyle(
                                          fontSize: 16,
                                          color: PrimaryColor
                                      ),),
                                      VerticalDivider(
                                        color: grey_10,
                                        thickness: 1,
                                      ),

                                      Text(value[index].gender.toUpperCase(),style: TextStyle(
                                          fontSize: 16,
                                          color: PrimaryColor
                                      ),),
                                      VerticalDivider(
                                        color: grey_10,
                                        thickness: 1,
                                      ),
                                      Text(value[index].age,style: TextStyle(
                                          fontSize: 16,
                                          color: PrimaryColor),
                                      ),
                                    ],
                                  ),
                                ),

                              ],),),

                        ]),
                      ),
                    ),
                  );
                },)
            ),
          ),
        ],
      ),
    );
  }

  Future filterSearchResults(String value, dataList, ) async{

    if(value.isNotEmpty){

      if(value.length>0){

        getPatientValue(value);
      }else{
        getPatientValue("");
      }
    }else{
      getPatientValue("");
    }
  }
}
extension StringExtension on String {
  String capitalize() {
    return "${this[0].toUpperCase()}${this.substring(1).toLowerCase()}";
  }
}
