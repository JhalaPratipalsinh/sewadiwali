
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_medinote/response/LabListingResponse.dart';
import 'package:flutter_medinote/response/SaveLabResponse.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../response/CommonResponse.dart';
import '../utils/AppColors.dart';
import '../utils/CustomAlertTextDialog.dart';
import '../utils/PreferenceManager.dart';
import '../utils/VariableBag.dart';
import 'package:http/http.dart' as http;

class ListLabActivity extends StatefulWidget {
  const ListLabActivity({Key? key}) : super(key: key);

  @override
  State<ListLabActivity> createState() => _ListLabActivityState();
}

class _ListLabActivityState extends State<ListLabActivity> {
  var _isLoading = true;
  var userId,searchText="",customerId="",page_index="1";
  var dataList;
  late ScaffoldMessengerState _scaffoldMessengerState;
  TextEditingController controller = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _isLoading = true;
    setPreferenceValue();
  }
  setPreferenceValue() async {
    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {
      userId = value;
      getLabListing("");
    }));
  }

  Future getLabListing(String searchText) async {


    Map data ={
      'customer_id' : customerId,
      'User_Id' : userId,
      'search_text' : searchText,
      'page_index' : page_index,
    };

    await Future.wait(
        [http.post(Uri.parse(BASE_URL+"MobileApp/MediNoteLABListing"),body: data)]
    ).then((respons) {
      var jasonData = null;

      setState((){
        _isLoading = false;
      });

      if(respons[0].statusCode == 200){
        jasonData = jsonDecode(respons[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = LabListingResponse.fromJson(map);
        if(response1.settings.success =="1"){
          setState((){
            dataList = LabListingResponse.fromJson(map);
          });
        }else{
          setState((){
            dataList = null;
            //_scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
          });
        }
      }else{
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Something went wrong please try again later.")));
      }

    },onError: (error){
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(
          msg: error.toString(),
          textColor: Colors.white,
          backgroundColor: Colors.red,
          gravity: ToastGravity.CENTER);
    });
  }

  @override
  Widget build(BuildContext context) {
    _scaffoldMessengerState = ScaffoldMessenger.of(context);
    return Scaffold(
      backgroundColor: grey_5,
      appBar: AppBar(title: Text("Laboratory"),backgroundColor: PrimaryColor,),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 15.0,right: 15.0,top: 10,bottom: 10),
            child: Row(
              children: [
                Flexible(
                  child: Container(
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10),),
                    child: TextFormField(
                      decoration: const InputDecoration(
                        hintStyle: TextStyle(fontSize: 17),
                        hintText: 'Search...',
                        prefixIcon: Icon(Icons.search,color: PrimaryColor,),
                        contentPadding: EdgeInsets.symmetric(vertical: 15.0, horizontal: 10.0),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: PrimaryColor)
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: PrimaryColor)
                        ),
                      ),
                      onChanged: (value){
                        filterSearchResults(value,dataList);

                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
          Flexible(
            child: _isLoading?Center(
              child: CircularProgressIndicator(),
            ): Container(child: dataList!=null? BuildLabList(context,dataList): Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Image(width: 100, height: 100, image: AssetImage('images/folder.png'),color: PrimaryColor,),
                SizedBox(
                    height:10
                ),
                Align(
                    alignment: Alignment.center,
                    child: Text("Data not found",style: TextStyle(color: PrimaryColor,fontSize: 20.0),)),
              ],
            ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          openTextDialog(context,controller,"","","","","Add Laboratory","Laboratory Name","1");
        },
        backgroundColor: PrimaryColor,
        child: Icon(Icons.add),
      ),
    );
  }

  Widget BuildLabList(BuildContext context, LabListingResponse labListingResponse) {
    var value = labListingResponse.data;
    return Container(
      child: Column(
        children: [

          Flexible(
            child: Padding(
              padding: const EdgeInsets.only(left: 15.0,right: 15.0,top: 10,bottom: 10),
              child: ListView.builder(
                  itemCount: value == null?0:value.length,
                  itemBuilder: (context,index){
                    return InkWell(
                      onTap: (){
                        openTextDialog(
                            context,
                            controller,
                            value[index].laboratoryId,
                            value[index].laboratoryName,
                            value[index].laboratoryType,
                            value[index].laboratoryAddress,
                            "Edit Laboratory Detail",
                            "Laboratory Name","2");
                      },
                      child: Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              Container(
                                width:50,
                                height: 50,
                                child: Image.asset('images/symtoms.png'),
                              ),
                              Flexible(
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 15.0,),
                                  child: Text(value[index].laboratoryName,style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: PrimaryColor),),
                                ),
                              ),

                            ],
                          ),
                        ),
                      ),
                    );
                  }),
            ),
          ),
        ],
      ),
    );
  }

  void openTextDialog(BuildContext context, TextEditingController controller, String diseaseId, String diseaseName,String editTxtField2,String editTxtField3, String dialogTitle, String txtFiel1,String isEdit ) {
    showDialog(
        context: context,
        builder: (BuildContext context) => CustomAlertTextDialog(
          dialogTitle: dialogTitle,
          doneTitle: "Done",
          cancelTitle: "Cancel",
          onDelete: onDeleteClick,
          position: "1",
          onClick: onSelectionClick1,
          onCancel: onSelectionCancel1,
          relationController:controller,
          editId : diseaseId,
          editName : diseaseName,
          editTxtField2 : editTxtField2,
          editTxtField3 : editTxtField3,
          txtFiel1 : txtFiel1,
          txtFiel2IsVisible : true,
          txtFiel3IsVisible : true,
          isEdit : isEdit,

        ));
  }
  onSelectionClick1(
      String editId,
      String selectionName,
      String position,
      TextEditingController bloodGroupController,
      String textfield2Value,
      String txtfield3Value,
      ) {

    //bloodGroupController.text = selectionName;

    //print(selectedId);
    print("disease :"+selectionName);
    print("textField2Value :"+textfield2Value);

   // Navigator.pop(context);

    SaveLabData(editId,selectionName,textfield2Value,txtfield3Value);
  }

  onSelectionCancel1(String p1) {
  }

  onDeleteClick(String labId) {
    //Navigator.pop(context);
    alertDeleteLabDialog(labId);
  }

  Future SaveLabData(String editId,String selectionName, String labType, String labAddress) async{

    setState((){
      _isLoading = true;
    });

    Map data = {
      'customer_id' : customerId,
      'user_id' : userId,
      'lab_id' : editId,
      'lab_name' : selectionName,
      'lab_type' : labType,
      'lab_add' : labAddress,
    };

    await Future.wait(
        [http.post(Uri.parse(BASE_URL+'MobileApp/SaveMediNoteLabData'),body: data)]
    ).then((response){

      var jasonData = null;
      setState((){
        _isLoading = false;
      });

      if(response[0].statusCode==200){

        jasonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = SaveLabResponse.fromJson(map);

        if(response1.settings.success=="1"){
          setState((){
            _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message,style: TextStyle(fontSize: 14),)));
            getLabListing("");
          });
        }
      }else{
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Something went wrong please try again later.")));
      }


    },onError: (error){
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(
          msg: error.toString(),
          textColor: Colors.white,
          backgroundColor: Colors.red,
          gravity: ToastGravity.CENTER);
    });
  }

  Future<bool> alertDeleteLabDialog(String labId) async{
    return await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Container(
              height: 120,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 10.0),
                    child: Text("Are you sure you want to delete this laboratory detail?"),
                  ),
                  SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            print('yes selected');
                            Navigator.of(context).pop();
                            DeleteLab(labId);
                          },
                          child: Text("Yes"),
                          style: ElevatedButton.styleFrom(primary: Colors.red.shade800),
                        ),
                      ),
                      SizedBox(width: 15),
                      Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              print('no selected');
                              Navigator.of(context).pop();
                            },
                            child: Text("No", style: TextStyle(color: Colors.black)),
                            style: ElevatedButton.styleFrom(
                              primary: Colors.white,
                            ),
                          ))
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }


  Future DeleteLab(String labId) async{

    Map data = {
      'customer_id' : customerId,
      'user_id' : userId,
      'lab_id' : labId
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+'MobileApp/DeleteMediNoteLabData'),body: data)
    ]).then((response) {

      var jsonData = null;

      setState((){
        _isLoading = true;
      });

      if(response[0].statusCode==200){
        jsonData = jsonDecode(response[0].body);
        var map =   Map<String,dynamic>.from(jsonData);
        var response1 = CommonResponse.fromJson(map);

        if(response1.settings.success=="1"){
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
          getLabListing("");
        }else{
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message,
            style: TextStyle(fontFamily: "poppins_regular",fontSize: 14),)));
        }
      }else{
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text('Something went wrong please try again later.')));
      }

    },onError: (error){
      Fluttertoast.showToast(msg: error.toString(),textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.CENTER);
    });
  }

  Future filterSearchResults(String value, dataList, ) async{

    if(value.isNotEmpty){

      if(value.length>0){

        getLabListing(value);
      }else{
        getLabListing("");
      }
    }else{
      getLabListing("");
    }
  }

}
