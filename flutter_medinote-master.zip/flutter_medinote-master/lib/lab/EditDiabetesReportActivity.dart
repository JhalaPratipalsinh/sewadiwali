
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_medinote/utils/LabTypeModelCalss.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';

import '../response/CommonResponse.dart';
import '../response/LabListResponse.dart';
import '../response/PatientListingResponse.dart';
import '../utils/AppColors.dart';
import '../utils/CustomAlertSelectionDialog.dart';
import '../utils/EmployeeTypeHelper.dart';
import '../utils/GetEditTextValueHelper.dart';
import 'package:http/http.dart' as http;

import '../utils/PreferenceManager.dart';
import '../utils/VariableBag.dart';

class EditDiabetesReportActivity extends StatefulWidget {
  final String diabetesId;
  final LabTypeModelCalss listvalue;

  const EditDiabetesReportActivity(this.diabetesId, this.listvalue, {Key? key}) : super(key: key);

  @override
  State<EditDiabetesReportActivity> createState() => _EditDiabetesReportActivityState(diabetesId);
}

class _EditDiabetesReportActivityState extends State<EditDiabetesReportActivity> {
  String diabetesId;
  var currentSelectedValue = 'Select';
  var isPatientNameEditable =false,isTestDateEditable=false,isLabEditable=false,isBloodGlucoseEditable=false,isPostPrandialEditable=false,isUrineEditable=true;
  var isBloodg = true,isPostPrad = true,isUrine = true;
  var strPatient,strPatientId,strLab,strLabId;
  String today1="",todayTime1="";
  var userId,customerId="",strBloodGlucose,strPostPrandial,strUrineAcetone;
  var _isLoading = false;
  List<GetEditTextValueHelper> arrayList = <GetEditTextValueHelper>[];

  List<EmployeeTypeHelper> patientList = [];
  List<EmployeeTypeHelper> labList = [];
  TextEditingController _patientController = TextEditingController();
  TextEditingController _dateController = TextEditingController();
  TextEditingController _labController = TextEditingController();
  TextEditingController _bloodGlucoseController = TextEditingController();
  TextEditingController _postPrandialController = TextEditingController();
  var deviceTypes = [
    'Select',
    'Present',
    'Absent',
  ];

  var isEditMod = false,title="";

  var myMenuItems = <String>[
    'Edit',
    'Delete',
  ];

  _EditDiabetesReportActivityState(this.diabetesId);

  void onSelect(item) {
    switch (item) {
      case 'Edit':
        print('Edit clicked');
        setState(() {
          isEditMod = true;
          disableButton("2");

        });
        break;
      case 'Delete':
        print('Delete clicked');
        alertDeleteDiabetesDialog(context);
        break;
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {
      userId = value;
      getPatientList();
      getLabList();
      getDiabetesData();
      print("User Id = "+userId.toString());

    }));
    DateTime today = DateTime.now();

    today1 = "${today.day}/${today.month}/${today.year}";

    print("init - "+today1);


    disableButton("1");
  }

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(
        title: Text(title),backgroundColor: PrimaryColor,
        actions: [
          isEditMod ?
          Padding(
            padding: const EdgeInsets.only(right: 15.0),
            child: InkWell(
                onTap: (){
                  checkValidation();
                },
                child: Icon(Icons.check)),
          ):
          PopupMenuButton<String>(
              onSelected: onSelect,
              itemBuilder: (BuildContext context) {
                return myMenuItems.map((String choice) {
                  return PopupMenuItem<String>(
                    child: Text(choice),
                    value: choice,
                  );
                }).toList();
              })
        ],
      ),
        body: Container(
          width: width,
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Stack(
                    children: [
                      Container(
                        width: width,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 10.0),
                          child: Card(
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10), side: BorderSide(color: PrimaryColor)),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  SizedBox(height: 30,),
                                  Row(
                                    children: [
                                      Text("Patient : "),
                                      SizedBox(width: 10,),
                                      Flexible(
                                        child: TextFormField(
                                          readOnly: true,
                                          controller: _patientController,
                                          enabled: isPatientNameEditable,
                                          decoration: const InputDecoration(
                                            border: InputBorder.none,
                                            hintText: 'select patinet',
                                            contentPadding: EdgeInsets.all(0.0),
                                            isDense: true,
                                          ),
                                          validator: (value){
                                            strPatient = value;
                                            if(strPatient==null || strPatient.isEmpty){
                                              return 'Select patient.';
                                            }return null;
                                          },
                                          onTap: (){
                                            print("click");
                                            openSelectDialog(context,_patientController,patientList,"Patient");
                                          },
                                        ),
                                      ),
                                      Icon(Icons.arrow_drop_down_outlined,color: PrimaryColor,),

                                    ],
                                  ),
                                  SizedBox(height: 10,),
                                  Row(
                                    children: [
                                      const Text("Test Date : "),
                                      const SizedBox(width: 10,),
                                      Flexible(
                                        child: TextFormField(
                                          readOnly: true,
                                          controller: _dateController,
                                          enabled: isTestDateEditable,
                                          decoration: const InputDecoration(
                                              hintText: 'select date',
                                              contentPadding: EdgeInsets.all(0),
                                              isDense: true,
                                              border: InputBorder.none
                                          ),
                                          onTap: ()async{
                                            String toDate = await _showDatePicker(context);
                                            //_showDatePicker(context);
                                            print(toDate);
                                            _dateController.text = toDate;
                                          },

                                        ),
                                      ),
                                      const Icon(Icons.arrow_drop_down_outlined,color: PrimaryColor,)
                                    ],
                                  ),
                                  SizedBox(height: 10,),
                                  Row(
                                    children: [
                                      const Text("Laboratory Name : "),
                                      const SizedBox(width: 10,),
                                      Flexible(
                                        child: TextFormField(
                                          readOnly: true,
                                          controller: _labController,
                                          enabled: isLabEditable,
                                          decoration: const InputDecoration(
                                            hintText: 'select laboratory name.',
                                            contentPadding: EdgeInsets.all(0.0),
                                            isDense: true,
                                            border: InputBorder.none,
                                          ),
                                          validator: (value){
                                            strLab = value;
                                            if(strLab==null || strLab.isEmpty){
                                              return 'Select laboratory name';
                                            }return null;
                                          },
                                          onTap: (){
                                            print("click");
                                            openSelectDialog(context,_labController,labList,"Laboratory");
                                          },
                                        ),
                                      ),
                                      const Icon(Icons.arrow_drop_down_outlined,color: PrimaryColor,)
                                    ],
                                  ),
                                  Container(
                                    child: SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      child: DataTable(
                                          columnSpacing: 20,
                                          border: TableBorder.symmetric(
                                              inside: BorderSide(width: 1,color: Colors.white)
                                          ),
                                          columns: const [
                                            DataColumn(label: Text('Test Name ')),
                                            DataColumn(label: Text('Result')),
                                            DataColumn(label: Text('Unit')),
                                            DataColumn(label: Text('Range')),
                                          ],
                                          rows:  [
                                            DataRow(
                                                cells: [
                                                  DataCell(Text('Blood Glucose :')),
                                                  DataCell(
                                                    TextFormField(
                                                      keyboardType: TextInputType.number,
                                                      maxLength: 3,
                                                      controller: _bloodGlucoseController,
                                                      enabled: isBloodGlucoseEditable,
                                                      decoration: const InputDecoration(
                                                          hintText: 'enter',
                                                          border: InputBorder.none,
                                                          contentPadding: EdgeInsets.symmetric(vertical: 5,horizontal: 5),
                                                          isDense: true,
                                                          fillColor:grey_20,
                                                          filled: true,
                                                          counterText: ""
                                                      ),
                                                      onChanged: (value){
                                                        strBloodGlucose = value;
                                                        int ivalue;
                                                        if(value.toString().isNotEmpty && value.toString().length>0){
                                                          ivalue = int.parse(value.toString());

                                                          if(ivalue >=70 && ivalue <=110){
                                                            setState((){
                                                              isBloodg = true;
                                                            });
                                                          } else{
                                                            setState((){
                                                              isBloodg = false;
                                                            });
                                                          }
                                                        }else{
                                                          //ivalue = 0;
                                                          setState((){
                                                            isBloodg = true;
                                                          });
                                                        }


                                                      },
                                                      inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,9}'))],
                                                    ),
                                                  ),
                                                  DataCell(Text('mg/d')),
                                                  DataCell(
                                                      Container(
                                                          decoration: BoxDecoration(
                                                              border: Border.all(color: PrimaryColor),
                                                              borderRadius: BorderRadius.circular(5),
                                                              color: isBloodg ?  Colors.white : Colors.red
                                                          ),
                                                          child: Padding(
                                                            padding: const EdgeInsets.all(8.0),
                                                            child: Text('70-110',style: TextStyle(color: isBloodg? Colors.black:Colors.white),),
                                                          ))),
                                                ]),

                                            DataRow(
                                                cells: [
                                                  DataCell(Text('Post Prandial \nB.G. After 1hr:')),
                                                  DataCell(
                                                    TextFormField(
                                                      keyboardType: TextInputType.number,
                                                      maxLength: 3,
                                                      controller: _postPrandialController,
                                                      enabled: isPostPrandialEditable,
                                                      decoration: const InputDecoration(
                                                          hintText: 'enter',
                                                          border: InputBorder.none,
                                                          contentPadding: EdgeInsets.symmetric(vertical: 5,horizontal: 5),
                                                          isDense: true,
                                                          fillColor:grey_20,
                                                          filled: true,
                                                          counterText: ""
                                                      ),
                                                      onChanged: (value){
                                                        strPostPrandial = value;
                                                        int ivalue;
                                                        if(value.toString().isNotEmpty && value.toString().length>0){
                                                          ivalue = int.parse(value.toString());

                                                          if(ivalue >=70 && ivalue <=110){
                                                            setState((){
                                                              isPostPrad = true;
                                                            });
                                                          } else{
                                                            setState((){
                                                              isPostPrad = false;
                                                            });
                                                          }
                                                        }else{
                                                          //ivalue = 0;
                                                          setState((){
                                                            isPostPrad = true;
                                                          });
                                                        }


                                                      },
                                                      inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,9}'))],
                                                    ),
                                                  ),
                                                  DataCell(Text('mg/d')),
                                                  DataCell(Container(
                                                      decoration: BoxDecoration(
                                                          border: Border.all(color: PrimaryColor),
                                                          borderRadius: BorderRadius.circular(5),
                                                          color: isPostPrad ?  Colors.white : Colors.red
                                                      ),
                                                      child: Padding(
                                                        padding: const EdgeInsets.all(8.0),
                                                        child: Text('70-110',style: TextStyle(color: isPostPrad? Colors.black:Colors.white)),
                                                      ))),
                                                ]),
                                          ]
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),

                      Center(child: Container(
                          decoration: BoxDecoration(
                            color: PrimaryColor,
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.only(top: 8.0,bottom: 8.0,right: 20,left: 20),
                            child: Text("Blood Glucose",style: TextStyle(color: Colors.white),),
                          ))),
                    ],
                  ),
                  SizedBox(height: 50,),
                  Stack(
                    children: [
                      Container(
                        width: width,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 10.0),
                          child: Card(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                                side: BorderSide(color: PrimaryColor)),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                SizedBox(height: 30,),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Expanded(
                                        child: Column(children: [
                                          Text("Result"),
                                          SizedBox(
                                            height: 15,
                                          ),
                                          AbsorbPointer(
                                            absorbing: isUrineEditable,
                                            child: DropdownButton<String>(
                                              underline: Container(),
                                              hint: Text("Select"),
                                              value: currentSelectedValue,
                                              isDense: true,
                                              onChanged: (newValue) {
                                                setState(() {
                                                  currentSelectedValue = newValue!;
                                                  if(currentSelectedValue=='Present'){
                                                    setState((){
                                                      isUrine = false;
                                                    });
                                                  }else{
                                                    setState((){
                                                      isUrine = true;
                                                    });
                                                  }
                                                });
                                                print(currentSelectedValue);
                                              },
                                              items: deviceTypes.map((String value) {
                                                return DropdownMenuItem<String>(
                                                  value: value,
                                                  child: Text(value),
                                                );
                                              }).toList(),
                                            ),
                                          )
                                        ],),
                                      ),
                                      Expanded(
                                        child: Column(children: [
                                          Text("Range"),
                                          SizedBox(
                                            height: 15,
                                          ),
                                          Container(
                                              decoration: BoxDecoration(
                                                  border: Border.all(color: PrimaryColor),
                                                  borderRadius: BorderRadius.circular(5),
                                                  color: isUrine ?  Colors.white : Colors.red
                                              ),
                                              child: Padding(
                                                padding: const EdgeInsets.all(8.0),
                                                child: Text('Absent',style: TextStyle(color: isUrine? Colors.black:Colors.white)),
                                              ))
                                        ],),
                                      ),

                                    ],),
                                ),
                                SizedBox(height: 30,),
                              ],
                            ),
                          ),
                        ),
                      ),

                      Center(child: Container(
                          decoration: BoxDecoration(
                            color: PrimaryColor,
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.only(top: 8.0,bottom: 8.0,right: 20,left: 20),
                            child: Text("Urine Acetone",style: TextStyle(color: Colors.white),),
                          ))),
                    ],
                  ),
                ],
              ),
            ),
          ),
        )
    );
  }

  Future getPatientList() async {

    Map data = {
      'customer_id' : customerId,
      'user_id' : userId,
      'filtertext' : "",
      'Select_Valuecode' : ""
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/PatientListing"),body: data)
    ]).then((response) {
      var jsonData = null;

      if(response[0].statusCode==200){
        jsonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = PatientListingResponse.fromJson(map);

        if(response1.settings.success=="1"){
          for(int i =0; i<response1.data.length; i++) {
            patientList.add(EmployeeTypeHelper(response1.data[i].patientName, response1.data[i].patientId, "", false,""));
          }
        }
      }else{
        print("status code wrong");
      }
    },onError: (error){

      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(msg: error.toString(), textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER);

    });
  }
  Future getLabList() async {

    Map data = {
      'customer_id' : customerId,
      'User_Id' : userId,
      'filtertext' : "",
      'Select_Valuecode' : ""
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/LabListing"),body: data)
    ]).then((response) {
      var jsonData = null;

      if(response[0].statusCode==200){
        jsonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = LabListResponse.fromJson(map);

        if(response1.settings.success=="1"){
          for(int i =0; i<response1.data.length; i++) {
            labList.add(EmployeeTypeHelper(response1.data[i].laboratoryName, response1.data[i].id, "", false,""));
          }
        }
      }else{
        print("status code wrong");
      }
    },onError: (error){

      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(msg: error.toString(), textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER);

    });
  }

  Future getDiabetesData() async{

    _patientController.text = widget.listvalue.strpatient.toString();
    strPatientId = widget.listvalue.strpatientId.toString();
    strPatient = widget.listvalue.strpatient.toString();

    strLabId = widget.listvalue.strlaboratoryId.toString();
    _labController.text = widget.listvalue.strlaboratory.toString();

    _dateController.text = widget.listvalue.strdate.toString();

    _bloodGlucoseController.text = widget.listvalue.strbloodGlucoseResult.toString();
    strBloodGlucose = widget.listvalue.strbloodGlucoseResult.toString();
    var isBloodGlucoseVar = int.parse(_bloodGlucoseController.text.toString());

    _postPrandialController.text = widget.listvalue.strpostPrandialBloodGluAfter.toString();
    strPostPrandial = widget.listvalue.strpostPrandialBloodGluAfter.toString();
    var isPostPradVar = int.parse( _postPrandialController.text.toString());


    setState((){
      currentSelectedValue = widget.listvalue.strUrineAcetoneResult.toString();
      if(currentSelectedValue=='Present'){
        setState((){
          isUrine = false;
        });
      }else{
        setState((){
          isUrine = true;
        });
      }

      if(isBloodGlucoseVar >=70 && isBloodGlucoseVar <=110){
        setState((){
          isBloodg = true;
        });
      } else{
        setState((){
          isBloodg = false;
        });
      }

      if(isPostPradVar >=70 && isPostPradVar <=110){
        setState((){
          isPostPrad = true;
        });
      } else{
        setState((){
          isPostPrad = false;
        });
      }

    });

  }




  Future openSelectDialog(BuildContext context, TextEditingController controller, List<EmployeeTypeHelper> dataList, String idtfDialog) async {

    if(idtfDialog=="Patient"){
      showDialog(
          context: context,
          builder: (BuildContext context) => CustomAlertSelectionDialog(
            idtfDialog: idtfDialog,
            selectedId: "1",
            selectionList: patientList,
            doneTitle: "Done",
            cancelTitle: "Cancel",
            position: "1",
            onClick: onSelectionClick,
            onCancel: onSelectionCancel,
            rowClickPos: 0,
            relationController:controller,));
    }else if(idtfDialog=="Laboratory"){
      showDialog(
          context: context,
          builder: (BuildContext context) => CustomAlertSelectionDialog(
            idtfDialog: idtfDialog,
            selectedId: "1",
            selectionList: labList,
            doneTitle: "Done",
            cancelTitle: "Cancel",
            position: "1",
            onClick: onSelectionClick,
            onCancel: onSelectionCancel,
            rowClickPos: 0,
            relationController:controller,));
    }

  }

  onSelectionClick(
      String idtfDialog,
      String selectedId,
      String selectionName,
      String position,
      int rowClickPos,
      TextEditingController controller,
      String extraStr) {

    if(idtfDialog=="Patient"){
      controller.text = selectionName;
      print(selectedId);
      print(selectionName);
     // Navigator.pop(context, arrayList);
      strPatientId = selectedId;
      strPatient = selectionName;
      print("patient Id.."+strPatientId);

    }else if(idtfDialog=="Laboratory"){
      controller.text = selectionName;
      print(selectedId);
      print(selectionName);
     // Navigator.pop(context, arrayList);
      strLabId = selectedId;
      strLab = selectionName;
      print("labId.."+strLabId);
    }





  }

  onSelectionCancel(String p1) {
  }

  Future<String> _showDatePicker(BuildContext context)async{
    final DateTime? picked=await showDatePicker(
        context: context, initialDate: DateTime.now(),
        firstDate: DateTime(2015, 8),
        lastDate: DateTime(2101));
    if(picked != null)
    {
      return DateFormat("dd/MM/yyyy").format(picked);
    }
    return today1;
  }

  Future checkValidation() async{
    if(strPatient!=null && strPatient.toString().length>0){
      if(_dateController.text.isNotEmpty && _dateController.text.length>0){
        if(_labController.text.isNotEmpty && _labController.text.length>0){
          if(strBloodGlucose!=null && strBloodGlucose.toString().length>0){
            if(strPostPrandial!=null && strPostPrandial.toString().length>0){
              if(currentSelectedValue!=null && currentSelectedValue!='Select'){
                //Fluttertoast.showToast(msg: "Success...",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
                SubmitData();
              }else{
                Fluttertoast.showToast(msg: "Please select urine acetone.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
              }
            }else{
              Fluttertoast.showToast(msg: "Please enter post prandial B.G. after 1hr.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
            }
          }else{
            Fluttertoast.showToast(msg: "Please enter blood glucose.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
          }
        }else{
          Fluttertoast.showToast(msg: "Please select laboratory name.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
        }
      }else{
        Fluttertoast.showToast(msg: "Please select date.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
      }
    }else{
      Fluttertoast.showToast(msg: "Please select patient.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
    }
  }

  Future SubmitData() async{


    setState((){
      _isLoading = true;
    });

    Map data = {
      'customer_id' :  customerId.toString(),
      'user_id' :  userId.toString(),
      'lab_id' :  strLabId,
      'dia_id' :  diabetesId,
      'pat_id' :  strPatientId,
      'test_date' :  _dateController.text.toString(),
      'bgl' :  strBloodGlucose,
      'P_bgl' :  strPostPrandial,
      'ua' :  currentSelectedValue,
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/SaveMediNoteDiabetesData"),body: data)
    ]).then((response){

      var jasonData = null;
      setState((){
        _isLoading = false;
      });
      if(response[0].statusCode==200){

        jasonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = CommonResponse.fromJson(map);

        if(response1.settings.success=="1"){
          setState((){

            //Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=>ListPatientActivity()));
            Navigator.pop(context,true);
          });
        }else{
          setState((){
            Fluttertoast.showToast(msg: response1.settings.message, textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER);

          });
        }
      }else{
        Fluttertoast.showToast(msg: 'Something went wrong please try again later.', textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER);
      }


    }, onError: (error) {
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(
          msg: error.toString(),
          textColor: Colors.white,
          backgroundColor: Colors.red,
          gravity: ToastGravity.CENTER);
    });
  }
  Future disableButton(String isEditable) async{
    // 1=disable,2=enable
    if(isEditable=="1"){
      setState((){

        title="Diabetes Report Detail";
        isPatientNameEditable = false;
        isTestDateEditable = false;
        isLabEditable = false;
        isBloodGlucoseEditable = false;
        isPostPrandialEditable = false;
        isUrineEditable = true;
        /*isBloodGrpEditable = false;
        isGenderEditable = false;
        isLeftEyeEditable = false;
        isRightEyeEditable = false;
        isVisionAddDataEnable = false;
        isVisionDeleteEditable = false;
        isAllergyDesEditable = false;
        isSpecialRemarkEditable = false;

        //for custome radio button
        isDiabetesEditable = true;
        isBPEditable = true;
        isEpliepsyEditable = true;
        isVisionEditable = true;
        isAllergyEditable = true;*/
      });

    }else{
      setState((){
        title="Edit Diabetes Detail";
        isPatientNameEditable = true;
        isTestDateEditable = true;
        isLabEditable = true;
        isBloodGlucoseEditable = true;
        isPostPrandialEditable = true;
        isUrineEditable = false;
        /*isNameEditable = true;
        isMobileEditable = true;
        isEmailEditable = true;
        isAgeEditable = true;
        isRelationEditable = true;
        isBloodGrpEditable = true;
        isGenderEditable = true;
        isLeftEyeEditable = true;
        isRightEyeEditable = true;
        isVisionAddDataEnable = true;
        isVisionDeleteEditable = true;
        isAllergyDesEditable = true;
        isSpecialRemarkEditable = true;

        //for custome radio button
        isDiabetesEditable = false;
        isBPEditable = false;
        isEpliepsyEditable = false;
        isVisionEditable = false;
        isAllergyEditable = false;*/
      });
    }
  }
  Future<bool> alertDeleteDiabetesDialog(context) async{
    return await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Container(
              height: 120,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 10.0),
                    child: Text("Are you sure you want to delete this patient detail?"),
                  ),
                  SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            print('yes selected');
                            Navigator.of(context).pop();
                            DeleteDiabetes();
                          },
                          child: Text("Yes"),
                          style: ElevatedButton.styleFrom(primary: Colors.red.shade800),
                        ),
                      ),
                      SizedBox(width: 15),
                      Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              print('no selected');
                              Navigator.of(context).pop();
                            },
                            child: Text("No", style: TextStyle(color: Colors.black)),
                            style: ElevatedButton.styleFrom(
                              primary: Colors.white,
                            ),
                          ))
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }
  Future DeleteDiabetes() async{

    setState((){
      _isLoading = true;
    });
    Map data = {
      'customer_id' : "",
      'user_id' : userId,
      'dia_id' : widget.diabetesId,
    };

    final response = await http.post(Uri.parse(BASE_URL+"MobileApp/DeleteMediNoteDiabetesData"),body: data);

    setState((){
      _isLoading = true;
    });
    if(response!=null){
      var jsonData = null;
      if(response.statusCode==200){
        jsonData = jsonDecode(response.body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = CommonResponse.fromJson(map);
        if(response1.settings.success == "1"){

          Fluttertoast.showToast(msg: response1.settings.message, textColor: Colors.white, backgroundColor: Colors.green, gravity: ToastGravity.CENTER);
          Navigator.pop(context,true);

        }else{
          Fluttertoast.showToast(msg: response1.settings.message, textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER);
        }
      }else{
        print("add diabetes report response 200 not arrive");
      }
    }else{
      print("add diabetes report response null");
    }



  }


}
