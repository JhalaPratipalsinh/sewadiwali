
import 'dart:convert';

import 'package:custom_radio_grouped_button/custom_radio_grouped_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;

import '../response/CommonResponse.dart';
import '../response/LabListResponse.dart';
import '../response/PatientListingResponse.dart';
import '../utils/AppColors.dart';
import '../utils/CustomAlertSelectionDialog.dart';
import '../utils/EmployeeTypeHelper.dart';
import '../utils/GetEditTextValueHelper.dart';
import '../utils/PreferenceManager.dart';
import '../utils/VariableBag.dart';

class AddBloodPressureActivity extends StatefulWidget {
  const AddBloodPressureActivity({Key? key}) : super(key: key);

  @override
  State<AddBloodPressureActivity> createState() => _AddBloodPressureActivityState();
}

class _AddBloodPressureActivityState extends State<AddBloodPressureActivity> {

  var currentSelectedValue = 'Select';
  var isSystolic = true,isDiastolic = true;
  var strPatient,strPatientId,strLab,strLabId;
  String today1="",todayTime1="";
  var userId,customerId="",strDiastolic,strSystolic;
  var _isLoading = false;
  List<GetEditTextValueHelper> arrayList = <GetEditTextValueHelper>[];

  List<EmployeeTypeHelper> patientList = [];
  List<EmployeeTypeHelper> labList = [];
  TextEditingController _patientController = TextEditingController();
  TextEditingController _dateController = TextEditingController();
  TextEditingController _labController = TextEditingController();
  var strSelfLab = "Self";
  var isLabVisible = false;


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {
      userId = value;
      getPatientList();
      getLabList();
      print("User Id = "+userId.toString());

    }));
    DateTime today = DateTime.now();

    today1 = "${today.day}/${today.month}/${today.year}";

    print("init - "+today1);

  }

  @override
  Widget build(BuildContext context) {
    var _width = MediaQuery.of(context).size.width;
    return Scaffold(
        backgroundColor: grey_2,
        appBar: AppBar(
          backgroundColor: PrimaryColor,
          title: Text("Add Blood Pressure Report"),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 15.0),
              child: InkWell(
                  onTap: (){
                    checkValidation();
                  },
                  child: Icon(Icons.check)),
            ),
          ],

        ),
        body: Container(
          width: _width,
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Stack(
                    children: [
                      Container(
                        width: _width,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 10.0),
                          child: Card(
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10), side: BorderSide(color: PrimaryColor)),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  SizedBox(height: 30,),
                                  //patient
                                  Row(
                                    children: [
                                      Text("Patient : "),
                                      SizedBox(width: 10,),
                                      Flexible(
                                        child: TextFormField(
                                          readOnly: true,
                                          controller: _patientController,
                                          decoration: const InputDecoration(
                                            border: InputBorder.none,
                                            hintText: 'select patinet',
                                            contentPadding: EdgeInsets.all(0.0),
                                            isDense: true,
                                          ),
                                          validator: (value){
                                            strPatient = value;
                                            if(strPatient==null || strPatient.isEmpty){
                                              return 'Select patient.';
                                            }return null;
                                          },
                                          onTap: (){
                                            print("click");
                                            openSelectDialog(context,_patientController,patientList,"Patient");
                                          },
                                        ),
                                      ),
                                      Icon(Icons.arrow_drop_down_outlined,color: PrimaryColor,),

                                    ],
                                  ),
                                  SizedBox(height: 10,),
                                  //testdate
                                  Row(
                                    children: [
                                      const Text("Test Date : "),
                                      const SizedBox(width: 10,),
                                      Flexible(
                                        child: TextFormField(
                                          readOnly: true,
                                          controller: _dateController,
                                          decoration: const InputDecoration(
                                              hintText: 'select date',
                                              contentPadding: EdgeInsets.all(0),
                                              isDense: true,
                                              border: InputBorder.none
                                          ),
                                          onTap: ()async{
                                            String toDate = await _showDatePicker(context);
                                            //_showDatePicker(context);
                                            print(toDate);
                                            _dateController.text = toDate;
                                          },

                                        ),
                                      ),
                                      const Icon(Icons.arrow_drop_down_outlined,color: PrimaryColor,)
                                    ],
                                  ),
                                  SizedBox(height: 10,),
                                  CustomRadioButton(
                                    unSelectedBorderColor: grey_90,
                                    selectedBorderColor: PrimaryColor,
                                    width: _width/2.4,
                                    height: 25,
                                    elevation: 0,
                                    absoluteZeroSpacing: true,
                                    unSelectedColor: Colors.white,
                                    defaultSelected: "Self",
                                    buttonLables: const [
                                      'Self',
                                      'Lab',
                                    ],
                                    buttonValues: const [
                                      'Self',
                                      'Lab',
                                    ],
                                    buttonTextStyle: ButtonTextStyle(
                                        selectedColor: Colors.white,
                                        unSelectedColor: grey_60,
                                        textStyle: TextStyle(fontSize: 16)),
                                    radioButtonValue: (value) {
                                      strSelfLab = value.toString();
                                      print(strSelfLab);
                                      if(value=="Lab"){
                                        setState((){
                                          isLabVisible = true;
                                        });
                                      }else{
                                        setState((){
                                          isLabVisible = false;
                                        });
                                      }
                                    },
                                    enableShape: true,
                                    selectedColor: PrimaryColor,
                                  ),
                                  SizedBox(height: 10,),
                                  Visibility(
                                    visible: isLabVisible,
                                    child: Row(
                                      children: [
                                        const Text("Laboratory Name : "),
                                        const SizedBox(width: 10,),
                                        Flexible(
                                          child: TextFormField(
                                            readOnly: true,
                                            controller: _labController,
                                            decoration: const InputDecoration(
                                              hintText: 'select laboratory name.',
                                              contentPadding: EdgeInsets.all(0.0),
                                              isDense: true,
                                              border: InputBorder.none,
                                            ),
                                            validator: (value){
                                              strLab = value;
                                              if(strLab==null || strLab.isEmpty){
                                                return 'Select laboratory name';
                                              }return null;
                                            },
                                            onTap: (){
                                              print("click");
                                              openSelectDialog(context,_labController,labList,"Laboratory");
                                            },
                                          ),
                                        ),
                                        const Icon(Icons.arrow_drop_down_outlined,color: PrimaryColor,)
                                      ],
                                    ),
                                  ),
                                  Container(
                                    child: SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      child: FittedBox(
                                        child: DataTable(
                                            border: TableBorder.symmetric(
                                                inside: BorderSide(width: 1,color: Colors.white)
                                            ),
                                            columns: const [
                                              DataColumn(label: Text('Test Name ')),
                                              DataColumn(label: Text('Result')),
                                              DataColumn(label: Text('Range')),
                                            ],
                                            rows:  [
                                              DataRow(
                                                  cells: [
                                                    DataCell(Text('Systolic :')),
                                                    DataCell(
                                                      TextFormField(
                                                        keyboardType: TextInputType.number,
                                                        maxLength: 3,
                                                        decoration: const InputDecoration(
                                                            hintText: 'enter',
                                                            border: InputBorder.none,
                                                            contentPadding: EdgeInsets.symmetric(vertical: 5,horizontal: 5),
                                                            isDense: true,
                                                            fillColor:grey_20,
                                                            filled: true,
                                                            counterText: ""
                                                        ),
                                                        onChanged: (value){
                                                          strSystolic = value;
                                                          int ivalue;
                                                          if(value.toString().isNotEmpty && value.toString().length>0){
                                                            ivalue = int.parse(value.toString());

                                                            if(ivalue <120){
                                                              setState((){
                                                                isSystolic= true;
                                                              });
                                                            } else{
                                                              setState((){
                                                                isSystolic = false;
                                                              });
                                                            }
                                                          }else{
                                                            //ivalue = 0;
                                                            setState((){
                                                              isSystolic = true;
                                                            });
                                                          }


                                                        },
                                                        inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,9}'))],
                                                      ),
                                                    ),
                                                    DataCell(
                                                        Container(
                                                            decoration: BoxDecoration(
                                                                border: Border.all(color: PrimaryColor),
                                                                borderRadius: BorderRadius.circular(5),
                                                                color: isSystolic ?  Colors.white : Colors.red
                                                            ),
                                                            child: Padding(
                                                              padding: const EdgeInsets.all(8.0),
                                                              child: Text('<120 ',style: TextStyle(color: isSystolic? Colors.black:Colors.white),),
                                                            ))),
                                                  ]),

                                              DataRow(
                                                  cells: [
                                                    DataCell(Text('Diastolic :')),
                                                    DataCell(
                                                      TextFormField(
                                                        keyboardType: TextInputType.number,
                                                        maxLength: 3,
                                                        decoration: const InputDecoration(
                                                            hintText: 'enter',
                                                            border: InputBorder.none,
                                                            contentPadding: EdgeInsets.symmetric(vertical: 5,horizontal: 5),
                                                            isDense: true,
                                                            fillColor:grey_20,
                                                            filled: true,
                                                            counterText: ""
                                                        ),
                                                        onChanged: (value){
                                                          strDiastolic = value;
                                                          int ivalue;
                                                          if(value.toString().isNotEmpty && value.toString().length>0){
                                                            ivalue = int.parse(value.toString());

                                                            if(ivalue < 80){
                                                              setState((){
                                                                isDiastolic = true;
                                                              });
                                                            } else{
                                                              setState((){
                                                                isDiastolic = false;
                                                              });
                                                            }
                                                          }else{
                                                            //ivalue = 0;
                                                            setState((){
                                                              isDiastolic = true;
                                                            });
                                                          }


                                                        },
                                                        inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,9}'))],
                                                      ),
                                                    ),
                                                    DataCell(
                                                        Container(
                                                        decoration: BoxDecoration(
                                                            border: Border.all(color: PrimaryColor),
                                                            borderRadius: BorderRadius.circular(5),
                                                            color: isDiastolic ?  Colors.white : Colors.red
                                                        ),
                                                        child: Padding(
                                                          padding: const EdgeInsets.all(8.0),
                                                          child: Text(' <80  ',style: TextStyle(color: isDiastolic? Colors.black:Colors.white)),
                                                        ))),
                                                  ]),
                                            ]
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),

                      Center(child: Container(
                          decoration: BoxDecoration(
                            color: PrimaryColor,
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.only(top: 8.0,bottom: 8.0,right: 20,left: 20),
                            child: Text("Blood Glucose",style: TextStyle(color: Colors.white),),
                          ))),
                    ],
                  ),
                  SizedBox(height: 50,),
                ],
              ),
            ),
          ),
        )
    );
  }


  Future getPatientList() async {

    Map data = {
      'customer_id' : customerId,
      'user_id' : userId,
      'filtertext' : "",
      'Select_Valuecode' : ""
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/PatientListing"),body: data)
    ]).then((response) {
      var jsonData = null;

      if(response[0].statusCode==200){
        jsonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = PatientListingResponse.fromJson(map);

        if(response1.settings.success=="1"){
          for(int i =0; i<response1.data.length; i++) {
            patientList.add(EmployeeTypeHelper(response1.data[i].patientName, response1.data[i].patientId, "", false,""));
          }
        }
      }else{
        print("status code wrong");
      }
    },onError: (error){

      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(msg: error.toString(), textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER);

    });
  }
  Future getLabList() async {

    Map data = {
      'customer_id' : customerId,
      'User_Id' : userId,
      'filtertext' : "",
      'Select_Valuecode' : ""
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/LabListing"),body: data)
    ]).then((response) {
      var jsonData = null;

      if(response[0].statusCode==200){
        jsonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = LabListResponse.fromJson(map);

        if(response1.settings.success=="1"){
          for(int i =0; i<response1.data.length; i++) {
            labList.add(EmployeeTypeHelper(response1.data[i].laboratoryName, response1.data[i].id, "", false,""));
          }
        }
      }else{
        print("status code wrong");
      }
    },onError: (error){

      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(msg: error.toString(), textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER);

    });
  }

  Future openSelectDialog(BuildContext context, TextEditingController controller, List<EmployeeTypeHelper> dataList, String idtfDialog) async {

    if(idtfDialog=="Patient"){
      showDialog(
          context: context,
          builder: (BuildContext context) => CustomAlertSelectionDialog(
            idtfDialog: idtfDialog,
            selectedId: "1",
            selectionList: patientList,
            doneTitle: "Done",
            cancelTitle: "Cancel",
            position: "1",
            onClick: onSelectionClick,
            onCancel: onSelectionCancel,
            rowClickPos: 0,
            relationController:controller,));
    }else if(idtfDialog=="Laboratory"){
      showDialog(
          context: context,
          builder: (BuildContext context) => CustomAlertSelectionDialog(
            idtfDialog: idtfDialog,
            selectedId: "1",
            selectionList: labList,
            doneTitle: "Done",
            cancelTitle: "Cancel",
            position: "1",
            onClick: onSelectionClick,
            onCancel: onSelectionCancel,
            rowClickPos: 0,
            relationController:controller,));
    }

  }

  onSelectionClick(
      String idtfDialog,
      String selectedId,
      String selectionName,
      String position,
      int rowClickPos,
      TextEditingController controller,
      String extraStr) {

    if(idtfDialog=="Patient"){
      controller.text = selectionName;
      print(selectedId);
      print(selectionName);
      //Navigator.pop(context, arrayList);
      strPatientId = selectedId;
      strPatient = selectionName;
      print("patient Id.."+strPatientId);

    }else if(idtfDialog=="Laboratory"){
      controller.text = selectionName;
      print(selectedId);
      print(selectionName);
     // Navigator.pop(context, arrayList);
      strLabId = selectedId;
      strLab = selectionName;
      print("labId.."+strLabId);
    }
  }

  onSelectionCancel(String p1) {
  }

  Future checkValidation() async{
    if(strPatient!=null && strPatient.toString().length>0){
      if(_dateController.text.isNotEmpty && _dateController.text.length>0){
        if(strSelfLab=='Lab'){
          if(_labController.text.isNotEmpty && _labController.text.length>0){
            if(strSystolic!=null && strSystolic.toString().length>0){
              if(strDiastolic!=null && strDiastolic.toString().length>0){
                  //Fluttertoast.showToast(msg: "Success...",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
                  SubmitData();

              }else{
                Fluttertoast.showToast(msg: "Please enter diastolic.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
              }
            }else{
              Fluttertoast.showToast(msg: "Please enter systolic.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
            }
          }else{
            Fluttertoast.showToast(msg: "Please select laboratory name.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
          }
        }else{
          if(strSystolic!=null && strSystolic.toString().length>0){
            if(strDiastolic!=null && strDiastolic.toString().length>0){
              //Fluttertoast.showToast(msg: "Success...",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
              SubmitData();

            }else{
              Fluttertoast.showToast(msg: "Please enter diastolic.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
            }
          }else{
            Fluttertoast.showToast(msg: "Please enter systolic.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
          }
        }
      }else{
        Fluttertoast.showToast(msg: "Please select date.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
      }
    }else{
      Fluttertoast.showToast(msg: "Please select patient.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
    }
  }

  Future SubmitData() async{


    setState((){
      _isLoading = true;
    });

    Map data = {
      'customer_id' :  customerId.toString(),
      'user_id' :  userId.toString(),
      'lab_id' :  strLabId,
      'bp_id' :  '',
      'pat_id' :  strPatientId,
      'test_date' :  _dateController.text.toString(),
      'Systolic' :  strSystolic,
      'Diastolic' :  strDiastolic,
      'Test_At' :  strSelfLab,
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/SaveMediNoteBPData"),body: data)
    ]).then((response){

      var jasonData = null;
      setState((){
        _isLoading = false;
      });
      if(response[0].statusCode==200){

        jasonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = CommonResponse.fromJson(map);

        if(response1.settings.success=="1"){
          setState((){

            //Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=>ListPatientActivity()));
            Navigator.pop(context,true);
          });
        }else{
          setState((){
            Fluttertoast.showToast(msg: response1.settings.message, textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER);

          });
        }
      }else{
        Fluttertoast.showToast(msg: 'Something went wrong please try again later.', textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER);
      }


    }, onError: (error) {
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(
          msg: error.toString(),
          textColor: Colors.white,
          backgroundColor: Colors.red,
          gravity: ToastGravity.CENTER);
    });
  }

  Future<String> _showDatePicker(BuildContext context)async{
    final DateTime? picked=await showDatePicker(
        context: context, initialDate: DateTime.now(),
        firstDate: DateTime(2015, 8),
        lastDate: DateTime(2101));
    if(picked != null)
    {
      return DateFormat("dd/MM/yyyy").format(picked);
    }
    return today1;
  }



}
