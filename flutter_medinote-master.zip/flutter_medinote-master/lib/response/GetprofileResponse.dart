// To parse this JSON data, do
//
//     final getprofileResponse = getprofileResponseFromJson(jsonString);

import 'dart:convert';

GetprofileResponse getprofileResponseFromJson(String str) => GetprofileResponse.fromJson(json.decode(str));

String getprofileResponseToJson(GetprofileResponse data) => json.encode(data.toJson());

class GetprofileResponse {
  GetprofileResponse({
    required this.settings,
    required  this.data,
  });

  Settings settings;
  List<Datum> data;

  factory GetprofileResponse.fromJson(Map<String, dynamic> json) => GetprofileResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required  this.userId,
    required  this.patientId,
    required  this.userName,
    required  this.contactNumber,
    required  this.emailId,
    required this.gender,
    required  this.bloodGroup,
    required this.diabetes,
    required  this.relation,
    required  this.profilePhoto,
    required  this.bloodPressure,
    required   this.specialRemarks,
    required  this.epilepsy,
    required  this.allergy,
    required  this.vision,
    required  this.age,
    required this.visionData,
  });

  String userId;
  String patientId;
  String userName;
  String contactNumber;
  String emailId;
  String gender;
  String bloodGroup;
  String diabetes;
  String relation;
  String profilePhoto;
  String bloodPressure;
  String specialRemarks;
  String epilepsy;
  String allergy;
  String vision;
  String age;
  List<dynamic> visionData;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    userId: json["User Id"],
    patientId: json["Patient Id"],
    userName: json["User Name"],
    contactNumber: json["Contact Number"],
    emailId: json["Email ID"],
    gender: json["Gender"],
    bloodGroup: json["Blood Group"],
    diabetes: json["Diabetes"],
    relation: json["Relation"],
    profilePhoto: json["Profile Photo"],
    bloodPressure: json["Blood Pressure"],
    specialRemarks: json["Special Remarks"],
    epilepsy: json["Epilepsy"],
    allergy: json["Allergy"],
    vision: json["Vision"],
    age: json["Age"],
    visionData: List<dynamic>.from(json["Vision Data"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "User Id": userId,
    "Patient Id": patientId,
    "User Name": userName,
    "Contact Number": contactNumber,
    "Email ID": emailId,
    "Gender": gender,
    "Blood Group": bloodGroup,
    "Diabetes": diabetes,
    "Relation": relation,
    "Profile Photo": profilePhoto,
    "Blood Pressure": bloodPressure,
    "Special Remarks": specialRemarks,
    "Epilepsy": epilepsy,
    "Allergy": allergy,
    "Vision": vision,
    "Age": age,
    "Vision Data": List<dynamic>.from(visionData.map((x) => x)),
  };
}

class Settings {
  Settings({
    required   this.success,
    required  this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
