// To parse this JSON data, do
//
//     final patientListingResponse = patientListingResponseFromJson(jsonString);

import 'dart:convert';

PatientListingResponse patientListingResponseFromJson(String str) => PatientListingResponse.fromJson(json.decode(str));

String patientListingResponseToJson(PatientListingResponse data) => json.encode(data.toJson());

class PatientListingResponse {
  PatientListingResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory PatientListingResponse.fromJson(Map<String, dynamic> json) => PatientListingResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.patientId,
    required this.patientName,
  });

  String patientId;
  String patientName;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    patientId: json["Patient Id"],
    patientName: json["Patient Name"],
  );

  Map<String, dynamic> toJson() => {
    "Patient Id": patientId,
    "Patient Name": patientName,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
