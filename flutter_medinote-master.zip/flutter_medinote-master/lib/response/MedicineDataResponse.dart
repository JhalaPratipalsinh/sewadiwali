// To parse this JSON data, do
//
//     final medicineDataResponse = medicineDataResponseFromJson(jsonString);

import 'dart:convert';

MedicineDataResponse medicineDataResponseFromJson(String str) => MedicineDataResponse.fromJson(json.decode(str));

String medicineDataResponseToJson(MedicineDataResponse data) => json.encode(data.toJson());

class MedicineDataResponse {
  MedicineDataResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory MedicineDataResponse.fromJson(Map<String, dynamic> json) => MedicineDataResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.userId,
    required this.medicineId,
    required this.medicineName,
    required this.medicineType,
  });

  String userId;
  String medicineId;
  String medicineName;
  String medicineType;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    userId: json["User Id"],
    medicineId: json["Medicine Id"],
    medicineName: json["Medicine Name"],
    medicineType: json["Medicine Type"],
  );

  Map<String, dynamic> toJson() => {
    "User Id": userId,
    "Medicine Id": medicineId,
    "Medicine Name": medicineName,
    "Medicine Type": medicineType,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.nextPage,
    required this.fields,
  });

  String success;
  String message;
  String nextPage;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    nextPage: json["next_page"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "next_page": nextPage,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
