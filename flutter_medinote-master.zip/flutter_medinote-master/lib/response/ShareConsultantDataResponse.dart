// To parse this JSON data, do
//
//     final shareConsultantDataResponse = shareConsultantDataResponseFromJson(jsonString);

import 'dart:convert';

ShareConsultantDataResponse shareConsultantDataResponseFromJson(String str) => ShareConsultantDataResponse.fromJson(json.decode(str));

String shareConsultantDataResponseToJson(ShareConsultantDataResponse data) => json.encode(data.toJson());

class ShareConsultantDataResponse {
  ShareConsultantDataResponse({
    required this.settings,
    required this.consultant,
  });

  Settings settings;
  List<Consultant> consultant;

  factory ShareConsultantDataResponse.fromJson(Map<String, dynamic> json) => ShareConsultantDataResponse(
    settings: Settings.fromJson(json["settings"]),
    consultant: List<Consultant>.from(json["Consultant"].map((x) => Consultant.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "Consultant": List<dynamic>.from(consultant.map((x) => x.toJson())),
  };
}

class Consultant {
  Consultant({
    required this.doctorName,
    required this.patientName,
    required this.symptoms,
    required this.diseaseName,
    required this.date,
    required this.medicine,
  });

  String doctorName;
  String patientName;
  String symptoms;
  String diseaseName;
  DateTime date;
  List<Medicine> medicine;

  factory Consultant.fromJson(Map<String, dynamic> json) => Consultant(
    doctorName: json["Doctor Name"],
    patientName: json["Patient Name"],
    symptoms: json["Symptoms"],
    diseaseName: json["Disease Name"],
    date: DateTime.parse(json["Date"]),
    medicine: List<Medicine>.from(json["Medicine"].map((x) => Medicine.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Doctor Name": doctorName,
    "Patient Name": patientName,
    "Symptoms": symptoms,
    "Disease Name": diseaseName,
    "Date": "${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}",
    "Medicine": List<dynamic>.from(medicine.map((x) => x.toJson())),
  };
}

class Medicine {
  Medicine({
    required this.medicineName,
    required this.medicineQuantity,
    required this.atMorning,
    required this.atAfternoon,
    required this.atEvening,
    required this.beforOrAfter,
    required this.medicineWith,
    required this.medicineSchedule,
    required this.startDate,
    required this.endDate,
    required this.medicineType,
    required this.drugName,
    required this.medicinePrice,
    required this.manufacturer,
  });

  String medicineName;
  String medicineQuantity;
  String atMorning;
  String atAfternoon;
  String atEvening;
  String beforOrAfter;
  String medicineWith;
  String medicineSchedule;
  String startDate;
  String endDate;
  String medicineType;
  String drugName;
  String medicinePrice;
  String manufacturer;

  factory Medicine.fromJson(Map<String, dynamic> json) => Medicine(
    medicineName: json["Medicine Name"],
    medicineQuantity: json["Medicine Quantity"],
    atMorning: json["At Morning"],
    atAfternoon: json["At Afternoon"],
    atEvening: json["At Evening"],
    beforOrAfter: json["Befor Or After"],
    medicineWith: json["Medicine With"],
    medicineSchedule: json["Medicine Schedule"],
    startDate: json["Start Date"],
    endDate: json["End Date"],
    medicineType: json["Medicine Type"],
    drugName: json["Drug Name"],
    medicinePrice: json["Medicine Price"],
    manufacturer: json["Manufacturer"],
  );

  Map<String, dynamic> toJson() => {
    "Medicine Name": medicineName,
    "Medicine Quantity": medicineQuantity,
    "At Morning": atMorning,
    "At Afternoon": atAfternoon,
    "At Evening": atEvening,
    "Befor Or After": beforOrAfter,
    "Medicine With": medicineWith,
    "Medicine Schedule": medicineSchedule,
    "Start Date": startDate,
    "End Date": endDate,
    "Medicine Type": medicineType,
    "Drug Name": drugName,
    "Medicine Price": medicinePrice,
    "Manufacturer": manufacturer,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
