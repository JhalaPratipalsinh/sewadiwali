// To parse this JSON data, do
//
//     final saveDiseaseDataResponse = saveDiseaseDataResponseFromJson(jsonString);

import 'dart:convert';

SaveDiseaseDataResponse saveDiseaseDataResponseFromJson(String str) => SaveDiseaseDataResponse.fromJson(json.decode(str));

String saveDiseaseDataResponseToJson(SaveDiseaseDataResponse data) => json.encode(data.toJson());

class SaveDiseaseDataResponse {
  SaveDiseaseDataResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory SaveDiseaseDataResponse.fromJson(Map<String, dynamic> json) => SaveDiseaseDataResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.disId,
  });

  String disId;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    disId: json["Dis_Id"],
  );

  Map<String, dynamic> toJson() => {
    "Dis_Id": disId,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
