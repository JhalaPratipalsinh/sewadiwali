// To parse this JSON data, do
//
//     final consultantMedDataListingResponse = consultantMedDataListingResponseFromJson(jsonString);

import 'dart:convert';

ConsultantMedDataListingResponse consultantMedDataListingResponseFromJson(String str) => ConsultantMedDataListingResponse.fromJson(json.decode(str));

String consultantMedDataListingResponseToJson(ConsultantMedDataListingResponse data) => json.encode(data.toJson());

class ConsultantMedDataListingResponse {
  ConsultantMedDataListingResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory ConsultantMedDataListingResponse.fromJson(Map<String, dynamic> json) => ConsultantMedDataListingResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.consultantId,
    required this.medicineId,
    required this.medicineName,
    required this.medicineQuantity,
    required this.atMorning,
    required this.atAfternoon,
    required this.atEvening,
    required this.beforOrAfter,
    required this.medicineWith,
    required this.medicineSchedule,
    required this.startDate,
    required this.endDate,
    required this.medicineType,
    required this.remark,
  });

  String consultantId;
  String medicineId;
  String medicineName;
  String medicineQuantity;
  String atMorning;
  String atAfternoon;
  String atEvening;
  String beforOrAfter;
  String medicineWith;
  String medicineSchedule;
  String startDate;
  String endDate;
  String medicineType;
  String remark;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    consultantId: json["Consultant Id"],
    medicineId: json["Medicine Id"],
    medicineName: json["Medicine Name"],
    medicineQuantity: json["Medicine Quantity"],
    atMorning: json["At Morning"],
    atAfternoon: json["At Afternoon"],
    atEvening: json["At Evening"],
    beforOrAfter: json["Befor Or After"],
    medicineWith: json["Medicine With"],
    medicineSchedule: json["Medicine Schedule"],
    startDate: json["Start Date"],
    endDate: json["End Date"],
    medicineType: json["Medicine Type"],
    remark: json["Remark"],
  );

  Map<String, dynamic> toJson() => {
    "Consultant Id": consultantId,
    "Medicine Id": medicineId,
    "Medicine Name": medicineName,
    "Medicine Quantity": medicineQuantity,
    "At Morning": atMorning,
    "At Afternoon": atAfternoon,
    "At Evening": atEvening,
    "Befor Or After": beforOrAfter,
    "Medicine With": medicineWith,
    "Medicine Schedule": medicineSchedule,
    "Start Date": startDate,
    "End Date": endDate,
    "Medicine Type": medicineType,
    "Remark": remark,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.nextPage,
    required this.fields,
  });

  String success;
  String message;
  String nextPage;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    nextPage: json["next_page"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "next_page": nextPage,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
