// To parse this JSON data, do
//
//     final doctorListingResponse = doctorListingResponseFromJson(jsonString);

import 'dart:convert';

DoctorListingResponse doctorListingResponseFromJson(String str) => DoctorListingResponse.fromJson(json.decode(str));

String doctorListingResponseToJson(DoctorListingResponse data) => json.encode(data.toJson());

class DoctorListingResponse {
  DoctorListingResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory DoctorListingResponse.fromJson(Map<String, dynamic> json) => DoctorListingResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.doctorId,
    required this.doctorName,
  });

  String doctorId;
  String doctorName;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    doctorId: json["Doctor Id"],
    doctorName: json["Doctor Name"],
  );

  Map<String, dynamic> toJson() => {
    "Doctor Id": doctorId,
    "Doctor Name": doctorName,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
