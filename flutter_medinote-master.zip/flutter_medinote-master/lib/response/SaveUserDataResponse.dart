// To parse this JSON data, do
//
//     final saveUserDataResponse = saveUserDataResponseFromJson(jsonString);

import 'dart:convert';

SaveUserDataResponse saveUserDataResponseFromJson(String str) => SaveUserDataResponse.fromJson(json.decode(str));

String saveUserDataResponseToJson(SaveUserDataResponse data) => json.encode(data.toJson());

class SaveUserDataResponse {
  SaveUserDataResponse({
    required this.settings,
    required  this.data,
  });

  Settings settings;
  List<Datum> data;

  factory SaveUserDataResponse.fromJson(Map<String, dynamic> json) => SaveUserDataResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required  this.userId,
  });

  String userId;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    userId: json["user_id"],
  );

  Map<String, dynamic> toJson() => {
    "user_id": userId,
  };
}

class Settings {
  Settings({
    required this.success,
    required  this.message,
    required  this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
