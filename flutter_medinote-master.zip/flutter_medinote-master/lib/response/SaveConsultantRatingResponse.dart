// To parse this JSON data, do
//
//     final saveConsultantRatingResponse = saveConsultantRatingResponseFromJson(jsonString);

import 'dart:convert';

SaveConsultantRatingResponse saveConsultantRatingResponseFromJson(String str) => SaveConsultantRatingResponse.fromJson(json.decode(str));

String saveConsultantRatingResponseToJson(SaveConsultantRatingResponse data) => json.encode(data.toJson());

class SaveConsultantRatingResponse {
  SaveConsultantRatingResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory SaveConsultantRatingResponse.fromJson(Map<String, dynamic> json) => SaveConsultantRatingResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.conId,
  });

  String conId;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    conId: json["Con_Id"],
  );

  Map<String, dynamic> toJson() => {
    "Con_Id": conId,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
