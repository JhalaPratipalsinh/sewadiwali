
// To parse this JSON data, do
//
//     final doctorDataListingResponse = doctorDataListingResponseFromJson(jsonString);

import 'dart:convert';

DoctorDataListingResponse doctorDataListingResponseFromJson(String str) => DoctorDataListingResponse.fromJson(json.decode(str));

String doctorDataListingResponseToJson(DoctorDataListingResponse data) => json.encode(data.toJson());

class DoctorDataListingResponse {
  DoctorDataListingResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory DoctorDataListingResponse.fromJson(Map<String, dynamic> json) => DoctorDataListingResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.userId,
    required this.doctorId,
    required this.doctorName,
    required this.doctorContactNumber,
    required this.speciality,
    required this.doctorType,
    required this.fee,
    required this.referredBy,
    required this.city,
    required this.area,
    required this.location,
    required this.gender,
  });

  String userId;
  String doctorId;
  String doctorName;
  String doctorContactNumber;
  String speciality;
  String doctorType;
  String fee;
  String referredBy;
  String city;
  String area;
  String location;
  String gender;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    userId: json["User Id"],
    doctorId: json["Doctor Id"],
    doctorName: json["Doctor Name"],
    doctorContactNumber: json["Doctor Contact Number"],
    speciality: json["Speciality"],
    doctorType: json["Doctor Type"],
    fee: json["Fee"],
    referredBy: json["Referred by"],
    city: json["City"],
    area: json["Area"],
    location: json["Location"],
    gender: json["Gender"],
  );

  Map<String, dynamic> toJson() => {
    "User Id": userId,
    "Doctor Id": doctorId,
    "Doctor Name": doctorName,
    "Doctor Contact Number": doctorContactNumber,
    "Speciality": speciality,
    "Doctor Type": doctorType,
    "Fee": fee,
    "Referred by": referredBy,
    "City": city,
    "Area": area,
    "Location": location,
    "Gender": gender,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.nextPage,
    required this.fields,
  });

  String success;
  String message;
  String nextPage;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    nextPage: json["next_page"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "next_page": nextPage,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
