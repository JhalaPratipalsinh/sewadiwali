// To parse this JSON data, do
//
//     final addVisionDataResponse = addVisionDataResponseFromJson(jsonString);

import 'dart:convert';

AddVisionDataResponse addVisionDataResponseFromJson(String str) => AddVisionDataResponse.fromJson(json.decode(str));

String addVisionDataResponseToJson(AddVisionDataResponse data) => json.encode(data.toJson());

class AddVisionDataResponse {
  AddVisionDataResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory AddVisionDataResponse.fromJson(Map<String, dynamic> json) => AddVisionDataResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.visionId,
  });

  String visionId;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    visionId: json["Vision_Id"],
  );

  Map<String, dynamic> toJson() => {
    "Vision_Id": visionId,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
