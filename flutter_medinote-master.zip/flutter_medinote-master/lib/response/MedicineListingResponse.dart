// To parse this JSON data, do
//
//     final medicineListingResponse = medicineListingResponseFromJson(jsonString);

import 'dart:convert';

MedicineListingResponse medicineListingResponseFromJson(String str) => MedicineListingResponse.fromJson(json.decode(str));

String medicineListingResponseToJson(MedicineListingResponse data) => json.encode(data.toJson());

class MedicineListingResponse {
  MedicineListingResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory MedicineListingResponse.fromJson(Map<String, dynamic> json) => MedicineListingResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.medicineId,
    required this.medicineName,
    required this.medicineType,
    required this.drugName,
    required this.manufacturer,
    required this.price,
  });

  String medicineId;
  String medicineName;
  String medicineType;
  String drugName;
  String manufacturer;
  String price;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    medicineId: json["Medicine Id"],
    medicineName: json["Medicine Name"],
    medicineType: json["Medicine Type"],
    drugName: json["Drug Name"],
    manufacturer: json["Manufacturer"],
    price: json["Price"],
  );

  Map<String, dynamic> toJson() => {
    "Medicine Id": medicineId,
    "Medicine Name": medicineName,
    "Medicine Type": medicineType,
    "Drug Name": drugName,
    "Manufacturer": manufacturer,
    "Price": price,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
