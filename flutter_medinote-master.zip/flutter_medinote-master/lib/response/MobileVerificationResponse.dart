// To parse this JSON data, do
//
//     final mobileVerificationResponse = mobileVerificationResponseFromJson(jsonString);

import 'dart:convert';

MobileVerificationResponse mobileVerificationResponseFromJson(String str) => MobileVerificationResponse.fromJson(json.decode(str));

String mobileVerificationResponseToJson(MobileVerificationResponse data) => json.encode(data.toJson());

class MobileVerificationResponse {
  MobileVerificationResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory MobileVerificationResponse.fromJson(Map<String, dynamic> json) => MobileVerificationResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.mobileNo,
    required this.userId,
    required this.userPId,
  });

  String mobileNo;
  String userId;
  String userPId;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    mobileNo: json["Mobile_No"],
    userId: json["User_ID"],
    userPId: json["UserP_Id"],
  );

  Map<String, dynamic> toJson() => {
    "Mobile_No": mobileNo,
    "User_ID": userId,
    "UserP_Id": userPId,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
