// To parse this JSON data, do
//
//     final consultantMedDataResponse = consultantMedDataResponseFromJson(jsonString);

import 'dart:convert';

ConsultantMedDataResponse consultantMedDataResponseFromJson(String str) => ConsultantMedDataResponse.fromJson(json.decode(str));

String consultantMedDataResponseToJson(ConsultantMedDataResponse data) => json.encode(data.toJson());

class ConsultantMedDataResponse {
  ConsultantMedDataResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory ConsultantMedDataResponse.fromJson(Map<String, dynamic> json) => ConsultantMedDataResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.userId,
    required this.medicineId,
    required this.medicineName,
    required this.medicineQty,
    required this.medicineType,
    required this.medicineSchedule,
    required this.whenToTake,
    required this.medicineWith,
    required this.onMorning,
    required this.onAfternoon,
    required this.onEvening,
    required this.medicineStarted,
    required this.medicineEnded,
    required this.remark,
  });

  String userId;
  String medicineId;
  String medicineName;
  String medicineQty;
  String medicineType;
  String medicineSchedule;
  String whenToTake;
  String medicineWith;
  String onMorning;
  String onAfternoon;
  String onEvening;
  String medicineStarted;
  String medicineEnded;
  String remark;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    userId: json["User Id"],
    medicineId: json["Medicine Id"],
    medicineName: json["Medicine Name"],
    medicineQty: json["Medicine Qty"],
    medicineType: json["Medicine Type"],
    medicineSchedule: json["Medicine Schedule"],
    whenToTake: json["When To Take"],
    medicineWith: json["Medicine With"],
    onMorning: json["On Morning"],
    onAfternoon: json["On Afternoon"],
    onEvening: json["On Evening"],
    medicineStarted: json["Medicine Started"],
    medicineEnded: json["Medicine Ended"],
    remark: json["Remark"],
  );

  Map<String, dynamic> toJson() => {
    "User Id": userId,
    "Medicine Id": medicineId,
    "Medicine Name": medicineName,
    "Medicine Qty": medicineQty,
    "Medicine Type": medicineType,
    "Medicine Schedule": medicineSchedule,
    "When To Take": whenToTake,
    "Medicine With": medicineWith,
    "On Morning": onMorning,
    "On Afternoon": onAfternoon,
    "On Evening": onEvening,
    "Medicine Started": medicineStarted,
    "Medicine Ended": medicineEnded,
    "Remark": remark,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
