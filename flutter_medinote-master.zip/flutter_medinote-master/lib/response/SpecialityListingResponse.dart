// To parse this JSON data, do
//
//     final specialityListingResponse = specialityListingResponseFromJson(jsonString);

import 'dart:convert';

SpecialityListingResponse specialityListingResponseFromJson(String str) => SpecialityListingResponse.fromJson(json.decode(str));

String specialityListingResponseToJson(SpecialityListingResponse data) => json.encode(data.toJson());

class SpecialityListingResponse {
  SpecialityListingResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory SpecialityListingResponse.fromJson(Map<String, dynamic> json) => SpecialityListingResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.id,
    required this.specialityName,
  });

  String id;
  String specialityName;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["Id"],
    specialityName: json["Speciality Name"],
  );

  Map<String, dynamic> toJson() => {
    "Id": id,
    "Speciality Name": specialityName,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
