// To parse this JSON data, do
//
//     final diseaseListingResponse = diseaseListingResponseFromJson(jsonString);

import 'dart:convert';

DiseaseListingResponse diseaseListingResponseFromJson(String str) => DiseaseListingResponse.fromJson(json.decode(str));

String diseaseListingResponseToJson(DiseaseListingResponse data) => json.encode(data.toJson());

class DiseaseListingResponse {
  DiseaseListingResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory DiseaseListingResponse.fromJson(Map<String, dynamic> json) => DiseaseListingResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.diseaseId,
    required this.diseaseName,
  });

  String diseaseId;
  String diseaseName;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    diseaseId: json["Disease Id"],
    diseaseName: json["Disease Name"],
  );

  Map<String, dynamic> toJson() => {
    "Disease Id": diseaseId,
    "Disease Name": diseaseName,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
