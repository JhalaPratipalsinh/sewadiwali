
// To parse this JSON data, do
//
//     final saveLabResponse = saveLabResponseFromJson(jsonString);

import 'dart:convert';

SaveLabResponse saveLabResponseFromJson(String str) => SaveLabResponse.fromJson(json.decode(str));

String saveLabResponseToJson(SaveLabResponse data) => json.encode(data.toJson());

class SaveLabResponse {
  SaveLabResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory SaveLabResponse.fromJson(Map<String, dynamic> json) => SaveLabResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.labId,
  });

  String labId;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    labId: json["Lab_ID"],
  );

  Map<String, dynamic> toJson() => {
    "Lab_ID": labId,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
