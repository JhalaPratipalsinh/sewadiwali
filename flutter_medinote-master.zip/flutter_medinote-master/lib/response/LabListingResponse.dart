// To parse this JSON data, do
//
//     final labListingResponse = labListingResponseFromJson(jsonString);

import 'dart:convert';

LabListingResponse labListingResponseFromJson(String str) => LabListingResponse.fromJson(json.decode(str));

String labListingResponseToJson(LabListingResponse data) => json.encode(data.toJson());

class LabListingResponse {
  LabListingResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory LabListingResponse.fromJson(Map<String, dynamic> json) => LabListingResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.userId,
    required this.laboratoryId,
    required this.laboratoryName,
    required this.laboratoryType,
    required this.laboratoryAddress,
  });

  String userId;
  String laboratoryId;
  String laboratoryName;
  String laboratoryType;
  String laboratoryAddress;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    userId: json["User Id"],
    laboratoryId: json["Laboratory Id"],
    laboratoryName: json["Laboratory Name"],
    laboratoryType: json["Laboratory Type"],
    laboratoryAddress: json["Laboratory Address"],
  );

  Map<String, dynamic> toJson() => {
    "User Id": userId,
    "Laboratory Id": laboratoryId,
    "Laboratory Name": laboratoryName,
    "Laboratory Type": laboratoryType,
    "Laboratory Address": laboratoryAddress,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.nextPage,
    required this.fields,
  });

  String success;
  String message;
  String nextPage;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    nextPage: json["next_page"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "next_page": nextPage,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
