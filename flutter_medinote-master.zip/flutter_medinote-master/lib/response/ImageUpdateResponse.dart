// To parse this JSON data, do
//
//     final imageUpdateResponse = imageUpdateResponseFromJson(jsonString);

import 'dart:convert';

ImageUpdateResponse imageUpdateResponseFromJson(String str) => ImageUpdateResponse.fromJson(json.decode(str));

String imageUpdateResponseToJson(ImageUpdateResponse data) => json.encode(data.toJson());

class ImageUpdateResponse {
  ImageUpdateResponse({
    required this.settings,
    required  this.data,
  });

  Settings settings;
  List<Datum> data;

  factory ImageUpdateResponse.fromJson(Map<String, dynamic> json) => ImageUpdateResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required  this.imagePath1,
  });

  String imagePath1;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    imagePath1: json["image_path1"],
  );

  Map<String, dynamic> toJson() => {
    "image_path1": imagePath1,
  };
}

class Settings {
  Settings({
    required   this.success,
    required   this.message,
    required  this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
