// To parse this JSON data, do
//
//     final consultationEditMainDataResponse = consultationEditMainDataResponseFromJson(jsonString);

import 'dart:convert';

ConsultationEditMainDataResponse consultationEditMainDataResponseFromJson(String str) => ConsultationEditMainDataResponse.fromJson(json.decode(str));

String consultationEditMainDataResponseToJson(ConsultationEditMainDataResponse data) => json.encode(data.toJson());

class ConsultationEditMainDataResponse {
  ConsultationEditMainDataResponse({
    required this.settings,
    required this.consultant,
  });

  Settings settings;
  List<Consultant> consultant;

  factory ConsultationEditMainDataResponse.fromJson(Map<String, dynamic> json) => ConsultationEditMainDataResponse(
    settings: Settings.fromJson(json["settings"]),
    consultant: List<Consultant>.from(json["Consultant"].map((x) => Consultant.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "Consultant": List<dynamic>.from(consultant.map((x) => x.toJson())),
  };
}

class Consultant {
  Consultant({
    required this.userId,
    required this.doctorId,
    required this.doctorName,
    required this.patientId,
    required this.patientName,
    required this.symptomsId,
    required this.symptoms,
    required this.diseaseId,
    required this.diseaseName,
    required this.date,
    required this.time,
    required this.rating,
    required this.comment,
  });

  String userId;
  String doctorId;
  String doctorName;
  String patientId;
  String patientName;
  String symptomsId;
  String symptoms;
  String diseaseId;
  String diseaseName;
  String date;
  String time;
  String rating;
  String comment;

  factory Consultant.fromJson(Map<String, dynamic> json) => Consultant(
    userId: json["User Id"],
    doctorId: json["Doctor Id"],
    doctorName: json["Doctor Name"],
    patientId: json["Patient Id"],
    patientName: json["Patient Name"],
    symptomsId: json["Symptoms Id"],
    symptoms: json["Symptoms"],
    diseaseId: json["Disease Id"],
    diseaseName: json["Disease Name"],
    date: json["Date"],
    time: json["Time"],
    rating: json["Rating"],
    comment: json["Comment"],
  );

  Map<String, dynamic> toJson() => {
    "User Id": userId,
    "Doctor Id": doctorId,
    "Doctor Name": doctorName,
    "Patient Id": patientId,
    "Patient Name": patientName,
    "Symptoms Id": symptomsId,
    "Symptoms": symptoms,
    "Disease Id": diseaseId,
    "Disease Name": diseaseName,
    "Date": date,
    "Time": time,
    "Rating": rating,
    "Comment": comment,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
