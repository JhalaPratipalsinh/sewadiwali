// To parse this JSON data, do
//
//     final labListResponse = labListResponseFromJson(jsonString);

import 'dart:convert';

LabListResponse labListResponseFromJson(String str) => LabListResponse.fromJson(json.decode(str));

String labListResponseToJson(LabListResponse data) => json.encode(data.toJson());

class LabListResponse {
  LabListResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory LabListResponse.fromJson(Map<String, dynamic> json) => LabListResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.id,
    required this.laboratoryName,
  });

  String id;
  String laboratoryName;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["Id"],
    laboratoryName: json["Laboratory Name"],
  );

  Map<String, dynamic> toJson() => {
    "Id": id,
    "Laboratory Name": laboratoryName,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
