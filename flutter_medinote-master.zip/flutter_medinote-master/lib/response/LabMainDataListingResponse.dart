// To parse this JSON data, do
//
//     final labMainDataListingResponse = labMainDataListingResponseFromJson(jsonString);

import 'dart:convert';

LabMainDataListingResponse labMainDataListingResponseFromJson(String str) => LabMainDataListingResponse.fromJson(json.decode(str));

String labMainDataListingResponseToJson(LabMainDataListingResponse data) => json.encode(data.toJson());

class LabMainDataListingResponse {
  LabMainDataListingResponse({
    required this.settings,
    required this.labdata,
  });

  Settings settings;
  List<Labdatum> labdata;

  factory LabMainDataListingResponse.fromJson(Map<String, dynamic> json) => LabMainDataListingResponse(
    settings: Settings.fromJson(json["settings"]),
    labdata: List<Labdatum>.from(json["LABDATA"].map((x) => Labdatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "LABDATA": List<dynamic>.from(labdata.map((x) => x.toJson())),
  };
}

class Labdatum {
  Labdatum({
    required this.labdata,
  });

  Labdata labdata;

  factory Labdatum.fromJson(Map<String, dynamic> json) => Labdatum(
    labdata: Labdata.fromJson(json["LABDATA"]),
  );

  Map<String, dynamic> toJson() => {
    "LABDATA": labdata.toJson(),
  };
}

class Labdata {
  Labdata({
    required this.diabetes,
    required this.bp,
  });

  List<Diabetes> diabetes;
  List<Bp> bp;

  factory Labdata.fromJson(Map<String, dynamic> json) => Labdata(
    diabetes: List<Diabetes>.from(json["Diabetes"].map((x) => Diabetes.fromJson(x))),
    bp: List<Bp>.from(json["BP"].map((x) => Bp.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Diabetes": List<dynamic>.from(diabetes.map((x) => x.toJson())),
    "BP": List<dynamic>.from(bp.map((x) => x.toJson())),
  };
}

class Bp {
  Bp({
    required this.reportType,
    required this.patientName,
    required this.patientId,
    required this.testDate,
    required this.testAt,
    required this.laboratoryName,
    required this.laboratoryId,
    required this.systolicResult,
    required this.diastolicResult,
    required this.reportId,
  });

  String reportType;
  String patientName;
  String patientId;
  String testDate;
  String testAt;
  String laboratoryName;
  String laboratoryId;
  String systolicResult;
  String diastolicResult;
  String reportId;

  factory Bp.fromJson(Map<String, dynamic> json) => Bp(
    reportType: json["Report Type"],
    patientName: json["Patient Name"],
    patientId: json["Patient Id"],
    testDate: json["Test Date"],
    testAt: json["Test At"],
    laboratoryName: json["Laboratory Name"],
    laboratoryId: json["Laboratory Id"],
    systolicResult: json["Systolic Result"],
    diastolicResult: json["Diastolic Result"],
    reportId: json["Report ID"],
  );

  Map<String, dynamic> toJson() => {
    "Report Type": reportType,
    "Patient Name": patientName,
    "Patient Id": patientId,
    "Test Date": testDate,
    "Test At": testAt,
    "Laboratory Name": laboratoryName,
    "Laboratory Id": laboratoryId,
    "Systolic Result": systolicResult,
    "Diastolic Result": diastolicResult,
    "Report ID": reportId,
  };
}

class Diabetes {
  Diabetes({
    required this.reportType,
    required this.patientName,
    required this.patientId,
    required this.testDate,
    required this.laboratoryName,
    required this.laboratoryId,
    required this.bloodGlucoseResult,
    required this.postPrandialBloodGlucoseAfter1HrResult,
    required this.urineAcetoneResult,
    required this.reportId,
  });

  String reportType;
  String patientName;
  String patientId;
  String testDate;
  String laboratoryName;
  String laboratoryId;
  String bloodGlucoseResult;
  String postPrandialBloodGlucoseAfter1HrResult;
  String urineAcetoneResult;
  String reportId;

  factory Diabetes.fromJson(Map<String, dynamic> json) => Diabetes(
    reportType: json["Report Type"],
    patientName: json["Patient Name"],
    patientId: json["Patient Id"],
    testDate: json["Test Date"],
    laboratoryName: json["Laboratory Name"],
    laboratoryId: json["Laboratory Id"],
    bloodGlucoseResult: json["Blood Glucose Result"],
    postPrandialBloodGlucoseAfter1HrResult: json["Post Prandial Blood Glucose after 1hr result"],
    urineAcetoneResult: json["Urine Acetone Result"],
    reportId: json["Report ID"],
  );

  Map<String, dynamic> toJson() => {
    "Report Type": reportType,
    "Patient Name": patientName,
    "Patient Id": patientId,
    "Test Date": testDate,
    "Laboratory Name": laboratoryName,
    "Laboratory Id": laboratoryId,
    "Blood Glucose Result": bloodGlucoseResult,
    "Post Prandial Blood Glucose after 1hr result": postPrandialBloodGlucoseAfter1HrResult,
    "Urine Acetone Result": urineAcetoneResult,
    "Report ID": reportId,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
