// To parse this JSON data, do
//
//     final visionListResponse = visionListResponseFromJson(jsonString);

import 'dart:convert';

VisionListResponse visionListResponseFromJson(String str) => VisionListResponse.fromJson(json.decode(str));

String visionListResponseToJson(VisionListResponse data) => json.encode(data.toJson());

class VisionListResponse {
  VisionListResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory VisionListResponse.fromJson(Map<String, dynamic> json) => VisionListResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.left,
    required this.right,
    required this.date,
    required this.visionId,
  });

  String left;
  String right;
  String date;
  String visionId;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    left: json["Left"],
    right: json["Right"],
    date: json["Date"],
    visionId: json["Vision Id"],
  );

  Map<String, dynamic> toJson() => {
    "Left": left,
    "Right": right,
    "Date": date,
    "Vision Id": visionId,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
