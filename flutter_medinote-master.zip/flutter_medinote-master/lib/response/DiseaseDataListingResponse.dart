// To parse this JSON data, do
//
//     final diseaseDataListingResponse = diseaseDataListingResponseFromJson(jsonString);

import 'dart:convert';

DiseaseDataListingResponse diseaseDataListingResponseFromJson(String str) => DiseaseDataListingResponse.fromJson(json.decode(str));

String diseaseDataListingResponseToJson(DiseaseDataListingResponse data) => json.encode(data.toJson());

class DiseaseDataListingResponse {
  DiseaseDataListingResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory DiseaseDataListingResponse.fromJson(Map<String, dynamic> json) => DiseaseDataListingResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.userId,
    required this.diseaseId,
    required this.diseaseName,
  });

  String userId;
  String diseaseId;
  String diseaseName;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    userId: json["User Id"],
    diseaseId: json["Disease Id"],
    diseaseName: json["Disease Name"],
  );

  Map<String, dynamic> toJson() => {
    "User Id": userId,
    "Disease Id": diseaseId,
    "Disease Name": diseaseName,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.nextPage,
    required this.fields,
  });

  String success;
  String message;
  String nextPage;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    nextPage: json["next_page"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "next_page": nextPage,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
