// To parse this JSON data, do
//
//     final consultationMainListResponse = consultationMainListResponseFromJson(jsonString);

import 'dart:convert';

ConsultationMainListResponse consultationMainListResponseFromJson(String str) => ConsultationMainListResponse.fromJson(json.decode(str));

String consultationMainListResponseToJson(ConsultationMainListResponse data) => json.encode(data.toJson());

class ConsultationMainListResponse {
  ConsultationMainListResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory ConsultationMainListResponse.fromJson(Map<String, dynamic> json) => ConsultationMainListResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.userId,
    required this.doctorId,
    required this.doctorName,
    required this.patientId,
    required this.patientName,
    required this.symptomsId,
    required this.symptoms,
    required this.diseaseId,
    required this.diseaseName,
    required this.consultantId,
    required this.rating,
    required this.date,
    required this.time,
    required this.dateAndTime,
    required this.comment,
  });

  String userId;
  String doctorId;
  String doctorName;
  String patientId;
  String patientName;
  String symptomsId;
  String symptoms;
  String diseaseId;
  String diseaseName;
  String consultantId;
  String rating;
  String date;
  String time;
  DateTime dateAndTime;
  String comment;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    userId: json["User Id"],
    doctorId: json["Doctor Id"],
    doctorName: json["Doctor Name"],
    patientId: json["Patient Id"],
    patientName: json["Patient Name"],
    symptomsId: json["Symptoms Id"],
    symptoms: json["Symptoms"],
    diseaseId: json["Disease Id"],
    diseaseName: json["Disease Name"],
    consultantId: json["Consultant Id"],
    rating: json["Rating"],
    date: json["Date"],
    time: json["Time"],
    dateAndTime: DateTime.parse(json["Date And Time"]),
    comment: json["Comment"],
  );

  Map<String, dynamic> toJson() => {
    "User Id": userId,
    "Doctor Id": doctorId,
    "Doctor Name": doctorName,
    "Patient Id": patientId,
    "Patient Name": patientName,
    "Symptoms Id": symptomsId,
    "Symptoms": symptoms,
    "Disease Id": diseaseId,
    "Disease Name": diseaseName,
    "Consultant Id": consultantId,
    "Rating": rating,
    "Date": date,
    "Time": time,
    "Date And Time": dateAndTime.toIso8601String(),
    "Comment": comment,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.nextPage,
    required this.fields,
  });

  String success;
  String message;
  String nextPage;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    nextPage: json["next_page"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "next_page": nextPage,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
