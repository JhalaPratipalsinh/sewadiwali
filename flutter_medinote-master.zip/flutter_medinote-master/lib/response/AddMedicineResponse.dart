// To parse this JSON data, do
//
//     final addMedicineResponse = addMedicineResponseFromJson(jsonString);

import 'dart:convert';

AddMedicineResponse addMedicineResponseFromJson(String str) => AddMedicineResponse.fromJson(json.decode(str));

String addMedicineResponseToJson(AddMedicineResponse data) => json.encode(data.toJson());

class AddMedicineResponse {
  AddMedicineResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory AddMedicineResponse.fromJson(Map<String, dynamic> json) => AddMedicineResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.medId,
  });

  String medId;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    medId: json["Med_id"],
  );

  Map<String, dynamic> toJson() => {
    "Med_id": medId,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
