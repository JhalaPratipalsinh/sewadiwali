// To parse this JSON data, do
//
//     final consultantAttachmentListingResponse = consultantAttachmentListingResponseFromJson(jsonString);

import 'dart:convert';

ConsultantAttachmentListingResponse consultantAttachmentListingResponseFromJson(String str) => ConsultantAttachmentListingResponse.fromJson(json.decode(str));

String consultantAttachmentListingResponseToJson(ConsultantAttachmentListingResponse data) => json.encode(data.toJson());

class ConsultantAttachmentListingResponse {
  ConsultantAttachmentListingResponse({
    required this.settings,
    required this.conAttach,
  });

  Settings settings;
  List<ConAttachElement> conAttach;

  factory ConsultantAttachmentListingResponse.fromJson(Map<String, dynamic> json) => ConsultantAttachmentListingResponse(
    settings: Settings.fromJson(json["settings"]),
    conAttach: List<ConAttachElement>.from(json["ConAttach"].map((x) => ConAttachElement.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "ConAttach": List<dynamic>.from(conAttach.map((x) => x.toJson())),
  };
}

class ConAttachElement {
  ConAttachElement({
    required this.conAttach,
  });

  ConAttachConAttach conAttach;

  factory ConAttachElement.fromJson(Map<String, dynamic> json) => ConAttachElement(
    conAttach: ConAttachConAttach.fromJson(json["ConAttach"]),
  );

  Map<String, dynamic> toJson() => {
    "ConAttach": conAttach.toJson(),
  };
}

class ConAttachConAttach {
  ConAttachConAttach({
    required this.report,
    required this.prescription,
  });

  List<Report> report;
  List<Prescription> prescription;

  factory ConAttachConAttach.fromJson(Map<String, dynamic> json) => ConAttachConAttach(
    report: List<Report>.from(json["Report"].map((x) => Report.fromJson(x))),
    prescription: List<Prescription>.from(json["Prescription"].map((x) => Prescription.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Report": List<dynamic>.from(report.map((x) => x.toJson())),
    "Prescription": List<dynamic>.from(prescription.map((x) => x.toJson())),
  };
}

class Prescription {
  Prescription({
    required this.prescriptionNo,
    required this.prescription,
    required this.prescriptionPath,
  });

  int prescriptionNo;
  String prescription;
  String prescriptionPath;

  factory Prescription.fromJson(Map<String, dynamic> json) => Prescription(
    prescriptionNo: json["Prescription No"],
    prescription: json["Prescription"],
    prescriptionPath: json["Prescription Path"],
  );

  Map<String, dynamic> toJson() => {
    "Prescription No": prescriptionNo,
    "Prescription": prescription,
    "Prescription Path": prescriptionPath,
  };
}

class Report {
  Report({
    required this.reportNo,
    required this.report,
    required this.reportName,
    required this.reportPath,
  });

  int reportNo;
  String report;
  String reportName;
  String reportPath;

  factory Report.fromJson(Map<String, dynamic> json) => Report(
    reportNo: json["Report No"],
    report: json["Report"],
    reportName: json["Report Name"],
    reportPath: json["Report Path"],
  );

  Map<String, dynamic> toJson() => {
    "Report No": reportNo,
    "Report": report,
    "Report Name": reportName,
    "Report Path": reportPath,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
