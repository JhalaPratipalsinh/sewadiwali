// To parse this JSON data, do
//
//     final patientDetailResponse = patientDetailResponseFromJson(jsonString);

import 'dart:convert';

PatientDetailResponse patientDetailResponseFromJson(String str) => PatientDetailResponse.fromJson(json.decode(str));

String patientDetailResponseToJson(PatientDetailResponse data) => json.encode(data.toJson());

class PatientDetailResponse {
  PatientDetailResponse({
    required this.settings,
    required this.data,
  });

  Settings settings;
  List<Datum> data;

  factory PatientDetailResponse.fromJson(Map<String, dynamic> json) => PatientDetailResponse(
    settings: Settings.fromJson(json["settings"]),
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "settings": settings.toJson(),
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.userId,
    required this.patientId,
    required this.patientName,
    required this.patientContactNumber,
    required this.patientEmailId,
    required this.gender,
    required this.bloodGroup,
    required this.diabetes,
    required this.relationWithUser,
    required this.bloodPressure,
    required this.specialRemarks,
    required this.epilepsy,
    required this.allergy,
    required this.vision,
    required this.age,
    required this.visionData,
  });

  String userId;
  String patientId;
  String patientName;
  String patientContactNumber;
  String patientEmailId;
  String gender;
  String bloodGroup;
  String diabetes;
  String relationWithUser;
  String bloodPressure;
  String specialRemarks;
  String epilepsy;
  String allergy;
  String vision;
  String age;
  List<VisionDatum> visionData;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    userId: json["User Id"],
    patientId: json["Patient Id"],
    patientName: json["Patient Name"],
    patientContactNumber: json["Patient Contact Number"],
    patientEmailId: json["Patient Email ID"],
    gender: json["Gender"],
    bloodGroup: json["Blood Group"],
    diabetes: json["Diabetes"],
    relationWithUser: json["Relation With User"],
    bloodPressure: json["Blood Pressure"],
    specialRemarks: json["Special Remarks"],
    epilepsy: json["Epilepsy"],
    allergy: json["Allergy"],
    vision: json["Vision"],
    age: json["Age"],
    visionData: List<VisionDatum>.from(json["Vision Data"].map((x) => VisionDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "User Id": userId,
    "Patient Id": patientId,
    "Patient Name": patientName,
    "Patient Contact Number": patientContactNumber,
    "Patient Email ID": patientEmailId,
    "Gender": gender,
    "Blood Group": bloodGroup,
    "Diabetes": diabetes,
    "Relation With User": relationWithUser,
    "Blood Pressure": bloodPressure,
    "Special Remarks": specialRemarks,
    "Epilepsy": epilepsy,
    "Allergy": allergy,
    "Vision": vision,
    "Age": age,
    "Vision Data": List<dynamic>.from(visionData.map((x) => x.toJson())),
  };
}

class VisionDatum {
  VisionDatum({
    required this.left,
    required this.right,
    required this.date,
  });

  String left;
  String right;
  String date;

  factory VisionDatum.fromJson(Map<String, dynamic> json) => VisionDatum(
    left: json["Left"],
    right: json["Right"],
    date: json["Date"],
  );

  Map<String, dynamic> toJson() => {
    "Left": left,
    "Right": right,
    "Date": date,
  };
}

class Settings {
  Settings({
    required this.success,
    required this.message,
    required this.fields,
  });

  String success;
  String message;
  List<String> fields;

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
    success: json["success"],
    message: json["message"],
    fields: List<String>.from(json["fields"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "fields": List<dynamic>.from(fields.map((x) => x)),
  };
}
