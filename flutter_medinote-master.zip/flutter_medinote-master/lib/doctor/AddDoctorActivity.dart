
import 'dart:convert';
import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_medinote/response/AddDoctorResponse.dart';
import 'package:flutter_medinote/utils/AppColors.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:loading_overlay/loading_overlay.dart';

import '../response/SavePatientResponse.dart';
import '../response/SpecialityListingResponse.dart';
import '../utils/CustomAlertSelectionDialog.dart';
import '../utils/EmployeeTypeHelper.dart';
import '../utils/GetEditTextValueHelper.dart';
import '../utils/PreferenceManager.dart';
import '../utils/VariableBag.dart';
import 'package:http/http.dart' as http;

class AddDoctorActivity extends StatefulWidget {
  const AddDoctorActivity({Key? key}) : super(key: key);

  @override
  State<AddDoctorActivity> createState() => _AddDoctorActivityState();
}

class _AddDoctorActivityState extends State<AddDoctorActivity> {

  List<EmployeeTypeHelper> specialityList = [];
  List<GetEditTextValueHelper> arrayList = <GetEditTextValueHelper>[];
  late ScaffoldMessengerState _scaffoldMessengerState;

  final _formkey = GlobalKey<FormState>();
  var drName = null,userId,customerId="",speciality,specialityId,fees="",referece="",city="",area="",contactNo="",location="";

  List<Gender> genders = <Gender>[];
  var strGender = null;
  var _isLoading = false;

  TextEditingController specialityController = TextEditingController();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {userId = value;}));

    genders.add(new Gender("Male", Icons.male, false));
    genders.add(new Gender("Female", Icons.female, false));
    genders.add(new Gender("Others", Icons.transgender, false));

    fetSpecialityData();

  }

  Future fetSpecialityData() async{

    Map data = {
      'customer_id' : "",
      'filtertext' : "",
      'Select_Valuecode' : "",
    };

    final response = await http.post(Uri.parse(BASE_URL+"MobileApp/DrSpecialityListing"),body: data);

    if(response!=null){
      var jsonData = null;
      if(response.statusCode==200){
        jsonData = jsonDecode(response.body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = SpecialityListingResponse.fromJson(map);
        if(response1.settings.success == "1"){
          for(int i=0; i<response1.data.length;i++){
            specialityList.add(EmployeeTypeHelper(response1.data[i].specialityName, response1.data[i].id,"", false,""));
          }
        }else{
          print("fetchHsnCode response success  not arrive");
        }
      }else{
        print("fetchHsnCode response 200 not arrive");
      }
    }else{
      print("fetchHsnCode response null");
    }
  }
  Future checkValidation() async{
    if(_formkey.currentState!.validate()){
      if(strGender!=null ){
        SubmitData();
      }else{
        Fluttertoast.showToast(msg: "Select gender.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    _scaffoldMessengerState = ScaffoldMessenger.of(context);

    return Scaffold(
      backgroundColor: grey_5,
      appBar: AppBar(
        title: Text("Add Doctor"),backgroundColor: PrimaryColor,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 15.0),
            child: InkWell(
                onTap: (){
                  checkValidation();
                },
                child: Icon(Icons.check)),
          ),
        ],),
      body: LoadingOverlay(
        isLoading: _isLoading,
        color: Colors.black54,
        opacity: 0.6,
        child: Container(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              elevation: 4,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: SingleChildScrollView(
                  child: Form(
                    key: _formkey,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        //name
                        TextFormField(
                          decoration: const InputDecoration(
                            labelText: "Doctor Name*",
                            labelStyle: TextStyle(color: PrimaryColor),

                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: grey_20)
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: PrimaryColor),
                            )
                          ),
                          validator: (value){
                            drName = value;
                            if(value==null || value.isEmpty){
                              return 'Enter doctor name';
                            }
                            return null;
                          },
                        ),
                        //speciality
                        TextFormField(
                          readOnly: true,
                          controller: specialityController,
                          decoration: const InputDecoration(
                            labelText: "Speciality*",
                            labelStyle: TextStyle(color: PrimaryColor),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: grey_20),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: PrimaryColor)
                            ),
                            suffixIcon: Icon(Icons.search,color: PrimaryColor,)
                          ),
                          validator: (value){
                            speciality = value;
                            if(value==null || value.isEmpty){
                              return 'Select speciality';
                            }
                            return null;
                          },
                          onTap: (){
                            print("click");
                            openSelectDialog(context,specialityController,specialityList,"Speciality");

                          },
                        ),
                        //Fees
                        TextFormField(
                          decoration: InputDecoration(
                              labelText: "Fees",
                              labelStyle: TextStyle(color: PrimaryColor),
                              enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: grey_20)
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              )
                          ),
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          onChanged: (value){
                            fees = value.toString();
                          },
                        ),
                        //reference
                        TextFormField(
                          decoration: InputDecoration(
                              labelText: "Reference",
                              labelStyle: TextStyle(color: PrimaryColor),

                              enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: grey_20)
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              )
                          ),
                          onChanged: (value){
                            referece = value.toString();
                          },
                        ),
                        //gender
                        SizedBox(height: 10,),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text("Gender*",style: TextStyle(color: PrimaryColor),),
                        ),
                        SizedBox(height: 10,),
                        Container(
                          height: 50,
                          child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              itemCount: genders.length,
                              itemBuilder: (context, index) {
                                return InkWell(
                                  splashColor: Colors.pinkAccent,
                                  onTap: () {
                                    setState(() {
                                      genders.forEach((gender) => gender.isSelected = false);
                                      genders[index].isSelected = true;
                                      strGender = genders[index].name;
                                    });
                                  },
                                  child:  CustomRadio(genders[index]),
                                );
                              }),
                        ),
                        SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_20, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),
                        SizedBox(height: 10,),
                        //city
                        TextFormField(
                          decoration: InputDecoration(
                              labelText: "City",
                              labelStyle: TextStyle(color: PrimaryColor),

                              enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: grey_20)
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              )
                          ),
                          onChanged: (value){
                            city = value.toString();
                          },
                        ),
                        //Area
                        TextFormField(
                          decoration: InputDecoration(
                              labelText: "Area",
                              labelStyle: TextStyle(color: PrimaryColor),

                              enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: grey_20)
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              )
                          ),
                          onChanged: (value){
                            area = value.toString();
                          },
                        ),
                        //Contact no
                        TextFormField(
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly],
                          maxLength: 10,
                          decoration: const InputDecoration(
                              labelText: "Contact No.",
                              labelStyle: TextStyle(color: PrimaryColor),

                              enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: grey_20)
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              )
                          ),
                          onChanged: (value){
                            contactNo = value.toString();
                          },
                        ),

                        //location
                        TextFormField(
                          decoration: InputDecoration(
                              labelText: "Location",
                              labelStyle: TextStyle(color: PrimaryColor),
                              enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: grey_20),
                              ),
                              focusedBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: PrimaryColor)
                              ),
                              suffixIcon: Icon(Icons.location_pin,color: PrimaryColor,)
                          ),
                          onChanged: (value){
                            location = value.toString();
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget CustomRadio(Gender _gender) {
    return Card(
        color: _gender.isSelected ? PrimaryColor : Colors.white,
        child: Container(
          height: 20,
          width: 90,
          alignment: Alignment.center,
          margin: new EdgeInsets.all(5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Icon(
                _gender.icon,
                color: _gender.isSelected ? Colors.white : Colors.grey,
                size: 22,
              ),

              SizedBox(height: 10),

              Text(
                _gender.name,
                style: TextStyle(color: _gender.isSelected ? Colors.white : Colors.grey),
              )
            ],
          ),
        ));
  }

  Future openSelectDialog(BuildContext context, TextEditingController relationController, List<EmployeeTypeHelper> dataList, String idtfDialog) async {
    showDialog(
        context: context,
        builder: (BuildContext context) => CustomAlertSelectionDialog(
          idtfDialog : idtfDialog,
          selectedId: "1",
          selectionList: specialityList,
          doneTitle: "Done",
          cancelTitle: "Cancel",
          position: "1",
          onClick: onSelectionClick,
          onCancel: onSelectionCancel,
          rowClickPos: 0,
          relationController:relationController,));
  }

  onSelectionClick(
      String idtfDialog,
      String selectedId,
      String selectionName,
      String position,
      int rowClickPos,
      TextEditingController relationController,
      String extraStr) {

    specialityController.text = selectionName;
    specialityId = selectedId;
    print(selectedId);
    print(selectionName);
   // Navigator.pop(context, arrayList);




  }

  onSelectionCancel(String p1) {
  }

  Future SubmitData() async{


    setState((){
      _isLoading = true;
    });

    Map data = {
      'customer_id' :  customerId.toString(),
      'user_id' :  userId.toString(),
      'dr_Id' :  "",
      'user_name' :  drName,
      'speciality' :  speciality,
      'type' :  "",
      'fees' :  fees,
      'reference' :  referece,
      'city' :  city,
      'area' :  area,
      'mobile_no' :  contactNo,
      'location' :  location,
      'spyid' :  specialityId,
      'Gender' :  strGender,
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/SaveMediNoteDoctorData"),body: data)
    ]).then((response){

      var jasonData = null;
      setState((){
        _isLoading = false;
      });
      if(response[0].statusCode==200){
        jasonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = AddDoctorResponse.fromJson(map);

        if(response1.settings.success=="1"){
          setState((){
            _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));

            //Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=>ListPatientActivity()));
            Navigator.pop(context,true);
          });
        }else{
          setState((){
            _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
          });
        }
      }else{
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Something went wrong please try again later.")));

      }


    }, onError: (error) {
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(
          msg: error.toString(),
          textColor: Colors.white,
          backgroundColor: Colors.red,
          gravity: ToastGravity.CENTER);
    });
  }

}


class Gender {
  String name;
  IconData icon;
  bool isSelected;

  Gender(this.name, this.icon, this.isSelected);
}

