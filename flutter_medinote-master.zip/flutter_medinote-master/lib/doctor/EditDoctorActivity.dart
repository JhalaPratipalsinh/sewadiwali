
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:loading_overlay/loading_overlay.dart';

import '../response/AddDoctorResponse.dart';
import '../response/CommonResponse.dart';
import '../response/DoctorDetailResponse.dart';
import '../response/SpecialityListingResponse.dart';
import '../utils/AppColors.dart';
import '../utils/CustomAlertSelectionDialog.dart';
import '../utils/EmployeeTypeHelper.dart';
import '../utils/GetEditTextValueHelper.dart';
import '../utils/PreferenceManager.dart';
import '../utils/VariableBag.dart';
import 'package:http/http.dart' as http;

class EditDoctorActivity extends StatefulWidget {
  final String doctorId;
  const EditDoctorActivity(this.doctorId, {Key? key}) : super(key: key);

  @override
  State<EditDoctorActivity> createState() => _EditDoctorActivityState();
}

class _EditDoctorActivityState extends State<EditDoctorActivity> {
  List<EmployeeTypeHelper> specialityList = [];
  List<GetEditTextValueHelper> arrayList = <GetEditTextValueHelper>[];
  late ScaffoldMessengerState _scaffoldMessengerState;
  var dataList;

  final _formkey = GlobalKey<FormState>();

  var drName = null,userId,customerId="",speciality,specialityId,fees="",referece="",city="",area="",contactNo="",location="";
  var isNameEditable =false,isMobileEditable =false,isSpecialityEditable =false,isFeesEditable =false,isReferenceEditable =false,isGenderEditable =false,isCityEditable =false,isAreaEditable =false,isLocationEditable =false;

  List<Gender> genders = <Gender>[];
  var strGender = null,title="";
  var _isLoading = false;
  var isEyeVisible = false,isEditMod = false;

  TextEditingController specialityController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController feesController = TextEditingController();
  TextEditingController referenceController = TextEditingController();
  TextEditingController cityController = TextEditingController();
  TextEditingController areaController = TextEditingController();
  TextEditingController contactNoController = TextEditingController();
  TextEditingController locationController = TextEditingController();

  var myMenuItems = <String>[
    'Edit',
    'Delete',
  ];

  void onSelect(item) {
    switch (item) {
      case 'Edit':
        print('Edit clicked');
        setState(() {
          isEditMod = true;
          disableButton("2");

        });
        break;
      case 'Delete':
        print('Delete clicked');
        alertDeleteDoctorDialog(context);
        break;
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {
      userId = value;
      getDoctorData();
    }));

    genders.add(new Gender("Male", Icons.male, false));
    genders.add(new Gender("Female", Icons.female, false));
    genders.add(new Gender("Others", Icons.transgender, false));

    fetSpecialityData();

    disableButton("1");


  }
  Future fetSpecialityData() async{

    Map data = {
      'customer_id' : "",
      'filtertext' : "",
      'Select_Valuecode' : "",
    };

    final response = await http.post(Uri.parse(BASE_URL+"MobileApp/DrSpecialityListing"),body: data);

    if(response!=null){
      var jsonData = null;
      if(response.statusCode==200){
        jsonData = jsonDecode(response.body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = SpecialityListingResponse.fromJson(map);
        if(response1.settings.success == "1"){
          for(int i=0; i<response1.data.length;i++){
            specialityList.add(EmployeeTypeHelper(response1.data[i].specialityName, response1.data[i].id,"", false,""));
          }
        }else{
          print("fetchHsnCode response success  not arrive");
        }
      }else{
        print("fetchHsnCode response 200 not arrive");
      }
    }else{
      print("fetchHsnCode response null");
    }
  }
  Future getDoctorData() async{
    setState((){
      _isLoading = true;
    });
    Map data = {
      'customer_id' : "",
      'user_id' : userId,
      'dr_Id' : widget.doctorId,
    };

    final response = await http.post(Uri.parse(BASE_URL+"MobileApp/GetMediNoteDoctorProfile"),body: data);

    setState((){
      _isLoading = false;
    });
    if(response!=null){
      var jsonData = null;
      if(response.statusCode==200){
        jsonData = jsonDecode(response.body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = DoctorDetailResponse.fromJson(map);
        if(response1.settings.success == "1"){
          dataList = DoctorDetailResponse.fromJson(map);
          fillData(dataList);
          print("success patient detail");
        }else{
          print("detail response success  not arrive");
        }
      }else{
        print("detail response 200 not arrive");
      }
    }else{
      print("detail response null");
    }
  }
  Future fillData(DoctorDetailResponse doctorDetailResponse) async{

    nameController.text = doctorDetailResponse.data[0].doctorName;
    drName = doctorDetailResponse.data[0].doctorName.toString();

    contactNoController.text = doctorDetailResponse.data[0].doctorContactNumber;
    contactNo = doctorDetailResponse.data[0].doctorContactNumber.toString();

    feesController.text = doctorDetailResponse.data[0].fee;
    fees = doctorDetailResponse.data[0].fee.toString();

    referenceController.text = doctorDetailResponse.data[0].referredBy;
    referece = doctorDetailResponse.data[0].referredBy.toString();

    cityController.text = doctorDetailResponse.data[0].city;
    city = doctorDetailResponse.data[0].city.toString();

    specialityController.text = doctorDetailResponse.data[0].speciality;
    specialityId = doctorDetailResponse.data[0].specificationId.toString();

    areaController.text = doctorDetailResponse.data[0].area;
    area = doctorDetailResponse.data[0].area.toString();

    locationController.text = doctorDetailResponse.data[0].location;
    location = doctorDetailResponse.data[0].location.toString();




    if(doctorDetailResponse.data[0].gender=="Male"){
      genders[0].isSelected = true;
      strGender = "Male";
      setState((){
        CustomRadio(genders[0]);
      });
    }else if(doctorDetailResponse.data[0].gender=="Female"){
      genders[1].isSelected = true;
      strGender = "Female";
      setState((){
        CustomRadio(genders[1]);
      });
    }else{
      genders[2].isSelected = true;
      strGender = "Other";
      setState((){
        print("other...");
        CustomRadio(genders[2]);
      });
    }


  }

  @override
  Widget build(BuildContext context) {
    _scaffoldMessengerState = ScaffoldMessenger.of(context);

    return Scaffold(
      backgroundColor: grey_5,
      appBar: AppBar(
        title: Text(title),backgroundColor: PrimaryColor,
        actions: [
          isEditMod ?
          Padding(
            padding: const EdgeInsets.only(right: 15.0),
            child: InkWell(
                onTap: (){
                  checkValidation();
                },
                child: Icon(Icons.check)),
          ):
          PopupMenuButton<String>(
              onSelected: onSelect,
              itemBuilder: (BuildContext context) {
                return myMenuItems.map((String choice) {
                  return PopupMenuItem<String>(
                    child: Text(choice),
                    value: choice,
                  );
                }).toList();
              })
        ],),
      body: LoadingOverlay(
        isLoading: _isLoading,
        color: Colors.black54,
        opacity: 0.6,
        child: Container(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: SingleChildScrollView(
                  child: Form(
                    key: _formkey,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        //name
                        TextFormField(
                          enabled: isNameEditable,
                          controller: nameController,
                          decoration: const InputDecoration(
                              labelText: "Doctor Name*",
                              labelStyle: TextStyle(color: PrimaryColor),

                              enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: grey_20)
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              )
                          ),
                          validator: (value){
                            drName = value;
                            if(value==null || value.isEmpty){
                              return 'Enter doctor name';
                            }
                            return null;
                          },
                        ),
                        //speciality
                        TextFormField(
                          enabled: isSpecialityEditable,
                          readOnly: true,
                          controller: specialityController,
                          decoration: InputDecoration(
                              labelText: "Speciality*",
                              labelStyle: TextStyle(color: PrimaryColor),
                              enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: grey_20),
                              ),
                              focusedBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: PrimaryColor)
                              ),
                              suffixIcon: Icon(Icons.search,color: PrimaryColor,)
                          ),
                          validator: (value){
                            speciality = value;
                            if(value==null || value.isEmpty){
                              return 'Select speciality';
                            }
                            return null;
                          },
                          onTap: (){
                            print("click");
                            openSelectDialog(context,specialityController,specialityList,"Speciality");

                          },
                        ),
                        //Fees
                        TextFormField(
                          enabled: isFeesEditable,
                          controller: feesController,
                          decoration: InputDecoration(
                              labelText: "Fees",
                              labelStyle: TextStyle(color: PrimaryColor),
                              enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: grey_20)
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              )
                          ),
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          onChanged: (value){
                            fees = value.toString();
                          },
                        ),
                        //reference
                        TextFormField(
                          enabled: isReferenceEditable,
                          controller: referenceController,
                          decoration: InputDecoration(
                              labelText: "Reference",
                              labelStyle: TextStyle(color: PrimaryColor),

                              enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: grey_20)
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              )
                          ),
                          onChanged: (value){
                            referece = value.toString();
                          },
                        ),
                        //gender
                        SizedBox(height: 10,),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text("Gender*",style: TextStyle(color: PrimaryColor),),
                        ),
                        SizedBox(height: 10,),
                        Container(
                          height: 50,
                          child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              itemCount: genders.length,
                              itemBuilder: (context, index) {
                                return InkWell(
                                  /*splashColor: Colors.whit`e,*/
                                  splashFactory: NoSplash.splashFactory,
                                  onTap: () {
                                    if(isGenderEditable){
                                      setState(() {
                                        genders.forEach((gender) => gender.isSelected = false);
                                        genders[index].isSelected = true;
                                        strGender = genders[index].name;
                                      });
                                    }
                                  },
                                  child:  CustomRadio(genders[index]),
                                );
                              }),
                        ),
                        SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_20, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),
                        SizedBox(height: 10,),
                        //city
                        TextFormField(
                          enabled: isCityEditable,
                          controller: cityController,
                          decoration: InputDecoration(
                              labelText: "City",
                              labelStyle: TextStyle(color: PrimaryColor),

                              enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: grey_20)
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              )
                          ),
                          onChanged: (value){
                            city = value.toString();
                          },
                        ),
                        //Area
                        TextFormField(
                          enabled: isAreaEditable,
                          controller: areaController,
                          decoration: InputDecoration(
                              labelText: "Area",
                              labelStyle: TextStyle(color: PrimaryColor),

                              enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: grey_20)
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              )
                          ),
                          onChanged: (value){
                            area = value.toString();
                          },
                        ),
                        //Contact no
                        TextFormField(
                          enabled: isMobileEditable,
                          controller: contactNoController,
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly],
                          maxLength: 10,
                          decoration: const InputDecoration(
                              labelText: "Contact No.",
                              labelStyle: TextStyle(color: PrimaryColor),

                              enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: grey_20)
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              )
                          ),
                          onChanged: (value){
                            contactNo = value.toString();
                          },
                        ),

                        //location
                        TextFormField(
                          enabled: isLocationEditable,
                          controller: locationController,
                          decoration: InputDecoration(
                              labelText: "Location",
                              labelStyle: TextStyle(color: PrimaryColor),
                              enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: grey_20),
                              ),
                              focusedBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: PrimaryColor)
                              ),
                              suffixIcon: Icon(Icons.location_pin,color: PrimaryColor,)
                          ),
                          onChanged: (value){
                            location = value.toString();
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget CustomRadio(Gender _gender) {
    return Card(
        color: _gender.isSelected ? PrimaryColor : Colors.white,
        child: Container(
          height: 20,
          width: 90,
          alignment: Alignment.center,
          margin: new EdgeInsets.all(5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Icon(
                _gender.icon,
                color: _gender.isSelected ? Colors.white : Colors.grey,
                size: 22,
              ),

              SizedBox(height: 10),

              Text(
                _gender.name,
                style: TextStyle(color: _gender.isSelected ? Colors.white : Colors.grey),
              )
            ],
          ),
        ));
  }

  Future openSelectDialog(BuildContext context, TextEditingController relationController, List<EmployeeTypeHelper> dataList, String idtfDialog) async {
    showDialog(
        context: context,
        builder: (BuildContext context) => CustomAlertSelectionDialog(
          idtfDialog : idtfDialog,
          selectedId: "1",
          selectionList: specialityList,
          doneTitle: "Done",
          cancelTitle: "Cancel",
          position: "1",
          onClick: onSelectionClick,
          onCancel: onSelectionCancel,
          rowClickPos: 0,
          relationController:relationController,));
  }

  onSelectionClick(
      String idtfDialog,
      String selectedId,
      String selectionName,
      String position,
      int rowClickPos,
      TextEditingController relationController,
      String extraStr) {

    specialityController.text = selectionName;
    specialityId = selectedId;
    print(selectedId);
    print(selectionName);
    //Navigator.pop(context, arrayList);




  }

  onSelectionCancel(String p1) {
  }

  Future SubmitData() async{


    setState((){
      _isLoading = true;
    });

    Map data = {
      'customer_id' :  customerId.toString(),
      'user_id' :  userId.toString(),
      'dr_Id' : widget.doctorId,
      'user_name' :  drName,
      'speciality' :  speciality,
      'type' :  "",
      'fees' :  fees,
      'reference' :  referece,
      'city' :  city,
      'area' :  area,
      'mobile_no' :  contactNo,
      'location' :  location,
      'spyid' :  specialityId,
      'Gender' :  strGender,
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/SaveMediNoteDoctorData"),body: data)
    ]).then((response){

      var jasonData = null;
      setState((){
        _isLoading = false;
      });
      if(response[0].statusCode==200){
        jasonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = AddDoctorResponse.fromJson(map);

        if(response1.settings.success=="1"){
          setState((){
            _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));

            //Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=>ListPatientActivity()));
            Navigator.pop(context,true);
          });
        }else{
          setState((){
            _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
          });
        }
      }else{
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Something went wrong please try again later.")));

      }


    }, onError: (error) {
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(
          msg: error.toString(),
          textColor: Colors.white,
          backgroundColor: Colors.red,
          gravity: ToastGravity.CENTER);
    });
  }

  Future disableButton(String isEditable) async{
    // 1=disable,2=enable
    if(isEditable=="1"){
      setState((){

        title="Doctor Detail";
        isNameEditable = false;
        isMobileEditable = false;
        isSpecialityEditable = false;
        isFeesEditable = false;
        isReferenceEditable = false;
        isGenderEditable = false;
        isCityEditable = false;
        isAreaEditable = false;
        isLocationEditable = false;
      });

    }else{
      setState((){
        title="Edit Doctor Detail";
        isNameEditable = true;
        isMobileEditable = true;
        isSpecialityEditable = true;
        isFeesEditable = true;
        isReferenceEditable = true;
        isGenderEditable = true;
        isCityEditable = true;
        isAreaEditable = true;
        isLocationEditable = true;
      });
    }
  }

  Future checkValidation() async{
    if(_formkey.currentState!.validate()){
      if(strGender!=null ){
        SubmitData();
      }else{
        Fluttertoast.showToast(msg: "Select gender.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
      }
    }
  }

  Future<bool> alertDeleteDoctorDialog(context) async{
    return await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Container(
              height: 120,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 10.0),
                    child: Text("Are you sure you want to delete this doctor detail?"),
                  ),
                  SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            print('yes selected');
                            Navigator.of(context).pop();
                            DeleteDoctor();
                          },
                          child: Text("Yes"),
                          style: ElevatedButton.styleFrom(primary: Colors.red.shade800),
                        ),
                      ),
                      SizedBox(width: 15),
                      Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              print('no selected');
                              Navigator.of(context).pop();
                            },
                            child: Text("No", style: TextStyle(color: Colors.black)),
                            style: ElevatedButton.styleFrom(
                              primary: Colors.white,
                            ),
                          ))
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }

  Future DeleteDoctor() async{

    setState((){
      _isLoading = true;
    });
    Map data = {
      'customer_id' : "",
      'user_id' : userId,
      'dr_Id' : widget.doctorId,
    };

    final response = await http.post(Uri.parse(BASE_URL+"MobileApp/DeleteMediNoteDoctorData"),body: data);

    setState((){
      _isLoading = true;
    });
    if(response!=null){
      var jsonData = null;
      if(response.statusCode==200){
        jsonData = jsonDecode(response.body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = CommonResponse.fromJson(map);
        if(response1.settings.success == "1"){
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));

          Navigator.pop(context,true);

        }else{
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));

          print(" response success  not arrive");
        }
      }else{
        print("response 200 not arrive");
      }
    }else{
      print("response null");
    }



  }

}


class Gender {
  String name;
  IconData icon;
  bool isSelected;

  Gender(this.name, this.icon, this.isSelected);
}
