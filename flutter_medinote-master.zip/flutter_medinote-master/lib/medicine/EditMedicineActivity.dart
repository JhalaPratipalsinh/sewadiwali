
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:http/http.dart' as http;
import '../response/AddMedicineResponse.dart';
import '../response/CommonResponse.dart';
import '../response/MedicineSingleDataResponse.dart';
import '../utils/AppColors.dart';
import '../utils/PreferenceManager.dart';
import '../utils/VariableBag.dart';

class EditMedicineActivity extends StatefulWidget {
  final String medicineId;
  const EditMedicineActivity(this.medicineId, {Key? key}) : super(key: key);

  @override
  State<EditMedicineActivity> createState() => _EditMedicineActivityState();
}

class _EditMedicineActivityState extends State<EditMedicineActivity> {
  final _formkey = GlobalKey<FormState>();
  var _isLoading = false,title="";

  late ScaffoldMessengerState _scaffoldMessengerState;
  var userId,customerId="", medicineName="",drugName="",manufactureBy="",price="",medicineType="";
  var isNameEditable =false,isDrugNameEditable =false,isManufactureEditable =false,isPriceEditable =false,isMedicineTypeEditable=false;
  var isEditMod = false;
  var dataList;

  TextEditingController medicineNameController = TextEditingController();
  TextEditingController drugNameController = TextEditingController();
  TextEditingController manufactureController = TextEditingController();
  TextEditingController priceController = TextEditingController();

  List<Gender> genders = <Gender>[];
  var strGender = null;

  var myMenuItems = <String>[
    'Edit',
    'Delete',
  ];

  void onSelect(item) {
    switch (item) {
      case 'Edit':
        print('Edit clicked');
        setState(() {
          isEditMod = true;
          disableButton("2");

        });
        break;
      case 'Delete':
        print('Delete clicked');
        alertDeleteDoctorDialog(context);
        break;
    }
  }

  void initState() {
    // TODO: implement initState
    super.initState();

    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {
      userId = value;
      getMedicineData();
    }));

    genders.add(new Gender("Capsule", 'images/ic_capsule__off.png', false));
    genders.add(new Gender("Tablet", 'images/ic_tablet_onn.png', false));
    genders.add(new Gender("ML (Syrup)", 'images/ic_syrup_off.png', false));
    genders.add(new Gender("Others", 'images/ic_other_medicine_off.png', false));

    //fetSpecialityData();

    disableButton("1");

  }

  Future getMedicineData() async{
    setState((){
      _isLoading = true;
    });
    Map data = {
      'customer_id' : "",
      'user_id' : userId,
      'med_Id' : widget.medicineId,
    };

    final response = await http.post(Uri.parse(BASE_URL+"MobileApp/GetMediNoteMedicineData"),body: data);

    setState((){
      _isLoading = false;
    });
    if(response!=null){
      var jsonData = null;
      if(response.statusCode==200){
        jsonData = jsonDecode(response.body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = MedicineSingleDataResponse.fromJson(map);
        if(response1.settings.success == "1"){
          dataList = MedicineSingleDataResponse.fromJson(map);
          fillData(dataList);
          print("success patient detail");
        }else{
          print("detail response success  not arrive");
        }
      }else{
        print("detail response 200 not arrive");
      }
    }else{
      print("detail response null");
    }
  }
  Future fillData(MedicineSingleDataResponse medicineSingleDataResponse) async{

    medicineNameController.text = medicineSingleDataResponse.data[0].medicineName;
    medicineName = medicineSingleDataResponse.data[0].medicineName.toString();

    drugNameController.text = medicineSingleDataResponse.data[0].drugName;
    drugName = medicineSingleDataResponse.data[0].drugName.toString();

    manufactureController.text = medicineSingleDataResponse.data[0].manufacturer;
    manufactureBy = medicineSingleDataResponse.data[0].manufacturer.toString();

    priceController.text = medicineSingleDataResponse.data[0].price;
    price = medicineSingleDataResponse.data[0].price.toString();


    if(medicineSingleDataResponse.data[0].medicineType=="Capsule"){
      genders[0].isSelected = true;
      medicineType = "Capsule";
      setState((){
        CustomRadio(genders[0]);
      });
    }else if(medicineSingleDataResponse.data[0].medicineType=="Tablet"){
      genders[1].isSelected = true;
      medicineType = "Tablet";
      setState((){
        CustomRadio(genders[1]);
      });
    }else if(medicineSingleDataResponse.data[0].medicineType=="ML (Syrup)"){
      genders[2].isSelected = true;
      medicineType = "ML (Syrup)";
      setState((){
        CustomRadio(genders[2]);
      });
    }else{
      genders[3].isSelected = true;
      medicineType = "Other";
      setState((){
        print("other...");
        CustomRadio(genders[3]);
      });
    }


  }

  @override
  Widget build(BuildContext context) {
    _scaffoldMessengerState = ScaffoldMessenger.of(context);

    return Scaffold(
      backgroundColor: grey_5,
      appBar: AppBar(
        title: Text(title),backgroundColor: PrimaryColor,
        actions: [
          isEditMod ?
          Padding(
            padding: const EdgeInsets.only(right: 15.0),
            child: InkWell(
                onTap: (){
                  checkValidation();
                },
                child: Icon(Icons.check)),
          ):
          PopupMenuButton<String>(
              onSelected: onSelect,
              itemBuilder: (BuildContext context) {
                return myMenuItems.map((String choice) {
                  return PopupMenuItem<String>(
                    child: Text(choice),
                    value: choice,
                  );
                }).toList();
              })
        ],),
      body: LoadingOverlay(
        child: Container(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: SingleChildScrollView(
                  child: Form(
                    key: _formkey,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        //medicine name
                        TextFormField(
                          controller: medicineNameController,
                          enabled: isNameEditable,
                          decoration: InputDecoration(
                              labelText: "Medicine Name*",
                              labelStyle: TextStyle(color: PrimaryColor),

                              enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: grey_20)
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              )
                          ),
                          validator: (value){
                            medicineName = value!;
                            if(value==null || value.isEmpty){
                              return 'Enter medicine name';
                            }
                            return null;
                          },
                        ),
                        //drug name
                        TextFormField(
                          controller: drugNameController,
                          enabled: isDrugNameEditable,
                          decoration: InputDecoration(
                              labelText: "Drug Name",
                              labelStyle: TextStyle(color: PrimaryColor),

                              enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: grey_20)
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              )
                          ),
                          onChanged: (value){
                            drugName = value.toString();
                          },
                        ),
                        //manufacture name
                        TextFormField(
                          controller: manufactureController,
                          enabled: isManufactureEditable,
                          decoration: InputDecoration(
                              labelText: "Manufacture By",
                              labelStyle: TextStyle(color: PrimaryColor),

                              enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: grey_20)
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              )
                          ),
                          onChanged: (value){
                            manufactureBy = value.toString();
                          },
                        ),
                        //Fees
                        TextFormField(
                          controller: priceController,
                          enabled: isPriceEditable,
                          decoration: InputDecoration(
                              labelText: "Price",
                              labelStyle: TextStyle(color: PrimaryColor),
                              enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: grey_20)
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              )
                          ),
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          onChanged: (value){
                            price = value.toString();
                          },
                        ),
                        //gender
                        SizedBox(height: 10,),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text("Type of medicine*",style: TextStyle(color: PrimaryColor),),
                        ),
                        SizedBox(height: 10,),
                        Container(
                          height: 80,
                          child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              itemCount: genders.length,
                              itemBuilder: (context, index) {
                                return GestureDetector(
                                  //splashColor: Colors.pinkAccent,
                                  onTap: () {
                                    if(isMedicineTypeEditable) {
                                      setState(() {
                                        genders.forEach((gender) =>
                                        gender.isSelected = false);
                                        genders[index].isSelected = true;
                                        medicineType = genders[index].name;
                                      });
                                    }
                                  },
                                  child:  CustomRadio(genders[index]),
                                );
                              }),
                        ),
                        SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_20, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),
                        SizedBox(height: 10,),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        isLoading: _isLoading,
        color: Colors.black54,
        opacity: 0.6,
      ),

    );
  }
  Future checkValidation() async{
    if(_formkey.currentState!.validate()) {
      if (medicineType != null) {
        SubmitData();
      } else {
        Fluttertoast.showToast(msg: "Select medicine type.",
            textColor: Colors.white,
            backgroundColor: Colors.red,
            gravity: ToastGravity.BOTTOM);
      }
    }
  }

  Future SubmitData() async{
    setState((){
      _isLoading = true;
    });

    Map data = {
      'customer_id' :  customerId.toString(),
      'user_id' :  userId.toString(),
      'med_Id' :  widget.medicineId,
      'med_name' :  medicineName.toString(),
      'med_type' :  medicineType.toString(),
      'drg_name' :  drugName.toString(),
      'mfr' :  manufactureBy.toString(),
      'price' :  price.toString(),
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/SaveMediNoteMedicineData"),body: data)
    ]).then((response){

      var jasonData = null;
      setState((){
        _isLoading = false;
      });
      if(response[0].statusCode==200){
        jasonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = AddMedicineResponse.fromJson(map);

        if(response1.settings.success=="1"){
          setState((){
            _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));

            //Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=>ListPatientActivity()));
            Navigator.pop(context,true);
          });
        }else{
          setState((){
            _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
          });
        }
      }else{
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Something went wrong please try again later.")));

      }


    }, onError: (error) {
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(
          msg: error.toString(),
          textColor: Colors.white,
          backgroundColor: Colors.red,
          gravity: ToastGravity.CENTER);
    });
  }

  Future disableButton(String isEditable) async{
    // 1=disable,2=enable
    if(isEditable=="1"){
      setState((){

        title="Medicine Detail";
        isNameEditable = false;
        isDrugNameEditable = false;
        isManufactureEditable = false;
        isPriceEditable = false;
        isMedicineTypeEditable = false;

      });

    }else{
      setState((){

        title="Edit Medicine Detail";
        isNameEditable = true;
        isDrugNameEditable = true;
        isManufactureEditable = true;
        isPriceEditable = true;
        isMedicineTypeEditable = true;

      });
    }
  }

  Future<bool> alertDeleteDoctorDialog(context) async{
    return await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Container(
              height: 120,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 10.0),
                    child: Text("Are you sure you want to delete this doctor detail?"),
                  ),
                  SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            print('yes selected');
                            Navigator.of(context).pop();
                            DeleteMedicine();
                          },
                          child: Text("Yes"),
                          style: ElevatedButton.styleFrom(primary: Colors.red.shade800),
                        ),
                      ),
                      SizedBox(width: 15),
                      Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              print('no selected');
                              Navigator.of(context).pop();
                            },
                            child: Text("No", style: TextStyle(color: Colors.black)),
                            style: ElevatedButton.styleFrom(
                              primary: Colors.white,
                            ),
                          ))
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }

  Future DeleteMedicine() async{

    setState((){
      _isLoading = true;
    });
    Map data = {
      'customer_id' : "",
      'user_id' : userId,
      'med_Id' : widget.medicineId,
    };

    final response = await http.post(Uri.parse(BASE_URL+"MobileApp/DeleteMediNoteMedicineData"),body: data);

    setState((){
      _isLoading = true;
    });
    if(response!=null){
      var jsonData = null;
      setState((){
        _isLoading = false;
      });
      if(response.statusCode==200){
        jsonData = jsonDecode(response.body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = CommonResponse.fromJson(map);
        if(response1.settings.success == "1"){
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));

          Navigator.pop(context,true);

        }else{
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));

          print(" response success  not arrive");
        }
      }else{
        print("response 200 not arrive");
      }
    }else{
      print("response null");
    }



  }


}

Widget CustomRadio(Gender _gender) {

  return Padding(
    padding: const EdgeInsets.only(left: 18.0,right: 18),
    child: Column(
      mainAxisSize: MainAxisSize.max,
      children: <Widget>[
        Expanded(
          child: Container(
            child: Image.asset(
              _gender.image.toString(),color: _gender.isSelected ? PrimaryColor :grey_20,),
          ),
        ),
        Expanded(child: Padding(
          padding: const EdgeInsets.only(top: 8.0),
          child: Text(_gender.name,style: TextStyle(color: _gender.isSelected ? PrimaryColor :grey_20),),
        )),
      ],
    ),
  );
}

class Gender {
  String name;
  String image;
  bool isSelected;

  Gender(this.name, this.image, this.isSelected);
}
