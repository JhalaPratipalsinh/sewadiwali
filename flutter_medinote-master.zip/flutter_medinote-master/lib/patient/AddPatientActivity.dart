
import 'dart:convert';
import 'dart:ffi';

import 'package:custom_radio_grouped_button/custom_radio_grouped_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_medinote/list/ListPatientActivity.dart';
import 'package:flutter_medinote/response/SavePatientResponse.dart';
import 'package:flutter_medinote/utils/AppColors.dart';
import 'package:flutter_medinote/utils/CustomAlertDialog.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:numberpicker/numberpicker.dart';

import '../response/RelationListResponse.dart';
import '../utils/CustomAlertSelectionDialog.dart';
import '../utils/CustomAlertSelectionImageDialog.dart';
import '../utils/EmployeeTypeHelper.dart';
import '../utils/GetEditTextValueHelper.dart';
import 'package:http/http.dart' as http;

import '../utils/PreferenceManager.dart';
import '../utils/VariableBag.dart';

class AddPatientActivity extends StatefulWidget {
  const AddPatientActivity({Key? key}) : super(key: key);

  @override
  State<AddPatientActivity> createState() => _AddPatientActivityState();
}

class _AddPatientActivityState extends State<AddPatientActivity> {
  final _formkey = GlobalKey<FormState>();
  var name = null,userId,customerId="";
  var mobileno = null;
  var emailId = "";
  var age = null;
  var relation = null;
  var bloodGroup = null;
  var strGender = null;
  var strDiabetes = "No";
  var strBP = "No";
  var strEpliepsy = "No";
  var strAllergy = "No";
  var strVision = "No";
  var strEye = "No";
  var strSpecialRemark = "";

  var _isLoading = false;
  late ScaffoldMessengerState _scaffoldMessengerState;


  var isEyeVisible = false;
  var isAllergyVisible = false;
  List<Gender> genders = <Gender>[];
  List<EmployeeTypeHelper> relationList = [];
  List<EmployeeTypeHelper> bloodGroupList = [];
  List<GetEditTextValueHelper> arrayList = <GetEditTextValueHelper>[];
  TextEditingController _relationController=TextEditingController();
  TextEditingController bloodGroupController = TextEditingController();
  TextEditingController lefEyeController = TextEditingController();
  TextEditingController rightEyeController = TextEditingController();
  TextEditingController allergyController = TextEditingController();
  TextEditingController emailIdController = TextEditingController();
  @override
  void initState() {

    super.initState();
    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {
      userId = value;
    }));

    genders.add(new Gender("Male", Icons.male, false));
    genders.add(new Gender("Female", Icons.female, false));
    genders.add(new Gender("Others", Icons.transgender, false));

    fetRelationData();

    bloodGroupList.add(EmployeeTypeHelper("A+", "1","images/a_positive.png", false,""));
    bloodGroupList.add(EmployeeTypeHelper("A-", "2","images/a_negative.png", false,""));
    bloodGroupList.add(EmployeeTypeHelper("B+", "3","images/b_positive.png", false,""));
    bloodGroupList.add(EmployeeTypeHelper("B-", "4","images/b_negative.png", false,""));
    bloodGroupList.add(EmployeeTypeHelper("AB+", "5","images/ab_positive.png", false,""));
    bloodGroupList.add(EmployeeTypeHelper("AB-", "6","images/ab_negative.png", false,""));
    bloodGroupList.add(EmployeeTypeHelper("O+", "7","images/o_positive.png", false,""));
    bloodGroupList.add(EmployeeTypeHelper("O-", "8","images/o_negative.png", false,""));


  }

  Future fetRelationData() async{

    Map data = {
      'customer_id' : "",
      'filtertext' : "",
      'Select_Valuecode' : "",
    };

    final response = await http.post(Uri.parse(BASE_URL+"MobileApp/RelationList"),body: data);

    if(response!=null){
      var jsonData = null;
      if(response.statusCode==200){
        jsonData = jsonDecode(response.body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = RelationListResponse.fromJson(map);
        if(response1.settings.success == "1"){
          for(int i=0; i<response1.data.length;i++){
            relationList.add(EmployeeTypeHelper(response1.data[i].relationType, response1.data[i].id,"", false,""));
          }
        }else{
          print("fetchHsnCode response success  not arrive");
        }
      }else{
        print("fetchHsnCode response 200 not arrive");
      }
    }else{
      print("fetchHsnCode response null");
    }
  }

  Future checkValidation() async{
    if(_formkey.currentState!.validate()){


        if(strGender!=null ){
          if(isEyeVisible && !isAllergyVisible) {
            if((lefEyeController.text.isNotEmpty && lefEyeController.text.length>0) ||
                rightEyeController.text.isNotEmpty && rightEyeController.text.length>0){
              SubmitData();
            }else{
              Fluttertoast.showToast(msg: "Please enter eye number.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
            }
          }else if(!isEyeVisible && isAllergyVisible){
            if(allergyController.text.isNotEmpty && allergyController.text.length >0){
              SubmitData();
            }else{
              Fluttertoast.showToast(msg: "Please enter allergy.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
            }
          }else if(isEyeVisible && isAllergyVisible){
            if((lefEyeController.text.isNotEmpty && lefEyeController.text.length>0) || rightEyeController.text.isNotEmpty && rightEyeController.text.length>0){
              if(allergyController.text.isNotEmpty && allergyController.text.length >0){
                SubmitData();
              }else{
                Fluttertoast.showToast(msg: "Please enter allergy.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
              }
            }else{
              Fluttertoast.showToast(msg: "Please enter eye number.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
            }
          }else{
            SubmitData();
          }
        }else{
          Fluttertoast.showToast(msg: "Select gender.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
        }

    }
  }

  Future SubmitData() async{

    var mobilenumber = "+91"+mobileno;

    setState((){
      _isLoading = true;
    });

    Map data = {
      'customer_id' :  customerId.toString(),
      'user_id' :  userId.toString(),
      'patient_Id' :  "",
      'user_name' :  name.toString(),
      'email_id' :  emailId.toString(),
      'mobile_no' :  mobilenumber.toString(),
      'gender' :  strGender.toString(),
      'blood_group' :  bloodGroup.toString(),
      'diabetes' :  strDiabetes.toString(),
      'blood_pressure' :  strBP.toString(),
      'special_remarks' :  strSpecialRemark.toString(),
      'relation' :  relation.toString(),
      'epilepsy' :  strEpliepsy.toString(),
      'vision' :  strVision.toString(),
      'allergy' :  strAllergy.toString(),
      'left' :  lefEyeController.text.toString(),
      'right' :  rightEyeController.text.toString(),
      'age' :  age.toString(),
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/SaveMediNotePatientData"),body: data)
    ]).then((response){

      var jasonData = null;
      setState((){
        _isLoading = false;
      });
      if(response[0].statusCode==200){
        jasonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = SavePatientResponse.fromJson(map);

        if(response1.settings.success=="1"){
          setState((){
            _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));

            //Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=>ListPatientActivity()));
            Navigator.pop(context,true);
          });
        }else{
          setState((){
            _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
          });
        }
      }else{
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Something went wrong please try again later.")));

      }


    }, onError: (error) {
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(
          msg: error.toString(),
          textColor: Colors.white,
          backgroundColor: Colors.red,
          gravity: ToastGravity.CENTER);
    });
  }

  @override
  Widget build(BuildContext context) {
    _scaffoldMessengerState = ScaffoldMessenger.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text("Add Patient"),backgroundColor: PrimaryColor,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 15.0),
            child: InkWell(
              onTap: (){
                checkValidation();
              },
                child: Icon(Icons.check)),
          ),
        ],
      ),
      body: LoadingOverlay(
        isLoading: _isLoading,
        color: Colors.black54,
        opacity: 0.6,
        child: Container(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10)),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: SingleChildScrollView(
                  child: Form(
                    key: _formkey,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextFormField(
                          decoration: const InputDecoration(
                            labelText: "Name*",
                            labelStyle: TextStyle(
                              color: PrimaryColor
                            ),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: grey_20),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: PrimaryColor),
                            ),
                          ),
                          validator: (value){
                            name = value;
                            if(name==null || name.isEmpty){
                              return 'Enter name';
                            }
                            return null;
                          },
                        ),
                        //mobile
                        TextFormField(
                          maxLength: 10,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: "Mobile*",
                            labelStyle: TextStyle(
                                color: PrimaryColor
                            ),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: grey_20),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: PrimaryColor),
                            ),
                            suffixIcon: Icon(Icons.perm_contact_cal_rounded,color: PrimaryColor,),
                            counterText: "",
                          ),
                          inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,9}'))],
                          validator: (value){
                            mobileno = value;
                            if(mobileno==null || mobileno.isEmpty || !RegExp(r'^(?:[+0]9)?[0-9]{10}$').hasMatch(mobileno)){
                              return 'Enter valid mobile number.';
                            }
                            return null;
                          },
                        ),
                        //email
                        TextFormField(
                          keyboardType: TextInputType.emailAddress,
                          controller:  emailIdController,
                          decoration: const InputDecoration(
                            labelText: "Email",
                            labelStyle: TextStyle(
                                color: PrimaryColor
                            ),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: grey_20),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: PrimaryColor),
                            ),
                          ),

                          validator: (value){
                            emailId = value!;
                            if(emailId.length>0 &&  !RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(emailId)){
                              return 'Enter valid email id.';
                            }
                            return null;
                          },
                        ),
                        //age
                        TextFormField(
                          keyboardType: TextInputType.number,
                          maxLength: 3,
                          decoration: const InputDecoration(
                            labelText: "Age",
                            labelStyle: TextStyle(
                                color: PrimaryColor
                            ),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: grey_20),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: PrimaryColor),
                            ),
                            counterText: "",
                          ),
                            inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,9}'))],
                          validator: (value){
                            age = value;
                            if(age==null || age.isEmpty){
                              return 'Enter valid age.';
                            }return null;
                          },
                        ),
                        //relation
                        TextFormField(
                          readOnly: true,
                          controller: _relationController,
                          decoration: const InputDecoration(
                              labelText: "Relation*",
                              labelStyle: TextStyle(
                                  color: PrimaryColor
                              ),
                              enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: grey_20),
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              ),
                              suffixIcon: Icon(Icons.search,color: PrimaryColor,)
                          ),
                          validator: (value){
                            relation = value;
                            if(relation==null || relation.isEmpty){
                              return 'Select relation.';
                            }return null;
                          },
                          onTap: (){
                            print("click");
                            openSelectDialog(context,_relationController,"Relation");
                          },
                        ),
                        //blood group
                        TextFormField(
                          readOnly: true,
                          controller: bloodGroupController,
                          decoration: const InputDecoration(
                              labelText: "Blood Group",
                              labelStyle: TextStyle(
                                  color: PrimaryColor
                              ),
                              enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: grey_20),
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              ),
                              suffixIcon: Icon(Icons.search,color: PrimaryColor,)
                          ),
                          onChanged: (value){
                            bloodGroup = value.toString();
                            print("bloodgroup "+bloodGroup);
                          },

                          onTap: (){
                            openSelectImageDialog(context,bloodGroupController);
                          },
                        ),
                        const SizedBox(height: 10,),
                        //gender
                        const Align(
                          alignment: Alignment.centerLeft,
                          child: Text("Gender*",style: TextStyle(color: PrimaryColor),),
                        ),
                        const SizedBox(height: 10,),
                        Container(
                          height: 50,
                          child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              itemCount: genders.length,
                              itemBuilder: (context, index) {
                                return InkWell(
                                  splashColor: Colors.pinkAccent,
                                  onTap: () {
                                    setState(() {
                                      genders.forEach((gender) => gender.isSelected = false);
                                      genders[index].isSelected = true;
                                      strGender = genders[index].name;
                                    });
                                  },
                                  child:  CustomRadio(genders[index]),
                                );
                              }),
                        ),
                        const SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_20, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),
                        SizedBox(height: 10,),
                        //diabitis
                        Container(
                          child: Row(
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                  width:25,height: 25,
                                  child: Image.asset("images/diabetes.png",color: PrimaryColor,),
                                ),
                              ),
                              const Expanded(
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 20.0),
                                    child: Text("Diabetes",style: TextStyle(color: PrimaryColor),),
                                  ),
                                ),
                              ),
                              CustomRadioButton(
                                unSelectedBorderColor: grey_90,
                                selectedBorderColor: PrimaryColor,
                                width: 60,height: 25,
                                elevation: 0,
                                absoluteZeroSpacing: true,
                                unSelectedColor: Colors.white,
                                defaultSelected: "No",
                                buttonLables: const [
                                  'No',
                                  'Yes',
                                ],
                                buttonValues: const [
                                  'No',
                                  'Yes',
                                ],
                                buttonTextStyle: ButtonTextStyle(
                                    selectedColor: Colors.white,
                                    unSelectedColor: grey_60,
                                    textStyle: TextStyle(fontSize: 16)),
                                radioButtonValue: (value) {
                                  print(value);
                                  strDiabetes = value.toString();
                                  print("diabetes"+strDiabetes);
                                },
                                enableShape: true,
                                selectedColor: PrimaryColor,
                              )
                            ],
                          ),
                        ),
                        const SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_20, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),
                        //blood pressure
                        SizedBox(height: 10,),
                        Container(
                          child: Row(
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                  width:25,height: 25,
                                  child: Image.asset("images/bloodgroup3.png",color: PrimaryColor,),
                                ),
                              ),
                              const Expanded(
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 20.0),
                                    child: Text("Blood Pressure",style: TextStyle(color: PrimaryColor),),
                                  ),
                                ),
                              ),
                              CustomRadioButton(
                                unSelectedBorderColor: grey_90,
                                selectedBorderColor: PrimaryColor,
                                width: 60,height: 25,
                                elevation: 0,
                                absoluteZeroSpacing: true,
                                unSelectedColor: Colors.white,
                                defaultSelected: "No",
                                buttonLables: const [
                                  'No',
                                  'Yes',
                                ],
                                buttonValues: const [
                                  'No',
                                  'Yes',
                                ],
                                buttonTextStyle: ButtonTextStyle(
                                    selectedColor: Colors.white,
                                    unSelectedColor: grey_60,
                                    textStyle: TextStyle(fontSize: 16)),
                                radioButtonValue: (value) {
                                  strBP = value.toString();
                                  print(strBP);
                                },
                                enableShape: true,
                                selectedColor: PrimaryColor,
                              )
                            ],
                          ),
                        ),
                        const SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_20, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),
                        //Epilepsy
                        const SizedBox(height: 10,),
                        Container(
                          child: Row(
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                  width:25,height: 25,
                                  child: Image.asset("images/epilepsy.png",color: PrimaryColor,),
                                ),
                              ),
                              const Expanded(
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 20.0),
                                    child: Text("Epilepsy",style: TextStyle(color: PrimaryColor),),
                                  ),
                                ),
                              ),
                              CustomRadioButton(
                                unSelectedBorderColor: grey_90,
                                selectedBorderColor: PrimaryColor,
                                width: 60,height: 25,
                                elevation: 0,
                                absoluteZeroSpacing: true,
                                unSelectedColor: Colors.white,
                                defaultSelected: "No",
                                buttonLables: const [
                                  'No',
                                  'Yes',
                                ],
                                buttonValues: const [
                                  'No',
                                  'Yes',
                                ],
                                buttonTextStyle: const ButtonTextStyle(
                                    selectedColor: Colors.white,
                                    unSelectedColor: grey_60,
                                    textStyle: TextStyle(fontSize: 16)),
                                radioButtonValue: (value) {
                                  strEpliepsy = value.toString();
                                  print(strEpliepsy);
                                },
                                enableShape: true,
                                selectedColor: PrimaryColor,
                              )
                            ],
                          ),
                        ),
                        SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_20, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),
                        //Vision
                        const SizedBox(height: 10,),
                        Container(
                          child: Row(
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                  width:25,height: 25,
                                  child: Image.asset("images/vision.png",color: PrimaryColor,),
                                ),
                              ),
                              const Expanded(
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 20.0),
                                    child: Text("Vision",style: TextStyle(color: PrimaryColor),),
                                  ),
                                ),
                              ),
                              CustomRadioButton(
                                unSelectedBorderColor: grey_90,
                                selectedBorderColor: PrimaryColor,
                                width: 60,height: 25,
                                elevation: 0,
                                absoluteZeroSpacing: true,
                                unSelectedColor: Colors.white,
                                defaultSelected: "No",
                                buttonLables: const [
                                  'No',
                                  'Yes',
                                ],
                                buttonValues: const [
                                  'No',
                                  'Yes',
                                ],
                                buttonTextStyle: ButtonTextStyle(
                                    selectedColor: Colors.white,
                                    unSelectedColor: grey_60,
                                    textStyle: TextStyle(fontSize: 16)),
                                radioButtonValue: (value) {
                                  strVision = value.toString();
                                  print(value);
                                  if(value=="Yes"){
                                    setState((){
                                      isEyeVisible = true;
                                    });
                                  }else{
                                    setState((){
                                      isEyeVisible = false;
                                    });
                                  }
                                },
                                enableShape: true,
                                selectedColor: PrimaryColor,
                              )
                            ],
                          ),
                        ),
                        //rowleftEyeRightEye
                        Visibility(
                          visible: isEyeVisible,
                          child: Padding(
                            padding: const EdgeInsets.only(top: 10,left: 10.0,right: 8.0),
                            child: Row(
                                children: [
                              Flexible(
                                child: TextFormField(
                                  controller: lefEyeController,
                                  readOnly: true,
                                  decoration: const InputDecoration(
                                    hintText: "Left Eye",
                                    suffixIcon: Icon(Icons.arrow_drop_down_outlined),
                                    border: InputBorder.none,
                                  ),
                                  onTap: (){

                                    openSelectNumberDialog(context,lefEyeController,"leftEye");

                                  },
                                ),
                              ),
                              Flexible(
                                child: TextFormField(
                                  readOnly: true,
                                  controller: rightEyeController,
                                  decoration: const InputDecoration(
                                      hintText: "Right Eye",
                                    suffixIcon: Icon(Icons.arrow_drop_down_outlined),
                                    border: InputBorder.none
                                  ),
                                  onTap: (){
                                    openSelectNumberDialog(context,rightEyeController,"rightEye");
                                  },
                                ),
                              ),
                            ]),
                          ),
                        ),
                        SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_20, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),
                        //Allergy
                        SizedBox(height: 10,),
                        Container(
                          child: Row(
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                  width:25,height: 25,
                                  child: Image.asset("images/allergy.png",color: PrimaryColor,),
                                ),
                              ),
                              const Expanded(
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 20.0),
                                    child: Text("Allergy",style: TextStyle(color: PrimaryColor),),
                                  ),
                                ),
                              ),
                              CustomRadioButton(

                                unSelectedBorderColor: grey_90,
                                selectedBorderColor: PrimaryColor,
                                width: 60,height: 25,
                                elevation: 0,
                                absoluteZeroSpacing: true,
                                unSelectedColor: Colors.white,
                                defaultSelected: "No",

                                buttonLables: const [
                                  'No',
                                  'Yes',
                                ],
                                buttonValues: const [
                                  'No',
                                  'Yes',
                                ],
                                buttonTextStyle: const ButtonTextStyle(
                                    selectedColor: Colors.white,
                                    unSelectedColor: grey_60,
                                    textStyle: TextStyle(fontSize: 16)),
                                radioButtonValue: (value) {
                                  print(value);
                                  if(value=="Yes"){
                                    setState((){
                                      isAllergyVisible = true;
                                    });
                                  }else{
                                    setState((){
                                      isAllergyVisible = false;

                                    });
                                  }
                                },
                                enableShape: true,
                                selectedColor: PrimaryColor,
                              )
                            ],
                          ),
                        ),
                        //allergy textformfield
                        Visibility(
                          visible: isAllergyVisible,
                          child: Padding(
                            padding: const EdgeInsets.only(top: 10.0),
                            child: TextFormField(
                              minLines: 4,
                              maxLines: 4,
                              controller: allergyController,
                              keyboardType: TextInputType.multiline,
                              decoration: const InputDecoration(
                                hintText: "Enter Description",
                                fillColor: grey_5,
                                filled: true,
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_20, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),

                        SizedBox(height: 10,),
                        Padding(
                          padding: const EdgeInsets.only(top: 10.0),
                          child: TextFormField(
                            minLines: 2,
                            maxLines: 5,
                            keyboardType: TextInputType.multiline,
                            decoration: InputDecoration(
                                labelText: 'Special Remark',
                                labelStyle: TextStyle(color: PrimaryColor),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: grey_60,width: 1),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide(color: grey_20)
                              )


                            ),
                            onChanged: (value){
                              strSpecialRemark = value;
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget CustomRadio(Gender _gender) {
    return Card(
        color: _gender.isSelected ? PrimaryColor : Colors.white,
        child: Container(
          height: 20,
          width: 90,
          alignment: Alignment.center,
          margin: new EdgeInsets.all(5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Icon(
                _gender.icon,
                color: _gender.isSelected ? Colors.white : Colors.grey,
                size: 22,
              ),

              SizedBox(height: 10),

              Text(
                _gender.name,
                style: TextStyle(color: _gender.isSelected ? Colors.white : Colors.grey),
              )
            ],
          ),
        ));
  }

  Future openSelectDialog(BuildContext context, TextEditingController relationController,String idtfDialog) async {
    showDialog(
        context: context,
        builder: (BuildContext context) => CustomAlertSelectionDialog(
          idtfDialog : idtfDialog,
          selectedId: "1",
          selectionList: relationList,
          doneTitle: "Done",
          cancelTitle: "Cancel",
          position: "1",
          onClick: onSelectionClick,
          onCancel: onSelectionCancel,
          rowClickPos: 0,
          relationController:relationController,));
  }

  onSelectionClick(
      String idtfDialog,
      String selectedId,
      String selectionName,
      String position,
      int rowClickPos,
      TextEditingController relationController,
      String extraStr) {

    relationController.text = selectionName;
    print(selectedId);
    print(selectionName);


  }

  onSelectionCancel(String p1) {
  }


  Future openSelectImageDialog(BuildContext context, TextEditingController bloodGroupController) async {
    showDialog(
        context: context,
        builder: (BuildContext context) => CustomAlertSelectionImageDialog(
          selectedId: "1",
          selectionList: bloodGroupList,
          doneTitle: "Done",
          cancelTitle: "Cancel",
          position: "1",
          arrayList: arrayList,
          onClick: onSelectionClick1,
          onCancel: onSelectionCancel1,
          rowClickPos: 0,
          relationController:bloodGroupController,));
  }

  onSelectionClick1(
      String selectedId,
      String selectionName,
      String position,
      List<GetEditTextValueHelper> arrayList,
      int rowClickPos,
      TextEditingController bloodGroupController) {

    bloodGroupController.text = selectionName;

    print(selectedId);
    print("bg :"+selectionName);
    //Navigator.pop(context, arrayList);

  }

  onSelectionCancel1(String p1) {
  }





  Future openSelectNumberDialog(BuildContext context, TextEditingController lefEyeController, String strName) async {
    showDialog(
        context: context,
        builder: (BuildContext context) => CustomAlertDialog(
          selectedId: "1",
          selectionList: relationList,
          doneTitle: "Done",
          cancelTitle: "Cancel",
          position: "1",
          arrayList: arrayList,
          onClick: onSelectionNumberClick,
          onCancel: onSelectionNumberCancel,
          rowClickPos: 0,
          relationController:lefEyeController,
          strName:strName));
  }

  onSelectionNumberClick(
      String selectedId,
      String selectionName,
      String position,
      List<GetEditTextValueHelper> arrayList,
      int rowClickPos,
      TextEditingController eyeController,
      String positiveMinValue,
      String currentValue,
      String currentValuePoint,
      String strName,
      ) {

    if(strName=="leftEye") {
      lefEyeController.text = '$positiveMinValue $currentValue .$currentValuePoint';
    }else if(strName=="rightEye"){
      rightEyeController.text = '$positiveMinValue $currentValue .$currentValuePoint';
    }

    print(selectedId);
    print(selectionName);
    //Navigator.pop(context, arrayList);




  }

  onSelectionNumberCancel(String p1) {
  }


}




class Gender {
  String name;
  IconData icon;
  bool isSelected;

  Gender(this.name, this.icon, this.isSelected);
}
