
import 'package:flutter/material.dart';

import '../utils/AppColors.dart';

class DemoClass extends StatefulWidget {
  const DemoClass({Key? key}) : super(key: key);

  @override
  State<DemoClass> createState() => _DemoClassState();
}

class _DemoClassState extends State<DemoClass> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Patient"),backgroundColor:PrimaryColor,),
      body: Container(
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              SizedBox(
                height: 20,
              ),
              Center(
                  child: Text(
                    'Rejected',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  )),
              SizedBox(
                height: 10,
              ),

              Material(
                  elevation: 3.0,
                  borderRadius: BorderRadius.circular(30.0),
                  color: Colors.blue,
                  child: MaterialButton(
                    minWidth: MediaQuery.of(context).size.width,
                    padding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
                    onPressed: () async {

                    },child: Text(
                    "ADD NEW",
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                  )
              ),
              SizedBox(
                height: 10,
              ),
              //add this scrollview & ScrollDirection
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Container(
                  child: DataTable(
                    columns: [
                      DataColumn(label: Text('No')),
                      DataColumn(label: Text('PO Ref')),
                      DataColumn(label: Text('Req Ref')),
                      DataColumn(label: Text('Requester')),
                      DataColumn(label: Text('Supplier')),
                      DataColumn(label: Text('Created')),
                      DataColumn(label: Text('By')),
                      DataColumn(label: Text('Delivery')),
                      DataColumn(label: Text('Status')),

                    ],
                    rows: [
                      DataRow(
                          cells: [
                        DataCell(Text('1')),
                        DataCell(Text('Arya')),
                        DataCell(Text('6')),
                        DataCell(Text('Arya')),
                        DataCell(Text('6')),
                        DataCell(Text('Arya')),
                        DataCell(Text('6')),
                        DataCell(Text('Arya')),
                        DataCell(Text('6')),

                      ]),
                      DataRow(cells: [
                        DataCell(Text('2')),
                        DataCell(Text('John')),
                        DataCell(Text('9')),
                        DataCell(Text('John')),
                        DataCell(Text('9')),
                        DataCell(Text('Arya')),
                        DataCell(Text('6')),
                        DataCell(Text('Arya')),
                        DataCell(Text('6')),


                      ]),
                      DataRow(cells: [
                        DataCell(Text('3')),
                        DataCell(Text('Tony')),
                        DataCell(Text('8')),
                        DataCell(Text('Tony')),
                        DataCell(Text('8')),
                        DataCell(Text('Arya')),
                        DataCell(Text('6')),
                        DataCell(Text('Arya')),
                        DataCell(Text('6')),


                      ]),
                    ],
                  ),
                ),
              ),
            ]),
      ),
    );
  }
}
