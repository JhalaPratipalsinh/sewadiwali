
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_medinote/lab/EditBloodPressureActivity.dart';
import 'package:flutter_medinote/lab/EditDiabetesReportActivity.dart';
import 'package:flutter_medinote/response/LabMainDataListingResponse.dart';
import 'package:flutter_medinote/utils/AppColors.dart';
import 'package:flutter_medinote/utils/PreferenceManager.dart';
import 'package:flutter_medinote/utils/VariableBag.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;

import '../lab/AddBloodPressureActivity.dart';
import '../lab/AddDiabetesReportActivity.dart';
import '../utils/LabTypeModelCalss.dart';

class LabFragScreen extends StatefulWidget {
  const LabFragScreen({Key? key}) : super(key: key);

  @override
  State<LabFragScreen> createState() => _LabFragScreenState();
}

class _LabFragScreenState extends State<LabFragScreen> {
  var _isLoading = true;
  var userId,searchText="",customerId="",page_index="1";
  var dataList;
  late ScaffoldMessengerState _scaffoldMessengerState;
  List<LabTypeModelCalss> labList = [];


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _isLoading = true;
    setPreferenceValue();
  }

  setPreferenceValue() async{
    PreferenceManager.instance.getStringValue("userId").then((value) => setState((){
      userId = value;
      getLabData("");
    }));
  }
  @override
  Widget build(BuildContext context) {
    _scaffoldMessengerState = ScaffoldMessenger.of(context);
    return Scaffold(
      backgroundColor: grey_5,
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 15.0,right: 15,top: 10,bottom: 10),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
              ),
              child: TextFormField(
                decoration: InputDecoration(
                  hintText: "Search...",
                  hintStyle: const TextStyle(fontSize: 17),
                  contentPadding: const EdgeInsets.symmetric(vertical: 15,horizontal: 10),
                  prefixIcon: const Icon(Icons.search,color: PrimaryColor,),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: PrimaryColor),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: PrimaryColor),
                  ),
                ),
                onChanged: (value){
                  filterSearchResults(value,dataList);
                },
              ),
            ),

          ),
          Flexible(
            child: _isLoading?const Center(child: CircularProgressIndicator(),)  :dataList!=null?buildList(context,labList): Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Image(
                  height: 100,
                  width:100,
                  image: AssetImage('images/folder.png'),color: PrimaryColor,),
                Align(
                  alignment: Alignment.center,
                  child: Text("No Data Found.",
                  style: TextStyle(color: PrimaryColor,fontFamily: "poppins_regular",fontSize: 20),),
                )
              ],
            ),
          )
        ],
      ),
      floatingActionButton: SpeedDial(
        animatedIcon: AnimatedIcons.menu_close,
        backgroundColor: PrimaryColor,
        overlayColor: Colors.black,
        overlayOpacity: 0.4,
        children: [
          SpeedDialChild(
              child: Image.asset('images/virus.png',color: Colors.white,width: 25,height: 25,),
              label: "Covid",
              backgroundColor: PrimaryColor
          ),
          SpeedDialChild(
              child: Image.asset('images/bloodgroup3.png',color: Colors.white,width: 25,height: 25,),
              label: "Blood Pressure",
              backgroundColor: PrimaryColor,
              onTap: () async {
                final reLoadPage = await Navigator.push(context, MaterialPageRoute(builder: (context) => AddBloodPressureActivity(),));

                if(reLoadPage){
                  setState((){
                    getLabData('');
                  });
                }
              }
          ),
          SpeedDialChild(
            child: Image.asset('images/diabetes.png',width: 25,height: 25,color: Colors.white,),
            label: "Diabetes",
            backgroundColor: PrimaryColor,
            onTap: () async {
              final reLoadPage = await Navigator.push(context, MaterialPageRoute(builder: (context) => AddDiabetesReportActivity(),));

              if(reLoadPage){
                setState((){
                  getLabData('');
                });
              }
            }
          ),
        ],
      ),
    );
  }

  Widget buildList(BuildContext context, List<LabTypeModelCalss> labList) {
    var value = labList;

    return Container(
      child: ListView.builder(
        itemCount: value!=null && value.length>0 ? value.length:0,
        itemBuilder: (context, index) {
          var istestAtshow=false;
          var isBGRandPPBGRshow=false;
          var isSyDiShow=false;
          var isDiabetes = false;

          if(value[index].strlabType.toString()=='Blood Pressure'){
            istestAtshow = true;
            isBGRandPPBGRshow = false;
            isSyDiShow = true;
            isDiabetes = false;
          }else{
            istestAtshow = false;
            isBGRandPPBGRshow = true;
            isSyDiShow = false;
            isDiabetes= true;
          }

          return Padding(
            padding: const EdgeInsets.only(left: 15.0,right: 15,top: 10,bottom: 10),
            child: InkWell(
              onTap: () async {

                if(value[index].strlabType=='Diabetes'){
                  final isReaload =  await Navigator.push(context, MaterialPageRoute(builder: (context) => EditDiabetesReportActivity(value[index].strReportId.toString(),value[index]),));
                  if(isReaload){
                    getLabData('');
                  }
                }else{
                  final isReaload =  await Navigator.push(context, MaterialPageRoute(builder: (context) => EditBloodPressureActivity(value[index].strReportId.toString(),value[index]),));
                  if(isReaload){
                    getLabData('');
                  }

                }
                              },
              child: Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration:  BoxDecoration(
                              color: isDiabetes?orange:blood_group_code,
                              borderRadius: const BorderRadius.only(topLeft:Radius.circular(10),bottomRight: Radius.circular(10)),
                            ),
                            child: Text(value[index].strlabType.toString(),style: const TextStyle(color: Colors.white),),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(right: 5.0,top: 5),
                            child: Container(
                              padding: const EdgeInsets.all(3),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                border: const Border(
                                  top: BorderSide(color: Colors.grey,width: 1),
                                    bottom:  BorderSide(color: Colors.grey,width: 1),
                                    right: BorderSide(color: Colors.grey,width: 1),
                                    left: BorderSide(color: Colors.grey,width: 1)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children:  [
                                  const Icon(Icons.calendar_month_outlined,color: PrimaryColor,),
                                  Text(value[index].strdate.toString()),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children:  [
                            const Text("Patient",style: TextStyle(fontWeight: FontWeight.bold),),
                            const SizedBox(height: 5,),
                            Text(value[index].strpatient.toString(),style: TextStyle(fontWeight: FontWeight.normal),),
                            const SizedBox(height: 5,),


                            Visibility(
                              visible: istestAtshow,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const SizedBox(height: 5,),
                                  const Text("Test at",style: TextStyle(fontWeight: FontWeight.bold),),
                                  const SizedBox(height: 5,),
                                  Text(value[index].strTestAt.toString(),style: const TextStyle(fontWeight: FontWeight.normal),),
                                  const SizedBox(height: 10,),
                                ],
                              ),
                            ),

                            const Text("Laboratory",style: TextStyle(fontWeight: FontWeight.bold),),
                            const SizedBox(height: 5,),
                            Text(value[index].strlaboratory.toString(),style: const TextStyle(fontWeight: FontWeight.normal),),
                            const SizedBox(height: 10,),

                            Visibility(
                              visible: isBGRandPPBGRshow,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text("Blood Glucose Result",style: TextStyle(fontWeight: FontWeight.bold),),
                                  const SizedBox(height: 5,),
                                  Text(value[index].strbloodGlucoseResult.toString(),style: const TextStyle(fontWeight: FontWeight.normal),),
                                  const SizedBox(height: 10,),
                                  const Text("Post Prandial Blood Glucose after 1hr result",style: TextStyle(fontWeight: FontWeight.bold),),
                                  const SizedBox(height: 5,),
                                  Text(value[index].strpostPrandialBloodGluAfter.toString(),style: const TextStyle(fontWeight: FontWeight.normal),),
                                ],
                              ),
                            ),
                            Visibility(
                              visible: isSyDiShow,
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Text("Systolic",style: TextStyle(fontWeight: FontWeight.bold),),
                                        const SizedBox(height: 5,),
                                        Text(value[index].strSystolic.toString()),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Text("Diastolic",style: TextStyle(fontWeight: FontWeight.bold),),
                                        const SizedBox(height: 5,),
                                        Text(value[index].strDiastolic.toString()),
                                      ],
                                    ),
                                  ),

                                ],
                              ),
                            ),



                          ],
                        ),
                      )

                    ],
                  )),
            ),
          );
      },),
    );
  }

  Future getLabData(String search) async {

    Map data = {
      'customer_id' : customerId,
      'User_Id' : userId,
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/MediNoteLABDATAListing"),body:data)
    ]).then((response) {
      var jsonData = null;

      if(mounted){
        setState((){
          _isLoading = false;
        });
        if(response[0].statusCode==200){
          jsonData = jsonDecode(response[0].body);
          var map = Map<String,dynamic>.from(jsonData);
          var response1 = LabMainDataListingResponse.fromJson(map);

          if(response1.settings.success=="1"){
            dataList = LabMainDataListingResponse.fromJson(map);
            labList.clear();
            if(response1.labdata.isNotEmpty && response1.labdata.length>0 ){
              if(response1.labdata[0].labdata.diabetes!=null && response1.labdata[0].labdata.diabetes.length>0){
                for(int i=0; i<response1.labdata[0].labdata.diabetes.length; i++){

                labList.add(LabTypeModelCalss(
                    response1.labdata[0].labdata.diabetes[i].reportType,
                    response1.labdata[0].labdata.diabetes[i].reportType,
                    response1.labdata[0].labdata.diabetes[i].reportId,
                    response1.labdata[0].labdata.diabetes[i].patientName,
                    response1.labdata[0].labdata.diabetes[i].patientId,
                    response1.labdata[0].labdata.diabetes[i].testDate,
                    response1.labdata[0].labdata.diabetes[i].laboratoryName,
                    response1.labdata[0].labdata.diabetes[i].laboratoryId,
                    response1.labdata[0].labdata.diabetes[i].bloodGlucoseResult,
                    response1.labdata[0].labdata.diabetes[i].postPrandialBloodGlucoseAfter1HrResult,
                    response1.labdata[0].labdata.diabetes[i].urineAcetoneResult,
                    "",
                    "",
                    ""));
                }

                for(int i=0; i<response1.labdata[0].labdata.bp.length; i++){

                labList.add(LabTypeModelCalss(
                    response1.labdata[0].labdata.bp[i].reportType,
                    response1.labdata[0].labdata.bp[i].reportType,
                    response1.labdata[0].labdata.bp[i].reportId,
                    response1.labdata[0].labdata.bp[i].patientName,
                    response1.labdata[0].labdata.bp[i].patientId,
                    response1.labdata[0].labdata.bp[i].testDate,
                    response1.labdata[0].labdata.bp[i].laboratoryName,
                    response1.labdata[0].labdata.bp[i].laboratoryId,
                    "",
                    "",
                    "",
                    response1.labdata[0].labdata.bp[i].testAt,
                    response1.labdata[0].labdata.bp[i].systolicResult,
                    response1.labdata[0].labdata.bp[i].diastolicResult));
                }
              }
            }else{
              labList.clear();
            }
          }else{
            setState((){
              dataList = null;
            });
          }
        }else{
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Somthing went wrong please try again later.")));
        }
      }
    },onError: (error){
      Fluttertoast.showToast(msg: error.toString(),backgroundColor: Colors.red,gravity:ToastGravity.CENTER );

    });
  }
  Future filterSearchResults(String value, dataList, ) async{

    if(value.isNotEmpty){

      if(value.length>0){

        getLabData(value);
      }else{
        getLabData("");
      }
    }else{
      getLabData("");
    }
  }

}
