
import 'package:flutter/material.dart';
import 'package:flutter_medinote/list/ListDiseaseActivity.dart';
import 'package:flutter_medinote/list/ListDoctorActivity.dart';
import 'package:flutter_medinote/list/ListMedicineActivity.dart';
import 'package:flutter_medinote/list/ListPatientActivity.dart';

import '../list/ListLabActivity.dart';

class ListFragScreen extends StatefulWidget {
  const ListFragScreen({Key? key}) : super(key: key);

  @override
  State<ListFragScreen> createState() => _ListFragScreenState();
}

class _ListFragScreenState extends State<ListFragScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
            children: [
          //patient
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: InkWell(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => ListPatientActivity(),));
              },
              child: Stack(
                  alignment: Alignment.center,
                  children: <Widget>[
                    Card(
                      semanticContainer: true,
                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      child: Image.asset(
                        'images/patient.png',
                        fit: BoxFit.fill,
                      ),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26.0),),
                      elevation: 5,
                      margin: EdgeInsets.all(0),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 30.0),
                      child: Align(
                        alignment: Alignment.topLeft,
                          child: Text("Patient",
                            style: TextStyle(
                              fontSize: 35,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),)),
                    ),
                  ]
              ),
            ),
          ),
          //disease
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>ListDiseaseActivity()));
              },
              child: Stack(
                  alignment: Alignment.center,
                  children: <Widget>[
                    Card(
                      semanticContainer: true,
                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      child: Image.asset(
                        'images/disease.png',
                        fit: BoxFit.fill,
                      ),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26.0),),
                      elevation: 5,
                      margin: EdgeInsets.all(0),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 30.0),
                      child: Align(
                          alignment: Alignment.topRight,
                          child: Text("Disease",
                            style: TextStyle(
                                fontSize: 35,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),)),
                    ),

                  ]
              ),
            ),
          ),
          //doctor
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => ListDoctorActivity(),));
              },
              child: Stack(
                  alignment: Alignment.center,
                  children: <Widget>[
                    Card(
                      semanticContainer: true,
                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      child: Image.asset(
                        'images/doctor_1.png',
                        fit: BoxFit.fill,
                      ),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26.0),),
                      elevation: 5,
                      margin: EdgeInsets.all(0),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 30.0),
                      child: Align(
                          alignment: Alignment.topLeft,
                          child: Text("Doctor",
                            style: TextStyle(
                                fontSize: 35,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),)),
                    ),
                  ]
              ),
            ),
          ),
          //medicine
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => ListMedicineActivity(),));
              },
              child: Stack(
                  alignment: Alignment.center,
                  children: <Widget>[
                    Card(
                      semanticContainer: true,
                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      child: Image.asset(
                        'images/medicine_banner.png',
                        fit: BoxFit.fill,
                      ),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26.0),),
                      elevation: 5,
                      margin: EdgeInsets.all(0),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 30.0),
                      child: Align(
                          alignment: Alignment.topRight,
                          child: Text("Medicine",
                            style: TextStyle(
                                fontSize: 35,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),)),
                    ),

                  ]
              ),
            ),
          ),
          //Laboratory
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => ListLabActivity(),));
              },
              child: Stack(
                  alignment: Alignment.center,
                  children: <Widget>[
                    Card(
                      semanticContainer: true,
                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      child: Image.asset(
                        'images/patient.png',
                        fit: BoxFit.fill,
                      ),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26.0),),
                      elevation: 5,
                      margin: EdgeInsets.all(0),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 30.0),
                      child: Align(
                          alignment: Alignment.topLeft,
                          child: Text("Laboratory",
                            style: TextStyle(
                                fontSize: 35,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),)),
                    ),
                  ]
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
