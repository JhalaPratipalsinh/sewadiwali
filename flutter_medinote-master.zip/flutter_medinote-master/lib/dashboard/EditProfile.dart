
import 'dart:convert';
import 'dart:developer';
import 'dart:io' as Io;

import 'dart:io';
import 'dart:typed_data';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:image_picker/image_picker.dart';
import 'package:custom_radio_grouped_button/custom_radio_grouped_button.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:http/http.dart' as http;

import '../main.dart';
import '../response/AddVisionDataResponse.dart';
import '../response/CommonResponse.dart';
import '../response/GetprofileResponse.dart';
import '../response/ImageUpdateResponse.dart';
import '../response/SaveUserDataResponse.dart';
import '../response/RelationListResponse.dart';
import '../response/SavePatientResponse.dart';
import '../response/VisionListResponse.dart';
import '../utils/AppColors.dart';
import '../utils/CustomAlertDialog.dart';
import '../utils/CustomAlertSelectionDialog.dart';
import '../utils/CustomAlertSelectionImageDialog.dart';
import '../utils/EmployeeTypeHelper.dart';
import '../utils/GetEditTextValueHelper.dart';
import '../utils/PreferenceManager.dart';
import '../utils/VariableBag.dart';
import 'DashBoardActivity.dart';

class EditProfile extends StatefulWidget {
  const EditProfile({Key? key}) : super(key: key);


  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {


  final _formkey = GlobalKey<FormState>();
  var isNameEditable =false,isMobileEditable =false,isEmailEditable =false,isAgeEditable =false,isRelationEditable =false,isBloodGrpEditable =false,isGenderEditable =false,isLeftEyeEditable =false,isRightEyeEditable =false,isVisionAddDataEnable =false,isVisionDeleteEditable =false,isAllergyDesEditable =false,isSpecialRemarkEditable =false;
  bool isDiabetesEditable =true,isBPEditable =true,isEpliepsyEditable =true,isVisionEditable =true,isAllergyEditable =true;
  var name = null,userId,customerId="";
  var mobileno = null;
  var emailId = "",title="",age = "",relation = null,bloodGroup = null,strGender = null;
  var strDiabetes = "No" ;
  var strBP = "No";
  var strEpliepsy = "No";
  var strAllergy = "No";
  var strVision = "No";
  var strEye = "No";
  var strSpecialRemark = "";
  var isVisionDataShow = false;
  var isVisionTableVisible = false;
  var _isLoading = false;
  late ScaffoldMessengerState _scaffoldMessengerState;
  var dataList;
  var dataVisionList;
  var isEyeVisible = false,
      isEditMod = true;
  var isAllergyVisible = false;
  List<Gender> genders = <Gender>[];
  List<EmployeeTypeHelper> relationList = [];
  List<EmployeeTypeHelper> bloodGroupList = [];
  List<GetEditTextValueHelper> arrayList = <GetEditTextValueHelper>[];
  TextEditingController _relationController = TextEditingController();
  TextEditingController bloodGroupController = TextEditingController();
  TextEditingController lefEyeController = TextEditingController();
  TextEditingController rightEyeController = TextEditingController();
  TextEditingController allergyController = TextEditingController();
  TextEditingController emailIdController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  TextEditingController ageController = TextEditingController();
  TextEditingController specialController = TextEditingController();
  var profile_responce;
  var myMenuItems = <String>[
    'Edit',
    'Delete'
  ];
  var Mob,email,gender,isLoading = false,patientId;
  void onSelect(item) {
    switch (item) {
      case 'Edit':
        print('Edit clicked');
        setState(() {
          isEditMod = true;
          disableButton("0");
        });
        break;
      case 'Delete':
        if (kDebugMode) {
          print('Delete clicked');
        }
        alertDeletePatientDialog(context);
        break;
    }
  }
  var img64, tempImage;

  Uint8List? _pickedImage;
  @override
  void initState() {
    isLoading = false;
    super.initState();

    PreferenceManager.instance.getStringValue("mobileno").then((value) => setState(() {
      Mob = value;
    }));
    PreferenceManager.instance.getStringValue("uesrEmail").then((value) => setState(() {
      email = value;
    }));
    PreferenceManager.instance.getStringValue("userName").then((value) => setState(() {
      name = value;
    }));
    PreferenceManager.instance.getStringValue("userGender").then((value) => setState(() {
      gender = value;
    }));
    PreferenceManager.instance.getStringValue("userRelation").then((value) => setState(() {
      relation = value;
        }));
    PreferenceManager.instance.getStringValue("Patient Id").then((value) => setState(() {
      patientId = value;
        }));


    PreferenceManager.instance.getStringValue("userId").then((value) =>
        setState(() {
          userId = value;
          _profileData();
           getVisionData();
        }));


    genders.add(Gender("Male", Icons.male, false));
    genders.add(Gender("Female", Icons.female, false));
    genders.add(Gender("Others", Icons.transgender, false));

    fetRelationData();

    bloodGroupList.add(EmployeeTypeHelper("A+", "1","images/a_positive.png", false,""));
    bloodGroupList.add(EmployeeTypeHelper("A-", "2","images/a_negative.png", false,""));
    bloodGroupList.add(EmployeeTypeHelper("B+", "3","images/b_positive.png", false,""));
    bloodGroupList.add(EmployeeTypeHelper("B-", "4","images/b_negative.png", false,""));
    bloodGroupList.add(EmployeeTypeHelper("AB+", "5","images/ab_positive.png", false,""));
    bloodGroupList.add(EmployeeTypeHelper("AB-", "6","images/ab_negative.png", false,""));
    bloodGroupList.add(EmployeeTypeHelper("O+", "7","images/o_positive.png", false,""));
    bloodGroupList.add(EmployeeTypeHelper("O-", "8","images/o_negative.png", false,""));

    disableButton("1");

  }
  void imagePickerOption() {
    showDialog(
        context: context,
        builder: (BuildContext context) => AlertDialog(
          shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(15))),
          actions: [
            Container(
              child: SingleChildScrollView(
                child: ClipRRect(
                  borderRadius: BorderRadius.all(Radius.circular(15)),
                  child: Container(
                    color: Colors.white,
                    // height: MediaQuery.of(context).size.height / 4,
                    child: Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const Text(
                            "Pic Image From",
                            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                                primary: Colors.orange),
                            onPressed: () {
                              pickImage(ImageSource.camera, imageQuality: 1, maxHeight: 1, maxWidth: 1);
                            },
                            icon: const Icon(Icons.camera),
                            label: const Text("CAMERA"),
                          ),
                          ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                                primary: Colors.orange),
                            onPressed: () {
                              pickImage(ImageSource.gallery,
                                  imageQuality: 3,
                                  maxHeight: 3,
                                  maxWidth: 3);
                            },
                            icon: const Icon(
                              Icons.image,
                            ),
                            label: const Text("GALLERY"),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                                primary: Color(0xFF555555)),
                            onPressed: () {
                              Get.back();
                            },
                            icon: const Icon(Icons.close),
                            label: const Text("CANCEL"),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            )
          ],
        ));
  }

  pickImage(ImageSource imageType, {
    required int imageQuality, required int maxHeight, required int maxWidth}) async {
    try {
      final photo = await ImagePicker().pickImage(source: imageType);

      if (photo == null) return;
      log('Photo path ${photo.path}');
      setState(() {
        tempImage = File(photo.path);
      });

      final text = photo.path;

      RegExp exp = new RegExp(r'(?:(?:https?|ftp):)?[\w/\-?=%.]+\.[\w/\-?=%.]+');
      Iterable<RegExpMatch> matches = exp.allMatches(text);

      matches.forEach((match) {
        print(text.substring(match.start, match.end));
      });

      final bytes = Io.File("$text").readAsBytesSync();
      img64 = base64Encode(bytes);
      print("$img64");

      setState(() {
        _pickedImage = Uint8List.fromList(File(photo.path).readAsBytesSync());
         _imgData(img64);
      });

      Navigator.pop(context);
    } catch (error) {
      debugPrint(error.toString());
    }
  }
  Future<void> _imgData(img64) async {
    Map data = {
      "customer_id": "",
      "user_id": userId.toString(),
      "Image_Path": img64,
    };
    print(data.toString());
    final imgResponse = await http.post(
      Uri.parse(
          "https://safal.datanote.co.in/api/medinote/MobileApp/UpdateMediNoteUserProfileImage"),
      body: data,
    );
    setState(() {
      isLoading = false;
    });
    var jsonData = null;
    if (imgResponse.statusCode == 200) {
      jsonData = json.decode(imgResponse.body);
      var map = Map<String, dynamic>.from(jsonData);
      var imageResponse = ImageUpdateResponse.fromJson(map);
      print(imageResponse.settings.message);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Picture update successfully"),
      ));
      PreferenceManager.instance.setStringValue(
        "image_path1",
        img64,
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Something Wrong"),));
    }
  }
  Future<void> _profileData() async {
    Map data = {
      "user_id": userId,
      "customer_id": "",
      "mobile_no": Mob,
      "email": email,
    };
    print(data.toString());
    final profiledata = await http.post(
      Uri.parse(
          "https://safal.datanote.co.in/api/medinote/MobileApp/GetMediNoteUserProfile"),
      body: data,
    );
    setState(() {
      isLoading = false;
    });
    var jsonData = null;
    if (profiledata.statusCode == 200) {
      jsonData = json.decode(profiledata.body);
      var map = Map<String, dynamic>.from(jsonData);
       profile_responce =GetprofileResponse.fromJson(map);
      print(profile_responce.settings.message);
      if (profile_responce.settings.success == '1') {
        dataList =GetprofileResponse.fromJson(map);
        fillData(dataList);
        PreferenceManager.instance.setStringValue("Patient Id", profile_responce.data[0].patientId);
        print(">>>>>>>>>>"+patientId);
        //ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(profile_responce.settings.message), backgroundColor: Colors.orange,));
      } else {
        Fluttertoast.showToast(msg: "Something Wrong", backgroundColor: Colors.red, textColor: Colors.white,);
        print("err");
      }
    }
  }
  Future fetRelationData() async{

    Map data = {
      'customer_id' : "",
      'filtertext' : "",
      'Select_Valuecode' : "",
    };

    final response = await http.post(Uri.parse(BASE_URL+"MobileApp/RelationList"),body: data);

    if(response!=null){
      var jsonData = null;
      if(response.statusCode==200){
        jsonData = jsonDecode(response.body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = RelationListResponse.fromJson(map);
        if(response1.settings.success == "1"){
          for(int i=0; i<response1.data.length;i++){
            relationList.add(EmployeeTypeHelper(response1.data[i].relationType, response1.data[i].id,"", false,""));
          }
        }else{
          print("fetchHsnCode response success  not arrive");
        }
      }else{
        print("fetchHsnCode response 200 not arrive");
      }
    }else{
      print("fetchHsnCode response null");
    }
  }

  Future getVisionData() async{

    Map data = {
      'customer_id' : "",
      'user_id' : userId,
      'patient_Id' : patientId,
    };

    final response = await http.post(Uri.parse("${BASE_URL}MobileApp/GetMediNoteVisionData"),body: data);

    if(response!=null){
      var jsonData = null;
      if(response.statusCode==200){
        jsonData = jsonDecode(response.body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = VisionListResponse.fromJson(map);
        if(response1.settings.success == "1"){
          print("Vision Data:-"+response1.settings.success);
          setState((){
            dataVisionList = VisionListResponse.fromJson(map);
          });
        }else{
          setState((){
            dataVisionList = null;
          });
          print("Vision  response success  not arrive");
        }
      }else{
        print("vision response 200 not arrive");
      }
    }else{
      print("vison response null");
    }
  }
  Future submitVisonData() async{

    if(lefEyeController.text.toString()!=null && lefEyeController.text.toString().trim().length>0){
      if(rightEyeController.text.toString()!=null && rightEyeController.text.toString().trim().length>0){

        Map data = {
          'customer_id' : "",
          'user_id' : userId,
          'patient_Id' : patientId,
          'left' : lefEyeController.text.toString(),
          'right' : rightEyeController.text.toString(),
        };

        final response = await http.post(Uri.parse("${BASE_URL}MobileApp/SaveMediNoteVisionData"),body: data);

        if(response!=null){
          var jsonData = null;
          if(response.statusCode==200){
            jsonData = jsonDecode(response.body);
            var map = Map<String,dynamic>.from(jsonData);
            var response1 = AddVisionDataResponse.fromJson(map);
            if(response1.settings.success == "1"){
              print("submit Vison Success");
              _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: const TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
              getVisionData();
            }else{
              print("add Vision  response success  not arrive");
            }
          }else{
            print("add vision response 200 not arrive");
          }
        }else{
          print("add vison response null");
        }
      }else{
        _scaffoldMessengerState.showSnackBar(const SnackBar(content: Text("Enter right eye number", style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
      }
    }else{
      _scaffoldMessengerState.showSnackBar(const SnackBar(content: Text("Enter left eye number", style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
    }

  }
  Future  DeleteVisionData(String visionId) async{
    setState(() {
      _isLoading = true;
    });
    Map data = {
      'customer_id' : "",
      'user_id' : userId,
      'patient_Id' : patientId,
      'vision_id' : visionId,
    };

    final response = await http.post(Uri.parse(BASE_URL+"MobileApp/DeleteMediNoteVisionData"),body: data);
    setState(() {
      _isLoading = false;
    });
    if(response!=null){
      var jsonData = null;
      if(response.statusCode==200){
        jsonData = jsonDecode(response.body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = AddVisionDataResponse.fromJson(map);
        if(response1.settings.success == "1"){
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: const TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
          getVisionData();
          //Navigator.of(context).pop();
        }else{
          print("add Vision  response success  not arrive");
        }
      }else{
        print("add vision response 200 not arrive");
      }
    }else{
      print("add vison response null");
    }
  }
  Future DeletePatient() async{

    setState((){
      _isLoading = true;
    });
    Map data = {
      'customer_id' : "",
      'user_id' : userId,
      'patient_Id' : patientId,
    };

    final response = await http.post(Uri.parse(BASE_URL+"MobileApp/DeleteMediNotePatientData"),body: data);

    setState((){
      _isLoading = true;
    });
    if(response!=null){
      var jsonData = null;
      if(response.statusCode==200){
        jsonData = jsonDecode(response.body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = CommonResponse.fromJson(map);
        if(response1.settings.success == "1"){
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: const TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
          Navigator.pop(context,true);
        }else{
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: const TextStyle(fontFamily: "poppins_regular",fontSize: 14))));

          print("add Vision  response success  not arrive");
        }
      }else{
        print("add vision response 200 not arrive");
      }
    }else{
      print("add vison response null");
    }



  }

  Future fillData(GetprofileResponse getprofileResponse) async{

    nameController.text = getprofileResponse.data[0].userName;
    name = getprofileResponse.data[0].userName.toString();

    var mno = getprofileResponse.data[0].contactNumber.toString();
    var monumber = mno.substring(3);
    print("monumber : "+monumber);
    mobileController.text = monumber;
    mobileno = monumber;

    emailIdController.text = getprofileResponse.data[0].emailId;
    emailId = getprofileResponse.data[0].emailId.toString();

    ageController.text = getprofileResponse.data[0].age;
    age = getprofileResponse.data[0].age.toString();

    _relationController.text = getprofileResponse.data[0].relation;
    relation = getprofileResponse.data[0].relation.toString();

    bloodGroupController.text = getprofileResponse.data[0].bloodGroup;
    bloodGroup = getprofileResponse.data[0].bloodGroup.toString();

    specialController.text = getprofileResponse.data[0].specialRemarks;
    strSpecialRemark = getprofileResponse.data[0].specialRemarks.toString();

    allergyController.text = getprofileResponse.data[0].allergy;
    strAllergy = getprofileResponse.data[0].allergy.toString();

    setState((){

      _pickedImage = Base64Decoder().convert(getprofileResponse.data[0].profilePhoto);

      strDiabetes = getprofileResponse.data[0].diabetes.toString();
      strBP = getprofileResponse.data[0].bloodPressure.toString();
      strEpliepsy = getprofileResponse.data[0].epilepsy.toString();
      strVision = getprofileResponse.data[0].vision.toString();
      if(strVision=="Yes"){
        isEyeVisible = true;
      }else{
        isEyeVisible = false;
      }
      strAllergy = getprofileResponse.data[0].allergy.toString();
      if(strAllergy=="Yes"){
        isAllergyVisible = true;
      }else{
        isAllergyVisible = false;
      }
    });


    if(getprofileResponse.data[0].gender=="Male"){
      genders[0].isSelected = true;
      strGender = "Male";
      setState((){
        CustomRadio(genders[0]);
      });
    }else if(getprofileResponse.data[0].gender=="Female"){
      genders[1].isSelected = true;
      strGender = "Female";
      setState((){
        CustomRadio(genders[1]);
      });
    }else{
      genders[2].isSelected = true;
      strGender = "Other";
      setState((){
        print("other...");
        CustomRadio(genders[2]);
      });
    }


  }



  Future SubmitData() async{

    var mobilenumber = "+91"+mobileno;

    setState((){
      _isLoading = true;
    });

    Map data = {
      'customer_id' :  customerId.toString(),
      'user_id' :  userId.toString(),
      'user_name' :  name.toString(),
      'email_id' :  emailId.toString(),
      'mobile_no' :  mobilenumber.toString(),
      'gender' :  strGender.toString(),
      'blood_group' :  bloodGroup.toString(),
      'diabetes' :  strDiabetes.toString(),
      'blood_pressure' :  strBP.toString(),
      'special_remarks' :  strSpecialRemark.toString(),
      'relation' :  relation.toString(),
      'epilepsy' :  strEpliepsy.toString(),
      'vision' :  strVision.toString(),
      'allergy' :  strAllergy.toString(),
      'lefteye' :  lefEyeController.text.toString(),
      'righteye' :  rightEyeController.text.toString(),
      'age' :  age.toString(),
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/SaveMediNoteUserData"),body: data)
    ]).then((response){

      var jasonData = null;
      setState((){
        _isLoading = false;
      });
      if(response[0].statusCode==200){
        jasonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = SaveUserDataResponse.fromJson(map);

        if(response1.settings.success=="1"){
          setState((){
            _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: const TextStyle(fontFamily: "poppins_regular",fontSize: 14))));

           // Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=>DashBoardActivity()));
            Navigator.pop(context,true);

          });
        }else{
          setState((){
            _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: const TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
          });
        }
      }else{
        _scaffoldMessengerState.showSnackBar(const SnackBar(content: Text("Something went wrong please try again later.")));
      }
    }, onError: (error) {
      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(
          msg: error.toString(),
          textColor: Colors.white,
          backgroundColor: Colors.red,
          gravity: ToastGravity.CENTER);
    });
  }

  Future checkValidation() async{
    if(_formkey.currentState!.validate()){


      if(strGender!=null ){
        if(isEyeVisible && !isAllergyVisible) {
          if(dataVisionList !=null){
            SubmitData();
          }else{
            Fluttertoast.showToast(msg: "Please enter eye number.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
          }
        }else if(!isEyeVisible && isAllergyVisible){
          if(allergyController.text.isNotEmpty && allergyController.text.length >0){
            SubmitData();
          }else{
            Fluttertoast.showToast(msg: "Please enter allergy.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
          }
        }else if(isEyeVisible && isAllergyVisible){
          if(dataVisionList !=null){
            if(allergyController.text.isNotEmpty && allergyController.text.length >0){
              SubmitData();
            }else{
              Fluttertoast.showToast(msg: "Please enter allergy.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
            }
          }else{
            Fluttertoast.showToast(msg: "Please enter eye number.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
          }
        }else{
          SubmitData();
        }
      }else{
        Fluttertoast.showToast(msg: "Select gender.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
      }

    }
  }

  Future disableButton(String isEditable) async {
    // 1=disable,2=enable
    if(isEditable=="2"){
      setState((){
        title="Profile Detail";
        isNameEditable = false;
        isMobileEditable = false;
        isEmailEditable = false;
        isAgeEditable = false;
        isRelationEditable = false;
        isBloodGrpEditable = false;
        isGenderEditable = false;
        isLeftEyeEditable = false;
        isRightEyeEditable = false;
        isVisionAddDataEnable = false;
        isVisionDeleteEditable = false;
        isAllergyDesEditable = false;
        isSpecialRemarkEditable = false;

        //for custome radio button
        isDiabetesEditable = true;
        isBPEditable = true;
        isEpliepsyEditable = true;
        isVisionEditable = true;
        isAllergyEditable = true;
      });

    }else{
      setState((){
        title="Edit Profile Detail";
        isNameEditable = true;
        isMobileEditable = true;
        isEmailEditable = true;
        isAgeEditable = true;
        isRelationEditable = true;
        isBloodGrpEditable = true;
        isGenderEditable = true;
        isLeftEyeEditable = true;
        isRightEyeEditable = true;
        isVisionAddDataEnable = true;
        isVisionDeleteEditable = true;
        isAllergyDesEditable = true;
        isSpecialRemarkEditable = true;

        //for custome radio button
        isDiabetesEditable = false;
        isBPEditable = false;
        isEpliepsyEditable = false;
        isVisionEditable = false;
        isAllergyEditable = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    _scaffoldMessengerState = ScaffoldMessenger.of(context);
    return Scaffold(
      backgroundColor: grey_5,
      appBar: AppBar(
        title: Text(title),backgroundColor: PrimaryColor,
        actions: [
          isEditMod ?
          Padding(
            padding: const EdgeInsets.only(right: 15.0),
            child: InkWell(
                onTap: (){
                  checkValidation();
                },
                child: const Icon(Icons.check)),
          ): PopupMenuButton<String>(
              onSelected: onSelect,
              itemBuilder: (BuildContext context) {
                return myMenuItems.map((String choice) {
                  return PopupMenuItem<String>(
                    value: choice,
                    child: Text(choice),
                  );
                }).toList();
              })
        ],
      ),
      body:LoadingOverlay(
        isLoading: _isLoading,
        color: Colors.black54,
        opacity: 0.6,
        child: Container(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)
              ),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: SingleChildScrollView(
                  child: Form(
                    key: _formkey,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Stack(
                          children: [Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Align(
                              alignment: Alignment.topCenter,
                              child: Stack(
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          color: const Color(0xFF555555), width: 5),
                                      borderRadius: const BorderRadius.all(
                                        Radius.circular(100),
                                      ),
                                    ),
                                    child: SizedBox.fromSize(
                                      size: Size(90, 90),
                                      child: ClipOval(
                                        // ignore: unnecessary_null_comparison
                                        child: _pickedImage != null
                                            ? Image.memory(
                                          _pickedImage!,
                                          fit: BoxFit.cover,
                                        )
                                            : Image.asset(
                                          'images/user_default.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                            Positioned(
                              top: MediaQuery.of(context).size.height / 10,
                              left: MediaQuery.of(context).size.width * 0.5,
                              width: MediaQuery.of(context).size.width * 0.1,
                              child: Container(
                                decoration: const BoxDecoration(
                                    color: Color(0xFF555555), shape: BoxShape.circle),
                                height: 30,
                                width: 30,
                                child: IconButton(
                                  onPressed: imagePickerOption,
                                  icon: const Icon(Icons.camera_alt, color: Colors.white, size: 15,),
                                ),
                              ),
                            )],
                        ),
                        TextFormField(
                          enabled: isNameEditable,
                          controller: nameController,
                          decoration: const InputDecoration(
                            labelText: "Name*",
                            labelStyle: TextStyle(color: PrimaryColor),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: grey_20),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: PrimaryColor),
                            ),
                          ),
                          validator: (value){
                            name = value;
                            if(name==null || name.isEmpty){
                              return 'Enter name';
                            }
                            return null;
                          },
                        ),
                        //mobile
                        TextFormField(
                          enabled: isMobileEditable,
                          controller: mobileController,
                          maxLength: 10,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: "Mobile*",
                            labelStyle: TextStyle(
                                color: PrimaryColor
                            ),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: grey_20),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: PrimaryColor),
                            ),
                            suffixIcon: Icon(Icons.perm_contact_cal_rounded,color: PrimaryColor,),
                            counterText: "",
                          ),
                          inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,9}'))],
                          validator: (value){
                            mobileno = value;
                            if(mobileno==null || mobileno.isEmpty || !RegExp(r'^(?:[+0]9)?[0-9]{10}$').hasMatch(mobileno)){
                              return 'Enter valid mobile number.';
                            }
                            return null;
                          },
                        ),
                        //email
                        TextFormField(
                          enabled: isEmailEditable,
                          keyboardType: TextInputType.emailAddress,
                          controller:  emailIdController,
                          decoration: const InputDecoration(
                            labelText: "Email",
                            labelStyle: TextStyle(
                                color: PrimaryColor
                            ),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: grey_20),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: PrimaryColor),
                            ),
                          ),

                          validator: (value){
                            emailId = value!;
                            if(emailId.length>0 &&  !RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(emailId)){
                              return 'Enter valid email id.';
                            }
                            return null;
                          },
                        ),
                        //age
                        TextFormField(
                          enabled: isAgeEditable,
                          controller: ageController,
                          keyboardType: TextInputType.number,
                          maxLength: 3,
                          decoration: const InputDecoration(
                            labelText: "Age",
                            labelStyle: TextStyle(
                                color: PrimaryColor
                            ),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: grey_20),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: PrimaryColor),
                            ),
                            counterText: "",
                          ),
                          inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,9}'))],
                          onChanged:(value){
                            age = value;
                          },
                        ),
                        //relation
                        TextFormField(
                          enabled: isRelationEditable,
                          readOnly: true,
                          controller: _relationController,
                          decoration: const InputDecoration(
                              labelText: "Relation*",
                              labelStyle: TextStyle(
                                  color: PrimaryColor
                              ),
                              enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: grey_20),
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              ),
                              suffixIcon: Icon(Icons.search,color: PrimaryColor,)
                          ),
                          validator: (value){
                            relation = value;
                            if(relation==null || relation.isEmpty){
                              return 'Select relation.';
                            }return null;
                          },
                          onTap: (){
                            if (kDebugMode) {
                              print("click");
                            }
                            openSelectDialog(context,_relationController,"Relation");
                          },
                        ),
                        //blood group
                        TextFormField(
                          enabled: isBloodGrpEditable,
                          readOnly: true,
                          controller: bloodGroupController,
                          decoration: const InputDecoration(
                              labelText: "Blood Group",
                              labelStyle: TextStyle(
                                  color: PrimaryColor
                              ),
                              enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: grey_20),
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: PrimaryColor),
                              ),
                              suffixIcon: Icon(Icons.search,color: PrimaryColor,)
                          ),
                          onChanged: (value){
                            bloodGroup = value.toString();
                           log("bloodgroup + $bloodGroup");
                          },
                          onTap: (){
                            openSelectImageDialog(context,bloodGroupController);
                          },
                        ),
                        const SizedBox(height: 10,),
                        //gender
                        const Align(
                          alignment: Alignment.centerLeft,
                          child: Text("Gender*",style: TextStyle(color: PrimaryColor),),
                        ),
                        const SizedBox(height: 10,),
                        SizedBox(
                          height: 50,
                          child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              itemCount: genders.length,
                              itemBuilder: (context, index) {
                                return InkWell(
                                  splashColor: Colors.white,
                                  onTap: () {
                                    if(isGenderEditable){
                                      setState(() {
                                        genders.forEach((gender) => gender.isSelected = false);
                                        genders[index].isSelected = true;
                                        strGender = genders[index].name;
                                      });
                                    }
                                  },
                                  child:  CustomRadio(genders[index]),
                                );
                              }),
                        ),
                        const SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_20, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),
                        const SizedBox(height: 10,),
                        //diabitis
                        Container(
                          child: Row(
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: SizedBox(
                                  width:25,height: 25,
                                  child: Image.asset("images/diabetes.png",color: PrimaryColor,),
                                ),
                              ),
                              const Expanded(
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 20.0),
                                    child: Text("Diabetes",style: TextStyle(color: PrimaryColor),),
                                  ),
                                ),
                              ),
                              AbsorbPointer(
                                absorbing: isDiabetesEditable,
                                child: Container(
                                  key: UniqueKey(),
                                  child:CustomRadioButton(
                                    unSelectedBorderColor: grey_90,
                                    selectedBorderColor: PrimaryColor,
                                    width: 60,height: 25,
                                    elevation: 0,
                                    absoluteZeroSpacing: true,
                                    unSelectedColor: Colors.white,
                                    defaultSelected: strDiabetes,
                                    buttonLables: const [
                                      'No',
                                      'Yes',
                                    ],
                                    buttonValues:const [
                                      'No',
                                      'Yes',
                                    ],
                                    buttonTextStyle: const ButtonTextStyle(
                                        selectedColor: Colors.white,
                                        unSelectedColor: grey_60,
                                        textStyle: TextStyle(fontSize: 16)),
                                    radioButtonValue: (value) {
                                      print(value);
                                      strDiabetes = value.toString();
                                      print("diabetes"+strDiabetes);
                                    },
                                    enableShape: true,
                                    selectedColor: PrimaryColor,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_20, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),
                        //blood pressure
                        const SizedBox(height: 10,),
                        Container(
                          child: Row(
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: SizedBox(
                                  width:25,height: 25,
                                  child: Image.asset("images/bloodgroup3.png",color: PrimaryColor,),
                                ),
                              ),
                              const Expanded(
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 20.0),
                                    child: Text("Blood Pressure",style: TextStyle(color: PrimaryColor),),
                                  ),
                                ),
                              ),
                              AbsorbPointer(
                                absorbing: isBPEditable,
                                child: Container(
                                  key: UniqueKey(),
                                  child: CustomRadioButton(
                                    unSelectedBorderColor: grey_90,
                                    selectedBorderColor: PrimaryColor,
                                    width: 60,height: 25,
                                    elevation: 0,
                                    absoluteZeroSpacing: true,
                                    unSelectedColor: Colors.white,
                                    defaultSelected: strBP,
                                    buttonLables:const [
                                      'No',
                                      'Yes',
                                    ],
                                    buttonValues: const [
                                      'No',
                                      'Yes',
                                    ],
                                    buttonTextStyle: const ButtonTextStyle(
                                        selectedColor: Colors.white,
                                        unSelectedColor: grey_60,
                                        textStyle: TextStyle(fontSize: 16)),
                                    radioButtonValue: (value) {
                                      strBP = value.toString();
                                      log(strBP);
                                    },
                                    enableShape: true,
                                    selectedColor: PrimaryColor,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        const SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_20, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),
                        //Epilepsy
                        const SizedBox(height: 10,),
                        Container(
                          child: Row(
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: SizedBox(
                                  width:25,height: 25,
                                  child: Image.asset("images/epilepsy.png",color: PrimaryColor,),
                                ),
                              ),
                              const Expanded(
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 20.0),
                                    child: Text("Epilepsy",style: TextStyle(color: PrimaryColor),),
                                  ),
                                ),
                              ),
                              AbsorbPointer(
                                absorbing: isEpliepsyEditable,
                                child: Container(
                                  key: UniqueKey(),
                                  child: CustomRadioButton(
                                    unSelectedBorderColor: grey_90,
                                    selectedBorderColor: PrimaryColor,
                                    width: 60,height: 25,
                                    elevation: 0,
                                    absoluteZeroSpacing: true,
                                    unSelectedColor: Colors.white,
                                    defaultSelected: strEpliepsy,
                                    buttonLables: [
                                      'No',
                                      'Yes',
                                    ],
                                    buttonValues: [
                                      'No',
                                      'Yes',
                                    ],
                                    buttonTextStyle: const ButtonTextStyle(
                                        selectedColor: Colors.white,
                                        unSelectedColor: grey_60,
                                        textStyle: TextStyle(fontSize: 16)),
                                    radioButtonValue: (value) {
                                      strEpliepsy = value.toString();
                                      print(strEpliepsy);
                                    },
                                    enableShape: true,
                                    selectedColor: PrimaryColor,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        const SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_20, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),
                        //Vision
                        const SizedBox(height: 10,),
                        Container(
                          child: Row(
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: SizedBox(
                                  width:25,height: 25,
                                  child: Image.asset("images/vision.png",color: PrimaryColor,),
                                ),
                              ),
                              const Expanded(
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 20.0),
                                    child: Text("Vision",style: TextStyle(color: PrimaryColor),),
                                  ),
                                ),
                              ),
                              AbsorbPointer(
                                absorbing: isVisionEditable,
                                child: Container(
                                  key: UniqueKey(),
                                  child: CustomRadioButton(
                                    unSelectedBorderColor: grey_90,
                                    selectedBorderColor: PrimaryColor,
                                    width: 60,height: 25,
                                    elevation: 0,
                                    absoluteZeroSpacing: true,
                                    unSelectedColor: Colors.white,
                                    defaultSelected: strVision,
                                    buttonLables: [
                                      'No',
                                      'Yes',
                                    ],
                                    buttonValues: [
                                      'No',
                                      'Yes',
                                    ],
                                    buttonTextStyle: const ButtonTextStyle(
                                        selectedColor: Colors.white,
                                        unSelectedColor: grey_60,
                                        textStyle: TextStyle(fontSize: 16)),
                                    radioButtonValue: (value) {
                                      strVision = value.toString();
                                      print(value);
                                      if(value=="Yes"){
                                        setState((){
                                          isEyeVisible = true;
                                        });
                                      }else{
                                        setState((){
                                          isEyeVisible = false;

                                        });
                                      }
                                    },
                                    enableShape: true,
                                    selectedColor: PrimaryColor,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        //rowleftEyeRightEye
                        Visibility(
                          visible: isEyeVisible,
                          child: Padding(
                            padding: const EdgeInsets.only(top: 10,left: 10.0,right: 8.0),
                            child: Column(
                              children: [
                                Row(
                                    children: [
                                      Flexible(
                                        child: TextFormField(
                                          enabled: isLeftEyeEditable,
                                          controller: lefEyeController,
                                          readOnly: true,
                                          decoration: const InputDecoration(
                                            hintText: "Left Eye",
                                            suffixIcon: Icon(Icons.arrow_drop_down_outlined),
                                            border: InputBorder.none,
                                          ),
                                          onTap: (){

                                            openSelectNumberDialog(context,lefEyeController,"leftEye");

                                          },
                                        ),
                                      ),
                                      Flexible(
                                        child: TextFormField(
                                          enabled: isRightEyeEditable,
                                          readOnly: true,
                                          controller: rightEyeController,
                                          decoration: const InputDecoration(
                                              hintText: "Right Eye",
                                              suffixIcon: Icon(Icons.arrow_drop_down_outlined),
                                              border: InputBorder.none
                                          ),
                                          onTap: (){
                                            openSelectNumberDialog(context,rightEyeController,"rightEye");
                                          },
                                        ),
                                      ),
                                      Container(
                                        child: InkWell(
                                            onTap: (){
                                              if(isVisionAddDataEnable){
                                                submitVisonData();
                                              }
                                            },
                                            child: const Icon(Icons.add_circle,size: 30,color: PrimaryColor,)),
                                      )
                                    ]),
                                //show more
                                InkWell(
                                  onTap: (){
                                    if(isVisionDataShow){
                                      setState((){
                                        isVisionDataShow = false;
                                        isVisionTableVisible = false;
                                      });
                                    }else{
                                      setState((){
                                        isVisionDataShow = true;
                                        isVisionTableVisible = true;
                                      });
                                    }
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: PrimaryColor,
                                      border: Border.all(color: PrimaryColor, width: 1.0),
                                      borderRadius: BorderRadius.circular(30.0),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(left: 10.0,),
                                          child: Text(
                                            'Show more',
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontFamily: 'poppins_regular',
                                              fontSize: 12,
                                            ),
                                          ),
                                        ),
                                        Container(
                                          key: UniqueKey(),
                                          child: isVisionDataShow ? Icon(Icons.keyboard_arrow_down ,size: 22.0,color: Colors.white,):
                                          Icon(Icons.keyboard_arrow_right,size: 22.0,color: Colors.white,),
                                        ),


                                      ],
                                    ),
                                  ),
                                ),
                                Visibility(
                                  visible: isVisionTableVisible,
                                  child: Padding(
                                    padding: const EdgeInsets.only(top: 8.0),
                                    child: Container(
                                      child: SingleChildScrollView(
                                        scrollDirection: Axis.horizontal,
                                        child: Container(
                                          child: dataVisionList!=null ? BuildTableData(context,dataVisionList):const Text("No data found"),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_20, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),
                        //Allergy
                        const SizedBox(height: 10,),
                        Container(
                          child: Row(
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: SizedBox(
                                  width:25,height: 25,
                                  child: Image.asset("images/allergy.png",color: PrimaryColor,),
                                ),
                              ),
                              const Expanded(
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 20.0),
                                    child: Text("Allergy",style: TextStyle(color: PrimaryColor),),
                                  ),
                                ),
                              ),
                              AbsorbPointer(
                                absorbing: isAllergyEditable,
                                child: Container(
                                  key: UniqueKey(),
                                  child: CustomRadioButton(
                                    unSelectedBorderColor: grey_90,
                                    selectedBorderColor: PrimaryColor,
                                    width: 60,height: 25,
                                    elevation: 0,
                                    absoluteZeroSpacing: true,
                                    unSelectedColor: Colors.white,
                                    defaultSelected: strAllergy,

                                    buttonLables: [
                                      'No',
                                      'Yes',
                                    ],
                                    buttonValues: [
                                      'No',
                                      'Yes',
                                    ],
                                    buttonTextStyle: const ButtonTextStyle(
                                        selectedColor: Colors.white,
                                        unSelectedColor: grey_60,
                                        textStyle: TextStyle(fontSize: 16)),
                                    radioButtonValue: (value) {
                                      strAllergy = value.toString();
                                      print(value);
                                      if(value=="Yes"){
                                        setState((){
                                          isAllergyVisible = true;
                                        });
                                      }else{
                                        setState((){
                                          isAllergyVisible = false;

                                        });
                                      }
                                    },
                                    enableShape: true,
                                    selectedColor: PrimaryColor,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        //allergy textformfield
                        Visibility(
                          visible: isAllergyVisible,
                          child: Padding(
                            padding: const EdgeInsets.only(top: 10.0),
                            child: TextFormField(
                              enabled: isAllergyDesEditable,
                              minLines: 4,
                              maxLines: 4,
                              controller: allergyController,
                              keyboardType: TextInputType.multiline,
                              decoration: const InputDecoration(
                                hintText: "Enter Description",
                                fillColor: grey_5,
                                filled: true,
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_20, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),

                        const SizedBox(height: 10,),
                        Padding(
                          padding: const EdgeInsets.only(top: 10.0),
                          child: TextFormField(
                            enabled: isSpecialRemarkEditable,
                            minLines: 2,
                            maxLines: 5,
                            controller: specialController,
                            keyboardType: TextInputType.multiline,
                            decoration: InputDecoration(
                                labelText: 'Special Remark',
                                labelStyle: const TextStyle(
                                    color: PrimaryColor
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: const BorderSide(color: grey_60,width: 1),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: const BorderSide(
                                        color: grey_20

                                    )
                                )


                            ),
                            onChanged: (value){
                              strSpecialRemark = value;
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
  Widget CustomeRadioDiabetes(strDiabetes){
    return CustomRadioButton(
      unSelectedBorderColor: grey_90,
      selectedBorderColor: PrimaryColor,
      width: 60,height: 25,
      elevation: 0,
      absoluteZeroSpacing: true,
      unSelectedColor: Colors.white,
      defaultSelected: strDiabetes,
      buttonLables:const [
        'No',
        'Yes',
      ],
      buttonValues:const [
        'No',
        'Yes',
      ],
      buttonTextStyle: const ButtonTextStyle(
          selectedColor: Colors.white,
          unSelectedColor: grey_60,
          textStyle: TextStyle(fontSize: 16)),
      radioButtonValue: (value) {
        print(value);
        strDiabetes = value.toString();
        print("diabetes"+strDiabetes!);
      },
      enableShape: true,
      selectedColor: PrimaryColor,
    );
  }

  Widget CustomRadio(Gender _gender) {
    return Card(
        color: _gender.isSelected ? PrimaryColor : Colors.white,
        child: Container(
          height: 20,
          width: 90,
          alignment: Alignment.center,
          margin: EdgeInsets.all(5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Icon(
                _gender.icon,
                color: _gender.isSelected ? Colors.white : Colors.grey,
                size: 22,
              ),

              const SizedBox(height: 10),

              Text(
                _gender.name,
                style: TextStyle(color: _gender.isSelected ? Colors.white : Colors.grey),
              )
            ],
          ),
        ));
  }

  Future openSelectDialog(BuildContext context, TextEditingController relationController,String idtfDialog) async {
    showDialog(
        context: context,
        builder: (BuildContext context) => CustomAlertSelectionDialog(
          idtfDialog : idtfDialog,
          selectedId: "1",
          selectionList: relationList,
          doneTitle: "Done",
          cancelTitle: "Cancel",
          position: "1",
          onClick: onSelectionClick,
          onCancel: onSelectionCancel,
          rowClickPos: 0,
          relationController:relationController,));
  }

  onSelectionClick(
      String idtfDialog,
      String selectedId,
      String selectionName,
      String position,
      int rowClickPos,
      TextEditingController relationController,
      String extraStr) {

    relationController.text = selectionName;

    print(selectedId);
    print(selectionName);
   // Navigator.pop(context, arrayList);




  }

  onSelectionCancel(String p1) {
  }


  Future openSelectImageDialog(BuildContext context, TextEditingController bloodGroupController) async {
    showDialog(
        context: context,
        builder: (BuildContext context) => CustomAlertSelectionImageDialog(
          selectedId: "1",
          selectionList: bloodGroupList,
          doneTitle: "Done",
          cancelTitle: "Cancel",
          position: "1",
          arrayList: arrayList,
          onClick: onSelectionClick1,
          onCancel: onSelectionCancel1,
          rowClickPos: 0,
          relationController:bloodGroupController,));
  }

  onSelectionClick1(
      String selectedId,
      String selectionName,
      String position,
      List<GetEditTextValueHelper> arrayList,
      int rowClickPos,
      TextEditingController bloodGroupController) {
    bloodGroupController.text = selectionName;
    print(selectedId);
    print("blood g:"+selectionName);
    bloodGroup = selectionName;
    //Navigator.pop(context, arrayList);
  }

  onSelectionCancel1(String p1) {
  }





  Future openSelectNumberDialog(BuildContext context, TextEditingController lefEyeController, String strName) async {
    showDialog(
        context: context,
        builder: (BuildContext context) => CustomAlertDialog(
            selectedId: "1",
            selectionList: relationList,
            doneTitle: "Done",
            cancelTitle: "Cancel",
            position: "1",
            arrayList: arrayList,
            onClick: onSelectionNumberClick,
            onCancel: onSelectionNumberCancel,
            rowClickPos: 0,
            relationController:lefEyeController,
            strName:strName));
  }

  onSelectionNumberClick(
      String selectedId,
      String selectionName,
      String position,
      List<GetEditTextValueHelper> arrayList,
      int rowClickPos,
      TextEditingController eyeController,
      String positiveMinValue,
      String currentValue,
      String currentValuePoint,
      String strName,
      ) {

    if(strName=="leftEye") {
      lefEyeController.text = '$positiveMinValue $currentValue .$currentValuePoint';
    }else if(strName=="rightEye"){
      rightEyeController.text = '$positiveMinValue $currentValue .$currentValuePoint';
    }

    print(selectedId);
    print(selectionName);
    //Navigator.pop(context, arrayList);


  }

  onSelectionNumberCancel(String p1) {
  }

  Widget BuildTableData(BuildContext context, VisionListResponse visionListResponse ) {
    var valueList = visionListResponse.data;
    return DataTable(
      headingRowColor: MaterialStateColor.resolveWith((states) => PrimaryColor),
      dataRowColor: MaterialStateColor.resolveWith((states) => grey_10),
      border: TableBorder.symmetric(inside: const BorderSide(width: 1, color: Colors.white), outside: const BorderSide(width: 3, color: Colors.white)),
      columns: const [
        DataColumn(label: Text('Date',style: TextStyle(color: Colors.white),)),
        DataColumn(label: Text('Left',style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Right',style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('',style: TextStyle(color: Colors.white))),

      ],
      rows: [
        for(int i=0; i<valueList.length; i++) DataRow(
            cells: [
              DataCell(Text(valueList[i].date.toString())),
              DataCell(Text(valueList[i].left.toString())),
              DataCell(Text(valueList[i].right.toString())),
              DataCell(
                  InkWell(
                      onTap: (){
                        if(isVisionDeleteEditable) {
                          alertDialog(context, valueList[i].visionId.toString());
                        }
                      },
                      child: const Text('Delete'))),

            ]),
      ],
    );
  }

  Future<bool> alertDialog(context, String visionId) async{
    return await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: SizedBox(
              height: 110,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Are you sure you want to delete this vision data?"),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            print('yes selected');
                            //_logout();
                            DeleteVisionData(visionId);
                            Navigator.of(context).pop();
                          },
                          style: ElevatedButton.styleFrom(primary: Colors.red.shade800),
                          child: const Text("Yes"),
                        ),
                      ),
                      const SizedBox(width: 15),
                      Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              print('no selected');
                              Navigator.of(context).pop();
                            },
                            style: ElevatedButton.styleFrom(
                              primary: Colors.white,
                            ),
                            child: const Text("No", style: TextStyle(color: Colors.black)),
                          ))
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }

  Future<bool> alertDeletePatientDialog(context) async{
    return await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: SizedBox(
              height: 120,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(top: 10.0),
                    child: Text("Are you sure you want to delete this patient detail?"),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          style: ElevatedButton.styleFrom(primary: Colors.red.shade800),
                          child: const Text("Yes"),
                        ),
                      ),
                      const SizedBox(width: 15),
                      Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              print('no selected');
                              Navigator.of(context).pop();
                            },
                            style: ElevatedButton.styleFrom(
                              primary: Colors.white,
                            ),
                            child: const Text("No", style: TextStyle(color: Colors.black)),
                          ))
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }

}


class Gender {
  String name;
  IconData icon;
  bool isSelected;

  Gender(this.name, this.icon, this.isSelected);
}

