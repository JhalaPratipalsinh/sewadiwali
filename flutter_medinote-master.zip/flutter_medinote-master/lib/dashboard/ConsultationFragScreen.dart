
import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_medinote/consultation/AddConsultationTabActivity.dart';
import 'package:flutter_medinote/consultation/editConsultation/EditConsultationTabActivity.dart';
import 'package:flutter_medinote/response/ConsultationMainListResponse.dart';
import 'package:flutter_medinote/utils/CustomAddRatingDialog.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';

import '../response/SaveConsultantRatingResponse.dart';
import '../response/ShareConsultantDataResponse.dart';
import '../utils/AppColors.dart';
import '../utils/ConsultationReportHelper.dart';
import '../utils/CustomAlertTextDialog.dart';
import '../utils/PreferenceManager.dart';
import '../utils/SyncPDFScreen.dart';
import '../utils/VariableBag.dart';

class ConsultationFragScreen extends StatefulWidget {
  const ConsultationFragScreen({Key? key}) : super(key: key);

  @override
  State<ConsultationFragScreen> createState() => _ConsultationFragScreenState();
}

class _ConsultationFragScreenState extends State<ConsultationFragScreen> {

  var _isLoading = true;
  var userId,searchText="",customerId="",page_index="1";
  var dataList;
  late ScaffoldMessengerState _scaffoldMessengerState;
  TextEditingController controller = TextEditingController();

  final DateFormat format = DateFormat.yMMMMd('en_US');
  String fromDate = '';
  String? toDate='';
  String? partyName='';

  late List<String> dataKey = <String>[];
  List<dynamic> fields = [];
  var mapEntry1 = [];
  var dataLength = 0;
  String doctorName='',diseaseName='',patientName='',consultationDate='';
  var mapEntry;
  List<ConsultationReportHelper> reportRowList = [];
  List<String> headerRowList = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _isLoading = true;
    setPreferenceValue();
  }
  setPreferenceValue() async {
    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {
      userId = value;
      getConsultationList("");
    }));
  }
  Future getConsultationList(String searchtext) async{
//get cunsultation data
    Map map ={
      'customer_id' : customerId,
      'user_id' : userId,
      'search_text' : searchtext,
      'page_index' : page_index,
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/MediNoteConsultantDataListing"),body: map)
    ]).then((response) {

      var jasonData  = null;

      if(mounted){
        setState((){
          _isLoading = false;
        });
      }


      if(response[0].statusCode==200){

        jasonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = ConsultationMainListResponse.fromJson(map);

        if(response1.settings.success=="1"){

          dataList = ConsultationMainListResponse.fromJson(map);

        }else{
          setState((){
            dataList = null;
          });
        }

      }else{
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Something went wrong please try again later.")));
      }

    },onError: (error){
      setState((){
        _isLoading = false;
        Fluttertoast.showToast(msg: error.toString(),textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.CENTER);
      });
    });

  }

  @override
  Widget build(BuildContext context) {
    _scaffoldMessengerState = ScaffoldMessenger.of(context);



    return Scaffold(
      body: Container(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 15.0,right: 15.0,top: 10,bottom: 10),
              child: Row(
                children: [
                  Flexible(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white, borderRadius: BorderRadius.circular(10),),
                      child: TextFormField(
                        decoration: const InputDecoration(
                          hintStyle: TextStyle(fontSize: 17),
                          hintText: 'Search...',
                          prefixIcon: Icon(Icons.search,color: PrimaryColor,),
                          contentPadding: EdgeInsets.symmetric(vertical: 15.0, horizontal: 10.0),
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                              borderSide: BorderSide(color: PrimaryColor)
                          ),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                              borderSide: BorderSide(color: PrimaryColor)
                          ),
                        ),
                        onChanged: (value){
                          filterSearchResults(value,dataList);

                        },
                      ),
                    ),
                  ),

                ],
              ),
            ),
            Flexible(
              child: Center(
                child: _isLoading?Container(
                  child: CircularProgressIndicator(),
                ):dataList!=null ? BuildConsultationList(context,dataList) : Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: const [
                    Image(width: 100, height: 100, image: AssetImage("images/folder.png"),color: PrimaryColor),
                    SizedBox(height: 10,),
                    Align(alignment: Alignment.center,
                        child: Text("Data not found",style: TextStyle(color: PrimaryColor,fontFamily: "poppins_regular",fontSize: 20.0),))
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: PrimaryColor,
          onPressed: () async {
            final reload = await Navigator.push(context, MaterialPageRoute(builder: (context) => AddConsultationTabActivity(),));
            if(reload){
              getConsultationList("");
            }
          },
      child: Icon(Icons.add,color: Colors.white,)
      ),
    );
  }


  Widget BuildConsultationList(BuildContext context,ConsultationMainListResponse consultationMainListResponse) {
    var value = consultationMainListResponse.data;
    return Container(
      child: ListView.builder(
        itemCount: value!=null && value.length>0 ?value.length:0,
        itemBuilder: (context,index){
          return Padding(
            padding: const EdgeInsets.only(left: 15.0,right: 15.0,top: 10,bottom: 10),
            child: InkWell(
              onTap: () async {
                final reLoadPage = await Navigator.of(context).push(MaterialPageRoute(builder: (context)=>EditConsultationTabActivity(value[index].consultantId)));

                if (reLoadPage) {
                  setState(() {
                    getConsultationList("");
                  });
                }
               // Navigator.of(context).push(MaterialPageRoute(builder: (context)=>EditConsultationTabActivity(value[index].consultantId)));
              },
              child: Card(
                elevation: 4,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Visibility(
                      visible: false,
                      child: Expanded(
                        flex: 1,
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 95,
                            height: 95,
                            child:  Image.asset('images/female_doctor.png'),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child:Column(
                        children: [
                          Align(
                            alignment: Alignment.topRight,
                            child: Padding(
                              padding: EdgeInsets.only(right:5.0,top: 5),
                              child: Container(
                                padding: const EdgeInsets.all(3),
                                decoration: const BoxDecoration(
                                  //color: grey_20,
                                   border: Border(
                                       top: BorderSide(color: Colors.grey, width: 1),
                                       left: BorderSide(color: Colors.grey, width: 1),
                                       right: BorderSide(color: Colors.grey, width: 1),
                                       bottom: BorderSide(color: Colors.grey, width: 1),
                                   ),
                                  borderRadius: BorderRadius.all(Radius.circular(10))
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(child: Icon(
                                      Icons.calendar_month_outlined,color: PrimaryColor,)),
                                    Text(value[index].date,style: TextStyle(color: PrimaryColor),),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Visibility(
                                  visible: false,
                                  child: Expanded(
                                    flex: 1,
                                    child: Align(
                                      alignment: Alignment.topLeft,
                                      child: Container(
                                        width: 95,
                                        height: 95,
                                        child: Image.asset('images/dress2.jpg'),
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Expanded(child: Text("Name",style: TextStyle(fontSize: 16,color: grey_60),)),
                                          Expanded(
                                              flex: 2,
                                              child: Text(value[index].patientName,style: TextStyle(fontSize: 16,color: PrimaryColor ),)),
                                        ],
                                      ),
                                      const Padding(
                                        padding: EdgeInsets.only(top: 8.0,bottom: 8.0),
                                        child: Divider(
                                          thickness: 1, // thickness of the line
                                          indent: 0, // empty space to the leading edge of divider.
                                          endIndent: 0, // empty space to the trailing edge of the divider.
                                          color: grey_10, // The color to use when painting the line.
                                          height: 1, // The divider's height extent.
                                        ),
                                      ),
                                      Row(
                                        children: [
                                          Expanded(child: Text("Doctor",style: TextStyle(fontSize: 16,color: grey_60),)),
                                          Expanded(
                                              flex: 2,child: Text(value[index].doctorName,style: TextStyle(fontSize: 16,color: PrimaryColor ),)),
                                        ],
                                      ),
                                      const Padding(
                                        padding: EdgeInsets.only(top: 8.0,bottom: 8.0),
                                        child: Divider(
                                          thickness: 1, // thickness of the line
                                          indent: 0, // empty space to the leading edge of divider.
                                          endIndent: 0, // empty space to the trailing edge of the divider.
                                          color: grey_10, // The color to use when painting the line.
                                          height: 1, // The divider's height extent.
                                        ),
                                      ),
                                      Row(
                                        children: [
                                          Expanded(child: const Text("Disease",style: TextStyle(fontSize: 16,color: grey_60),)),
                                          Expanded(
                                              flex: 2,child: Text(value[index].diseaseName,style: TextStyle(fontSize: 16,color: PrimaryColor ),)),
                                        ],
                                      ),
                                      const Padding(
                                        padding: EdgeInsets.only(top: 8.0,bottom: 8.0),
                                        child: Divider(
                                          thickness: 1, // thickness of the line
                                          indent: 0, // empty space to the leading edge of divider.
                                          endIndent: 0, // empty space to the trailing edge of the divider.
                                          color: grey_10, // The color to use when painting the line.
                                          height: 1, // The divider's height extent.
                                        ),
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [

                                          InkWell(
                                            onTap: (){
                                              openTextDialog(context,controller,value[index].consultantId,"","","","Add Rating","Review");
                                            },
                                            child: AbsorbPointer(
                                              absorbing: true,
                                              child: RatingBar.builder(
                                                itemSize: 20,
                                                initialRating: _InitialValue(value[index].rating),
                                                minRating: 1,
                                                itemCount: 5,
                                                itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                                                  itemBuilder: (context, index) => Icon(Icons.star, color: Colors.amber,),
                                                  onRatingUpdate: (rating) {
                                                    print(rating);
                                                  },),
                                            ),
                                          ),
                                          InkWell(
                                            onTap: (){
                                              //log('share click');
                                              //createDynamicPdf();
                                              callShareConsultationData(index,value[index].consultantId);
                                              //generateInvoice();
                                            },
                                            child: const CircleAvatar(
                                              maxRadius: 15,
                                              backgroundColor: PrimaryColor,
                                                child: Center(
                                                  child: Icon(size: 20, Icons.share,color: Colors.white,),
                                                )),
                                          )
                                        ],
                                      ),

                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },),
    );
  }

  _InitialValue(String rating) {
    if (rating == "AWFUL") {
      return 1.0;
    } else if(rating == "BAD") {
      return 2.0;
    }else if(rating == "OKAY") {
      return 3.0;
    }else if(rating == "GOOD") {
      return 4.0;
    } else {
      return 5.0;
    }
  }

  Future filterSearchResults(String value, dataList, ) async{

    if(value.isNotEmpty){

      if(value.length>0){

        getConsultationList(value);
      }else{
        getConsultationList("");
      }
    }else{
      getConsultationList("");
    }
  }

  void openTextDialog(BuildContext context, TextEditingController controller, String consultantId, String diseaseName,String editTxtField2,String editTxtField3, String dialogTitle, String txtFiel1 ) {
    showDialog(
        context: context,
        builder: (BuildContext context) => CustomAddRatingDialog(
          dialogTitle:dialogTitle,
          doneTitle: "Done",
          cancelTitle: "Cancel",
          onDelete: onDeleteClick,
          position: "1",
          onClick: onSelectionClick1,
          onCancel: onSelectionCancel1,
          relationController:controller,
          editId : consultantId,
          editName : diseaseName,
          editTxtField2 : editTxtField2,
          editTxtField3 : editTxtField3,
          txtFiel1 : txtFiel1,
          txtFiel2IsVisible : false,
          txtFiel3IsVisible : false,

        ));
  }
  onSelectionClick1(
      String editId,
      String selectionName,
      String position,
      TextEditingController bloodGroupController,
      String textfield2Value,
      String txtfield3Value,
      ) {

    //bloodGroupController.text = selectionName;
    //print(selectedId);
    print("review :"+selectionName);
    print("select star :"+textfield2Value);

    Navigator.pop(context);

   SubmitReview(textfield2Value,selectionName,editId);
  }

  onSelectionCancel1(String p1) {
  }
  onDeleteClick(String diseaseId) {
    Navigator.pop(context);
   // alertDeleteDiseaseDialog(diseaseId);
  }

  Future SubmitReview(String selectStar, String review, String consultantId) async{

    Map map ={
      'customer_id' : customerId,
      'user_id' : userId,
      'con_id' : consultantId,
      'rating' : selectStar,
      'comment' : review,
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/SaveConsultantRating"),body: map)
    ]).then((response) {

      var jasonData  = null;

      if(mounted){
        setState((){
          _isLoading = false;
        });
      }


      if(response[0].statusCode==200){

        jasonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = SaveConsultantRatingResponse.fromJson(map);

        if(response1.settings.success=="1"){

          Fluttertoast.showToast(msg: response1.settings.message,backgroundColor: Colors.green,gravity: ToastGravity.CENTER);
          getConsultationList("");
        }else{
          Fluttertoast.showToast(msg: response1.settings.message,backgroundColor: Colors.red,gravity: ToastGravity.CENTER);
        }

      }else{
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Something went wrong please try again later.")));
      }

    },onError: (error){
      setState((){
        _isLoading = false;
        Fluttertoast.showToast(msg: error.toString(),textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.CENTER);
      });
    });

  }


  Future callShareConsultationData(int index, String consultantId) async{

    setState((){
      _isLoading = true;
    });
    Map map ={
      'customer_id' : customerId,
      'user_id' : userId,
      'con_id' : consultantId,
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/ShareMediNoteConsultantData"),body: map)
    ]).then((response) {

      var jasonData  = null;

      if(mounted){
        setState((){
          _isLoading = false;
        });
      }


      if(response[0].statusCode==200){

        jasonData = jsonDecode(response[0].body);
        var mapData = Map<String,dynamic>.from(jasonData);
        var response1 = ShareConsultantDataResponse.fromJson(mapData);

        if(response1.settings.success=="1"){

          Fluttertoast.showToast(msg: response1.settings.message,backgroundColor: Colors.green,gravity: ToastGravity.CENTER);
          dataKey.clear();
          fields.clear();
          mapEntry1 = [];

         if(response1.consultant !=null && response1.consultant.length >0){

           if(response1.consultant[0].medicine != null && response1.consultant[0].medicine.isNotEmpty){

             if(response1.consultant[0].doctorName!=null && response1.consultant[0].doctorName.isNotEmpty){
               doctorName = response1.consultant[0].doctorName.toString();
             }
             if(response1.consultant[0].patientName!=null && response1.consultant[0].patientName.isNotEmpty){
               patientName = response1.consultant[0].patientName.toString();
             }
             if(response1.consultant[0].diseaseName!=null && response1.consultant[0].diseaseName.toString().isNotEmpty){
               diseaseName = response1.consultant[0].diseaseName.toString();
             }
             if(response1.consultant[0].date!=null && response1.consultant[0].date.toString().isNotEmpty){
               var strDate = response1.consultant[0].date.toString();

               String result = strDate.substring(0, strDate.indexOf(' '));
               print(result);
               consultationDate = result;
               print(consultationDate);
             }

             headerRowList.clear();
             reportRowList.clear();

             headerRowList =[
                 "Medicine Name",
                 "At Morning",
                 "At Afternoon",
                 "At Evening",
                 "Before or After",
                 "Medicine With",
                 "Medicine Schedule",
                 "Medicine Type",
                 "Drug Name",
                 "Medicine Price",
                 "Manufacturer"];

             for(int i=0; i<response1.consultant[0].medicine.length; i++){
               reportRowList.add(ConsultationReportHelper(
                   response1.consultant[0].medicine[i].medicineName,
                   response1.consultant[0].medicine[i].atMorning,
                   response1.consultant[0].medicine[i].atAfternoon,
                   response1.consultant[0].medicine[i].atEvening,
                   response1.consultant[0].medicine[i].beforOrAfter,
                   response1.consultant[0].medicine[i].medicineWith,
                   response1.consultant[0].medicine[i].medicineSchedule,
                   response1.consultant[0].medicine[i].medicineType,
                   response1.consultant[0].medicine[i].drugName,
                   response1.consultant[0].medicine[i].medicinePrice,
                   response1.consultant[0].medicine[i].manufacturer));


             }

             generateInvoice();
           }
         }

          /*if (mapData["Consultant"].length > 0) {
            mapData.forEach((key, value) {
              if (key == "Consultant") {
                dataLength = mapData["Consultant"].length;

                for (int i1 = 0; i1 < mapData["Consultant"].length; i1++) {
                  mapEntry = mapData[key][i1];
                  mapEntry1.insert(i1, mapData[key][i1]);
                }
              }
              if (key == "settings") {
                if (mapData["settings"]["fields"] != null) {
                  fields = mapData["settings"]["fields"];
                  log('ShareMediNoteConsultantData :=>fields ==> $fields');
                }
              }
            });
            for (var datavalues in mapEntry.entries) {
              dataKey.add(datavalues.key);
            }

            log("MapEntry List ==> $mapEntry1");
            log('Map Entry ==> $mapEntry');
          } else {
            Fluttertoast.showToast(msg: "No list found", textColor: Colors.white, backgroundColor: Colors.green, gravity: ToastGravity.CENTER);
          }*/


        }else{
          Fluttertoast.showToast(msg: response1.settings.message,backgroundColor: Colors.red,gravity: ToastGravity.CENTER);
        }

      }else{
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Something went wrong please try again later.")));
      }

    },onError: (error){
      setState((){
        _isLoading = false;
        Fluttertoast.showToast(msg: error.toString(),textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.CENTER);
      });
    });

  }

 /* Future<void> createDynamicPdf() async {

    PdfDocument document = PdfDocument();
    final PdfPage page = document.pages.add();
    //Get page client size
    final Size pageSize = page.getClientSize();
    PdfGrid grid = PdfGrid();
    PdfLayoutResult result = drawHeader(page, pageSize, grid);
    getGrid(grid);
    grid.beginCellLayout = (Object sender, PdfGridBeginCellLayoutArgs args) {
      final PdfGrid grid = sender as PdfGrid;
      if (args.cellIndex == grid.columns.count - 1) {
      } else if (args.cellIndex == grid.columns.count - 2) {}
    };
    result = grid.draw(page: page, bounds: Rect.fromLTWH(0, result.bounds.bottom + 20, 0, 0))!;
     grid.draw(page: document.pages.add(), bounds:  Rect.fromLTWH(10,  result.bounds.bottom + 40, 0, 0));
    List<int> bytes = document.saveSync();
    document.dispose();
    await saveAndLaunchFile(bytes, 'DataNoteReport.pdf');

  }
  PdfLayoutResult drawHeader(PdfPage page, Size pageSize, PdfGrid grid) {
    //Draw rectangle
    page.graphics.drawRectangle(
        brush: PdfSolidBrush(PdfColor(91, 126, 215)),
        bounds: Rect.fromLTWH(0, 0, pageSize.width - 115, 90));
    //Draw string
    page.graphics.drawString(
        'Report', PdfStandardFont(PdfFontFamily.helvetica, 20),
        brush: PdfBrushes.white,
        bounds: Rect.fromLTWH(25, 0, pageSize.width - 115, 90),
        format: PdfStringFormat(lineAlignment: PdfVerticalAlignment.middle));

    page.graphics.drawString(
        'Report', PdfStandardFont(PdfFontFamily.helvetica, 20),
        brush: PdfBrushes.white,
        bounds: Rect.fromLTWH(25, 0, pageSize.width - 115, 90),
        format: PdfStringFormat(lineAlignment: PdfVerticalAlignment.middle));

    page.graphics.drawRectangle(
        bounds: Rect.fromLTWH(400, 0, pageSize.width - 400, 90),
        brush: PdfSolidBrush(PdfColor(65, 104, 205)));

    page.graphics.drawString(format.format(DateTime.now()),
        PdfStandardFont(PdfFontFamily.helvetica, 14),
        bounds: Rect.fromLTWH(400, 0, pageSize.width - 400, 100),
        brush: PdfBrushes.white,
        format: PdfStringFormat(alignment: PdfTextAlignment.center, lineAlignment: PdfVerticalAlignment.middle));

    final PdfFont contentFont = PdfStandardFont(PdfFontFamily.helvetica, 14);
    //Draw string
    page.graphics.drawString('Date', contentFont,
        brush: PdfBrushes.white,
        bounds: Rect.fromLTWH(400, 0, pageSize.width - 400, 33),
        format: PdfStringFormat(
            alignment: PdfTextAlignment.center,
            lineAlignment: PdfVerticalAlignment.bottom));
    //Create data foramt and convert it to text.

    final String invoiceNumber = 'From Date:${fromDate != 'null' ? fromDate : '-'} \r\n\r\n To Date: ${toDate != 'null' ? toDate : '-'}';
    final Size contentSize = contentFont.measureString(invoiceNumber);
    // ignore: leading_newlines_in_multiline_strings
    String reportDetails =
    '''Report Name :  "Test report" \r\n\r\n Party Name : ${partyName != 'null' ? partyName : '-'}''';

    PdfTextElement(text: invoiceNumber, font: contentFont).draw(
        page: page,
        bounds: Rect.fromLTWH(pageSize.width - (contentSize.width + 30), 120,
            contentSize.width + 30, pageSize.height - 120));

    return PdfTextElement(text: reportDetails, font: contentFont).draw(
        page: page,
        bounds: Rect.fromLTWH(30, 120, pageSize.width - (contentSize.width + 30), pageSize.height - 120))!;
  }

  PdfGrid getGrid(PdfGrid grid) {

    grid.columns.add(count: dataValue.length);
    grid.headers.add(1);
    PdfGridRow header = grid.headers[0];

    if (dataKey.isNotEmpty) {
      for (int i = 0; i < dataKey.length; i++) {
        header.cells[i].value = dataKey[i].toString();
      }
    }

    PdfGridRow row = grid.rows.add();
    if (mapEntry1.isNotEmpty) {
      mapEntry1.map((values) => addRows(values, grid)).toList();
    }

    PdfGridBuiltInStyleSettings tableStyleOption =
    PdfGridBuiltInStyleSettings();
    tableStyleOption.applyStyleForBandedRows = true;
    tableStyleOption.applyStyleForHeaderRow = true;
    grid.applyBuiltInStyle(PdfGridBuiltInStyle.listTable6ColorfulAccent1, settings: tableStyleOption);

    return grid;
  }

  void addRows(values, PdfGrid grid) {
    try {
      PdfGridRow row = grid.rows.add();
      var index = 0;
      for (var dataValues in values.entries) {
        row.cells[index].value = dataValues.value;
        index++;
      }
    } catch (e) {
      log(e.toString());
    }
  }

  saveAndLaunchFile(List<int> bytes, String filepath) async {
    final directory = Platform.isAndroid
        ? await getApplicationDocumentsDirectory() //FOR ANDROID
        : await getApplicationSupportDirectory();
    final path = directory.path;

    String filePath = '$path/$filepath';
    final file = File(filePath);
    await file.writeAsBytes(bytes, flush: true);
    Fluttertoast.showToast(
        msg: 'File save $filepath successfully.',
        backgroundColor: Colors.green,
        textColor: Colors.white,
        gravity: ToastGravity.CENTER,
        toastLength: Toast.LENGTH_SHORT);

    Navigator.push(context, MaterialPageRoute(builder: (context) => SyncPDFScreen(filePath)),);

    log(filePath);
  }*/
  Future<void> generateInvoice() async {

    setState((){
      _isLoading = true;
    });

    //Create a PDF document.
    final PdfDocument document = PdfDocument();
    //Add page to the PDF
    final PdfPage page = document.pages.add();
    //Get page client size
    final Size pageSize = page.getClientSize();
    //Draw rectangle
    page.graphics.drawRectangle(
        bounds: Rect.fromLTWH(0, 0, pageSize.width, pageSize.height),
        pen: PdfPen(PdfColor(142, 170, 219)));
    //Generate PDF grid.
    final PdfGrid grid = getGrid();
    //Draw the header section by creating text element
    final PdfLayoutResult result = drawHeader(page, pageSize, grid);
    //Draw grid
    drawGrid(page, grid, result);
    //Add invoice footer
    //drawFooter(page, pageSize);
    //Save the PDF document
    final List<int> bytes = document.saveSync();
    //Dispose the document.
    document.dispose();
    //Save and launch the file.
    await saveAndLaunchFile(bytes, 'Medinote.pdf');
  }

  //Draws the invoice header
  PdfLayoutResult drawHeader(PdfPage page, Size pageSize, PdfGrid grid) {
    //Draw rectangle
    page.graphics.drawRectangle(
        brush: PdfSolidBrush(PdfColor(91, 126, 215)),
        bounds: Rect.fromLTWH(0, 0, pageSize.width - 115, 90));
    //Draw string
    page.graphics.drawString('MEDINOTE', PdfStandardFont(PdfFontFamily.helvetica, 30),
        brush: PdfBrushes.white,
        bounds: Rect.fromLTWH(25, 0, pageSize.width - 115, 90),
        format: PdfStringFormat(lineAlignment: PdfVerticalAlignment.middle));

    page.graphics.drawRectangle(
        bounds: Rect.fromLTWH(400, 0, pageSize.width - 400, 90),
        brush: PdfSolidBrush(PdfColor(91, 126, 215)));

    /*page.graphics.drawString(r'$' + getTotalAmount(grid).toString(),
        PdfStandardFont(PdfFontFamily.helvetica, 18),
        bounds: Rect.fromLTWH(400, 0, pageSize.width - 400, 100),
        brush: PdfBrushes.white,
        format: PdfStringFormat(
            alignment: PdfTextAlignment.center,
            lineAlignment: PdfVerticalAlignment.middle));*/

    final PdfFont contentFont = PdfStandardFont(PdfFontFamily.helvetica, 9);
    //Draw string
   /* page.graphics.drawString('Amount', contentFont,
        brush: PdfBrushes.white,
        bounds: Rect.fromLTWH(400, 0, pageSize.width - 400, 33),
        format: PdfStringFormat(
            alignment: PdfTextAlignment.center,
            lineAlignment: PdfVerticalAlignment.bottom));*/
    //Create data foramt and convert it to text.
    final DateFormat format = DateFormat.yMMMMd('en_US');
    //final String invoiceNumber = 'Invoice Number: 2058557939\r\n\r\nDate: ${format.format(DateTime.now())}';
    final String invoiceNumber = 'Consultation Date: $consultationDate';
    final Size contentSize = contentFont.measureString(invoiceNumber);
    // ignore: leading_newlines_in_multiline_strings
    String address = '''Doctor Name: $doctorName \r\n\r\nPatient Name: $patientName, \r\n\r\nDisease Name : $diseaseName ''';

    PdfTextElement(text: invoiceNumber, font: contentFont).draw(
        page: page,
        bounds: Rect.fromLTWH(pageSize.width - (contentSize.width + 30), 120,
            contentSize.width + 30, pageSize.height - 120));

    return PdfTextElement(text: address, font: contentFont).draw(
        page: page,
        bounds: Rect.fromLTWH(30, 120,
            pageSize.width - (contentSize.width + 30), pageSize.height - 120))!;
  }

  //Draws the grid
  void drawGrid(PdfPage page, PdfGrid grid, PdfLayoutResult result) {
    Rect? totalPriceCellBounds;
    Rect? quantityCellBounds;
    //Invoke the beginCellLayout event.
    grid.beginCellLayout = (Object sender, PdfGridBeginCellLayoutArgs args) {
      final PdfGrid grid = sender as PdfGrid;
      if (args.cellIndex == grid.columns.count - 1) {
        totalPriceCellBounds = args.bounds;
      } else if (args.cellIndex == grid.columns.count - 2) {
        quantityCellBounds = args.bounds;
      }
    };
    //Draw the PDF grid and get the result.
    result = grid.draw(page: page, bounds: Rect.fromLTWH(0, result.bounds.bottom + 40, 0, 0))!;

    //Draw grand total.
    /*page.graphics.drawString('Grand Total', PdfStandardFont(PdfFontFamily.helvetica, 9, style: PdfFontStyle.bold),
        bounds: Rect.fromLTWH(
            quantityCellBounds!.left,
            result.bounds.bottom + 10,
            quantityCellBounds!.width,
            quantityCellBounds!.height));*/
    /*page.graphics.drawString(getTotalAmount(grid).toString(),
        PdfStandardFont(PdfFontFamily.helvetica, 9, style: PdfFontStyle.bold),
        bounds: Rect.fromLTWH(
            totalPriceCellBounds!.left,
            result.bounds.bottom + 10,
            totalPriceCellBounds!.width,
            totalPriceCellBounds!.height));*/
  }

  //Draw the invoice footer data.
  void drawFooter(PdfPage page, Size pageSize) {
    final PdfPen linePen =
    PdfPen(PdfColor(142, 170, 219), dashStyle: PdfDashStyle.custom);
    linePen.dashPattern = <double>[3, 3];
    //Draw line
    page.graphics.drawLine(linePen, Offset(0, pageSize.height - 100),
        Offset(pageSize.width, pageSize.height - 100));

    const String footerContent =
    // ignore: leading_newlines_in_multiline_strings
    '''800 Interchange Blvd.\r\n\r\nSuite 2501, Austin,
         TX 78721\r\n\r\nAny Questions? support@adventure-works.com''';

    //Added 30 as a margin for the layout
    page.graphics.drawString(
        footerContent, PdfStandardFont(PdfFontFamily.helvetica, 9),
        format: PdfStringFormat(alignment: PdfTextAlignment.right),
        bounds: Rect.fromLTWH(pageSize.width - 30, pageSize.height - 70, 0, 0));
  }

  //Create PDF grid and return
  PdfGrid getGrid() {
    //Create a PDF grid
    final PdfGrid grid = PdfGrid();
    //Secify the columns count to the grid.
    grid.columns.add(count: headerRowList.length);
    //Create the header row of the grid.
    final PdfGridRow headerRow = grid.headers.add(1)[0];

    //Set style
    headerRow.style.backgroundBrush = PdfSolidBrush(PdfColor(68, 114, 196));
    headerRow.style.textBrush = PdfBrushes.white;

   /* headerRow.cells[0].value = 'Product Id';
    headerRow.cells[0].stringFormat.alignment = PdfTextAlignment.center;
    headerRow.cells[1].value = 'Product Name';
    headerRow.cells[2].value = 'Price';
    headerRow.cells[3].value = 'Quantity';
    headerRow.cells[4].value = 'Total';*/

    for(int i=0; i<headerRowList.length; i++){
      headerRow.cells[i].value = headerRowList[i].toString();

    }
    for(int i=0; i<reportRowList.length; i++){
      addProducts(reportRowList[i].medicineName,
          reportRowList[i].atMorning,
          reportRowList[i].atAfternoon,
          reportRowList[i].atEvening,
          reportRowList[i].beforOrAfter,
          reportRowList[i].medicineWith,
          reportRowList[i].medicineSchedule,
          reportRowList[i].medicineType,
          reportRowList[i].drugName,
          reportRowList[i].medicinePrice,
          reportRowList[i].manufacturer,
          grid);
    }

    //Add rows

    /*addProducts('LJ-0192', 'Long-Sleeve Logo Jersey,M', 49.99, 3, 149.97, grid);
    addProducts('So-B909-M', 'Mountain Bike Socks,M', 9.5, 2, 19, grid);
    addProducts('LJ-0192', 'Long-Sleeve Logo Jersey,M', 49.99, 4, 199.96, grid);
    addProducts('FK-5136', 'ML Fork', 175.49, 6, 1052.94, grid);
    addProducts('HL-U509', 'Sports-100 Helmet,Black', 34.99, 1, 34.99, grid);*/

    //Apply the table built-in style
    grid.applyBuiltInStyle(PdfGridBuiltInStyle.listTable4Accent5);
    //Set gird columns width
    //grid.columns[1].width = 200;
    for (int i = 0; i < headerRow.cells.count; i++) {
      headerRow.cells[i].style.cellPadding = PdfPaddings(bottom: 5, left: 5, right: 5, top: 5);
    }
    for (int i = 0; i < grid.rows.count; i++) {
      final PdfGridRow row = grid.rows[i];
      for (int j = 0; j < row.cells.count; j++) {
        final PdfGridCell cell = row.cells[j];
        if (j == 0) {
          cell.stringFormat.alignment = PdfTextAlignment.center;
        }
        cell.style.cellPadding = PdfPaddings(bottom: 5, left: 5, right: 5, top: 5);
      }
    }
    return grid;
  }

  //Create and row for the grid.
  void addProducts(String medicineName, String atMorning, String atAfternoon,
      String atEvening,String beforOrAfter,String medicineWith,String medicineSchedule,
      String medicineType,String drugName,String medicinePrice,String manufacturer, PdfGrid grid) {

    final PdfGridRow row = grid.rows.add();

    row.cells[0].value = medicineName;
    row.cells[1].value = atMorning.toString();
    row.cells[2].value = atAfternoon.toString();
    row.cells[3].value = atEvening.toString();
    row.cells[4].value = beforOrAfter.toString();
    row.cells[5].value = medicineWith.toString();
    row.cells[6].value = medicineSchedule.toString();
    row.cells[7].value = medicineType.toString();
    row.cells[8].value = drugName.toString();
    row.cells[9].value = medicinePrice.toString();
    row.cells[10].value = manufacturer.toString();
  }

  //Get the total amount.
  /*double getTotalAmount(PdfGrid grid) {
    double total = 0;
    for (int i = 0; i < grid.rows.count; i++) {
      final String value =
      grid.rows[i].cells[grid.columns.count - 1].value as String;
      total += double.parse(value);
    }
    return total;
  }*/


  saveAndLaunchFile(List<int> bytes, String filepath) async {
    setState((){
      _isLoading = false;
    });
    final directory = Platform.isAndroid
        ? await getApplicationDocumentsDirectory() //FOR ANDROID
        : await getApplicationSupportDirectory();
    final path = directory.path;

    String filePath = '$path/$filepath';
    final file = File(filePath);
    await file.writeAsBytes(bytes, flush: true);
    Fluttertoast.showToast(
        msg: 'File save $filepath successfully.',
        backgroundColor: Colors.green,
        textColor: Colors.white,
        gravity: ToastGravity.CENTER,
        toastLength: Toast.LENGTH_SHORT);
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => SyncPDFScreen(filePath)),
    );

    log(filePath);
  }

}




