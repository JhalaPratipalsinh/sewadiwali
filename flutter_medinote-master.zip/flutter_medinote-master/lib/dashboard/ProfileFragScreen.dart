
import 'dart:convert';
import 'dart:developer';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_medinote/dashboard/EditProfile.dart';
import 'package:flutter_medinote/utils/VariableBag.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../login/LoginTypeScreen.dart';
import '../response/GetprofileResponse.dart';

import '../utils/PreferenceManager.dart';
import 'package:http/http.dart' as http;

class ProfileFragScreen extends StatefulWidget {
  const ProfileFragScreen({Key? key}) : super(key: key);

  @override
  State<ProfileFragScreen> createState() => _ProfileFragScreenState();
}

class _ProfileFragScreenState extends State<ProfileFragScreen> {
  var Mob,email,name,userId,proName="",proEmail="";
  var profile_responce;
  Uint8List? _pickedImage;
  bool isLoading = false;
  @override
  void initState() {
    isLoading = false;
    super.initState();

    PreferenceManager.instance.getStringValue("mobileno")
        .then((value) => setState(() {
      Mob = value;
    }));
    PreferenceManager.instance.getStringValue("uesrEmail")
        .then((value) => setState(() {
      email = value;
    }));
    PreferenceManager.instance.getStringValue("userName")
        .then((value) => setState(() {
      name = value;
    }));
    PreferenceManager.instance.getStringValue("userId").then((value) =>
        setState(() {
          userId = value;
          _profileData();
        }));

  }
  @override
  void setState(fn) {
    if(mounted) {
      super.setState(fn);
    }
  }
  Future<void> _profileData() async {
    Map data = {
      "user_id": userId,
      "customer_id": "",
      "mobile_no": Mob,
      "email": email,
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/GetMediNoteUserProfile"),body: data)
    ]).then((response) {
      var jsonData = null;
      setState(() {
        isLoading = false;
      });
      if(response[0].statusCode==200){
        jsonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = GetprofileResponse.fromJson(map);

        if(response1.settings.success=="1"){

            setState((){
              proName = response1.data[0].userName;
              proEmail = response1.data[0].emailId;
              _pickedImage = const Base64Decoder().convert(response1.data[0].profilePhoto);
            });
        }
      }else{
        print("status code wrong");
      }
    },onError: (error){
      Fluttertoast.showToast(msg: error.toString(),textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.CENTER);
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
          children: [
            SizedBox(
              height: MediaQuery.of(context).size.height / 4,
              width: MediaQuery.of(context).size.width,
              child: ClipPath(
                clipper: CustomClipPath(),
                child: Container(
                  color: const Color(0xFF00777F),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(30.0),
              child: Column(
                children: [
                  Flexible(
                    child: Container(
                      decoration: const BoxDecoration(
                          boxShadow: [BoxShadow(
                            color: Colors.black,
                            blurRadius: 1.5,
                          ),
                          ],
                          color: Colors.white,
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                      width: MediaQuery.of(context).size.width / 1,
                      height: MediaQuery.of(context).size.height / 4,
                      child: Column(
                        children: [
                          const SizedBox(
                            height: 10,
                          ),
                          Flexible(
                            child: Column(
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                        color: const Color(0xFF00777F), width: 2),
                                    borderRadius: const BorderRadius.all(
                                      Radius.circular(100),
                                    ),
                                  ),
                                  child: SizedBox.fromSize(
                                    size: const Size(60, 60),
                                    child: ClipOval(
                                      // ignore: unnecessary_null_comparison
                                      child: _pickedImage != null
                                          ? Image.memory(
                                        _pickedImage!,
                                        fit: BoxFit.cover,
                                      )
                                          : Image.asset('images/user_default.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.center,
                                  child: Padding(
                                    padding: EdgeInsets.all(10.0),
                                    child: Text("$proName"),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.center,
                                  child: Padding(
                                    padding: EdgeInsets.all(6.0),
                                    child: Text("$proEmail",style: TextStyle(fontSize: 15)),
                                  ),
                                ),
                                Flexible(
                                  child: Align(
                                    alignment: Alignment.center,
                                    child: Padding(
                                        padding: const EdgeInsets.only(right: 0),
                                        child: ElevatedButton(
                                            style: ButtonStyle(
                                                backgroundColor:
                                                MaterialStateProperty.all(
                                                  const Color(0xFF00777F),
                                                ),
                                                shape: MaterialStateProperty.all<
                                                    RoundedRectangleBorder>(
                                                    RoundedRectangleBorder(
                                                      borderRadius:
                                                      BorderRadius.circular(10.0),
                                                    ))),
                                            child: const Text(
                                              ' EDIT PROFILE ',
                                              style: TextStyle(fontSize: 15),
                                            ),
                                            onPressed: () async {

                                              final reLoadPage = await Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context) => EditProfile(),));

                                              if (reLoadPage) {
                                                setState(() {
                                                  _profileData();
                                                });
                                              }
                                            })),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 25,
                  ),
                  Flexible(
                    child: InkWell(

                      onTap: () => showDialog(
                          context: context,
                          builder: (BuildContext context) => Dialog(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16.0)),
                              elevation: 10.0,
                              backgroundColor: Colors.transparent,
                              child: Container(
                                  margin:
                                  const EdgeInsets.only(left: 0.0, right: 0.0),
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: <Widget>[
                                      Container(
                                        padding: const EdgeInsets.only(
                                          top: 15.0,
                                        ),
                                        margin: const EdgeInsets.only(
                                            top: 13.0, right: 8.0),
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            shape: BoxShape.rectangle,
                                            borderRadius:
                                            BorderRadius.circular(15.0)),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                          CrossAxisAlignment.stretch,
                                          children: <Widget>[
                                            Padding(
                                              padding:
                                              const EdgeInsets.only(left: 10),
                                              child: Container(
                                                padding: const EdgeInsets.all(8),
                                                child: const Text(
                                                  "Logout",
                                                  style: TextStyle(
                                                      fontSize: 20,
                                                      fontWeight: FontWeight.bold),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding:
                                              const EdgeInsets.only(left: 10),
                                              child: Container(
                                                padding: const EdgeInsets.all(9),
                                                child: const Text(
                                                    "Are you sure want to Logout..?",
                                                    style: TextStyle(fontSize: 19),
                                                    textScaleFactor: 1),
                                              ),
                                            ),
                                            const SizedBox(height: 17.0),
                                            Row(
                                              mainAxisAlignment:
                                              MainAxisAlignment.start,
                                              crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                              children: [
                                                Flexible(
                                                  child: InkWell(
                                                    child: Container(
                                                      height: MediaQuery.of(context).size.height / 24,
                                                      width: MediaQuery.of(context).size.width / 2,
                                                      padding: const EdgeInsets.all(5),
                                                      decoration: const BoxDecoration(
                                                          color: Color(0xFF00777F),
                                                          borderRadius: BorderRadius.only(bottomLeft: Radius.circular(15))),
                                                      child: const Text(
                                                        "cancel",
                                                        style: TextStyle(
                                                            color: Colors.white,
                                                            fontSize: 18.0,
                                                            fontFamily:
                                                            'poppins_regular'),
                                                        textAlign: TextAlign.center,
                                                      ),
                                                    ),
                                                    onTap: () {
                                                      Navigator.pop(context);
                                                    },
                                                  ),
                                                ),
                                                Flexible(
                                                  child: InkWell(
                                                    child: Container(
                                                      height: MediaQuery.of(context).size.height / 24,
                                                      width: MediaQuery.of(context).size.width / 2,
                                                      padding: const EdgeInsets.all(5),
                                                      decoration: const BoxDecoration(
                                                          color: Color(0xFF00777F),
                                                          borderRadius: BorderRadius.only(bottomRight: Radius.circular(15.0),)),
                                                      child: const Text(
                                                        "Yes",
                                                        style: TextStyle(
                                                            color: Colors.white,
                                                            fontSize: 18.0,
                                                            fontFamily:
                                                            'poppins_regular'),
                                                        textAlign: TextAlign.center,
                                                      ),
                                                    ),
                                                    onTap: () => {
                                                     /*   PreferenceManager.instance.removeAll(),
                                                    Navigator.of(context).pushReplacement(MaterialPageRoute(
                                                  builder: (BuildContext context) => LoginTypeScreen(),
                                                  )),*/
                                                    userlogout(),
                                                    Navigator.pop(context),
                                                    },
                                                  ),
                                                ),
                                              ],
                                            )
                                          ],
                                        ),
                                      ),
                                    ],
                                  )))),
                      child: Container(
                        decoration: const BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black,
                                blurRadius: 1.5,
                              ),
                            ],
                            color: Colors.white,
                            borderRadius: BorderRadius.all(Radius.circular(10))),
                        height: MediaQuery.of(context).size.height / 11,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                                padding: const EdgeInsets.only(left: 20),
                                child: Image(
                                  color: const Color(0xFF00777F),
                                  height: MediaQuery.of(context).size.height / 30,
                                  image: const AssetImage("images/logout.png"),
                                )),
                            const Expanded(
                              child: Padding(
                                padding: EdgeInsets.all(10),
                                child: Text(
                                  "  Logout",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold, fontSize: 17),
                                ),
                              ),
                            ),
                            const Padding(
                              padding: EdgeInsets.only(right: 20),
                              child: Icon(
                                Icons.arrow_forward_ios,
                                color: Color(0xFF00777F),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ));
  }

  Future<dynamic> userlogout() async {
    setState(() {
      isLoading = true;
    });
    Map data = {
      "user_id": userId,
    };
    log('Logout  Body  :=> ${BASE_URL}MobileApp/MediNoteUserLogOut Api Body ==> $data');

    await Future.wait([
      http.post(Uri.parse(BASE_URL + "MobileApp/MediNoteUserLogOut"), body: data),
    ]).then((value) {
      if (!mounted) return;
      setState(() {
        isLoading = false;
      });
      var jsonData = null;
      var success;
      if (value[0].statusCode == 200) {
        jsonData = json.decode(value[0].body);
        var map = Map<String, dynamic>.from(jsonData);
        map.forEach((key, value) {
          if (key == "settings") {
            if (map["settings"]["success"] != null) {
              success = map["settings"]["success"].toString();
              log('UserLogOut :=>Next Page ==> $success');
            }
          }
        });
        if (success == "1") {
          Fluttertoast.showToast(msg: "Logout successfully!", textColor: Colors.white, backgroundColor: Colors.green, gravity: ToastGravity.CENTER, toastLength: Toast.LENGTH_SHORT);

          PreferenceManager.instance.removeAll();
          if (mounted) {
            setState(() {
              Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (context) => const LoginTypeScreen()), (route) => false);
            });
          }
        } else {
          Fluttertoast.showToast(msg: success.toString(), textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER);
        }

        log('DashBoard Load More:=> ${BASE_URL}MobileApp//UserLogOut:: ${json.decode(value[0].body)}');
      } else {
        log("Expense  not found exception");
      }
    }, onError: (error) {
      if (!mounted) return;
      setState(() {
        isLoading = false;
      });
      Fluttertoast.showToast(msg: error.toString(), textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER);
    });
  }

}

class CustomClipPath extends CustomClipper<Path> {
  var radius = 10.0;

  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(0, 0);
    path.lineTo(0, size.height - 70);
    path.quadraticBezierTo(
        size.width / 2, size.height, size.width, size.height - 70);
    path.lineTo(size.width, 0);
    path.lineTo(0, 0);

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
