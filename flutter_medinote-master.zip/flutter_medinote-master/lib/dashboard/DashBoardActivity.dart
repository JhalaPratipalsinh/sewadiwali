
import 'package:flutter/material.dart';
import 'package:flutter_medinote/dashboard/ConsultationFragScreen.dart';
import 'package:flutter_medinote/dashboard/LabFragScreen.dart';
import 'package:flutter_medinote/dashboard/ListFragScreen.dart';
import 'package:flutter_medinote/dashboard/ProfileFragScreen.dart';
import 'package:flutter_medinote/utils/AppColors.dart';

class DashBoardActivity extends StatefulWidget {
  const DashBoardActivity({Key? key}) : super(key: key);

  @override
  State<DashBoardActivity> createState() => _DashBoardActivityState();
}

class _DashBoardActivityState extends State<DashBoardActivity> {
  int _selectedIndex = 0;
  static const TextStyle optionStyle = TextStyle(fontSize: 30, fontWeight: FontWeight.bold);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Medinote"),
      backgroundColor: PrimaryColor,),
      body: Container(child: Center(child: _widgetOptions.elementAt(_selectedIndex),),),
      bottomNavigationBar: CreateBottombar(context),
    );
  }


  final _widgetOptions = [
    new ListFragScreen(),
    new ConsultationFragScreen(),
    new LabFragScreen(),
    new ProfileFragScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  Container CreateBottombar(BuildContext context) {
    return Container(
      //add ClipRRect widget for Round Corner
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
          topRight: Radius.circular(24),
          topLeft: Radius.circular(24),
        ),
        child: BottomNavigationBar(
          //add background color
          backgroundColor: PrimaryColor,
          type: BottomNavigationBarType.fixed,
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Padding(
                padding: EdgeInsets.all(5.0),
                child: ImageIcon(AssetImage('images/list.png'),size: 20,),
              ),
              label: 'List',
            ),
            BottomNavigationBarItem(
              icon: ImageIcon(AssetImage('images/consultation.png'),size: 30,),
              label: 'Consultation',
            ),
            BottomNavigationBarItem(
              icon: Padding(
                padding: EdgeInsets.all(5.0),
                child: ImageIcon(AssetImage('images/lab.png')),
              ),
              label: 'Lab',
            ),
            BottomNavigationBarItem(
              icon: Padding(
                padding: EdgeInsets.all(5.0),
                child: ImageIcon(AssetImage('images/profile.png')),
              ),
              label: 'Profile',
            ),

          ],
          currentIndex: _selectedIndex,
          selectedItemColor: Colors.white,
          onTap: _onItemTapped,
        ),
      ),
    );
  }
}
