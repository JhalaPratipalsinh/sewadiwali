
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_medinote/login/OTPVerificationActivtiy.dart';
import 'package:loading_overlay/loading_overlay.dart';

import '../response/MobileVerificationResponse.dart';
import '../utils/AppColors.dart';
import 'package:http/http.dart' as http;

import '../utils/PreferenceManager.dart';

class LoginActivity extends StatefulWidget {
  const LoginActivity({Key? key}) : super(key: key);

  @override
  State<LoginActivity> createState() => _LoginActivityState();
}

class _LoginActivityState extends State<LoginActivity> {
  var _formkey = GlobalKey<FormState>();
  var _isLoading = false;
  var mobileno = null;
  var code = null;
  var customerId = "";

  TextEditingController _controllerCode = TextEditingController();
  late ScaffoldMessengerState _scaffoldMessengerState;
  var mobilenumber = null;

  Future <void>   _submit() async {

    if (_isLoading) {
      return;
    }
    final isValid = _formkey.currentState!.validate();

    if (isValid) {
      setState(() {
        _isLoading = true;
      });
      if (code == null) {
        mobilenumber = "+"+code + mobileno;
      } else {
        mobilenumber = "+91" + mobileno;
      }

      Map data = {
        'customer_id': customerId,
        'mobile_number': mobilenumber
      };
      final response = await http.post(
        Uri.parse("https://safal.datanote.co.in/api/medinote/MobileApp/UserMobileVerificationForMediNote"), body: data,);
      setState(() {
        _isLoading = false;
      });
      var jsonData = null;
      if (response.statusCode == 200) {
        jsonData = json.decode(response.body);
        var map = Map<String, dynamic>.from(jsonData);
        var response1 = MobileVerificationResponse.fromJson(map);

        print(response1.settings.message);
        Map<String, dynamic> resposne = jsonDecode(response.body);
        if (response1.settings.success == "1") {
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message)));
          PreferenceManager.instance.setStringValue("UserPId", response1.data[0].userPId);
          PreferenceManager.instance.setStringValue("userId", response1.data[0].userId);
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => OTPVerificationActivtiy(), settings: RouteSettings(arguments: response1,)),);
        } else {
          _scaffoldMessengerState.showSnackBar(SnackBar(
              content: Text(response1.settings.message,
                  style: TextStyle(fontFamily: "poppins_regular", fontSize: 14.0))));
        }
      } else {
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Please try again!")));
      }
    } else {
      return;
    }

  }

  @override
  Widget build(BuildContext context) {
    _controllerCode.text = '+91';
    _scaffoldMessengerState = ScaffoldMessenger.of(context);

    return Scaffold(
      body: LoadingOverlay(
        isLoading: _isLoading,
        color: Colors.black54,
        opacity: 0.6,
        child: SingleChildScrollView(
          child: Stack(
            children: [
              Padding(
                padding: const EdgeInsets.all(0.0),
                child: ClipPath(
                  clipper: CustomClipPath(),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: 350,
                    color: Color(0xFF00777F),
                  ),
                ),
              ),
              Form(
                key: _formkey,
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left:  20.0,top: 130),
                      child: Text("Welcome to",
                      style: TextStyle(
                        fontSize: 25,color: Colors.white,fontWeight: FontWeight.bold ),),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left:  30.0),
                      child: Image.asset('images/logo_squre_midinote_white.png',
                      width: 130,
                      height: 130,),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 30.0, top: 140.0, right: 30.0),
                      child: Row(
                        children: [
                          Flexible(
                            flex: 1,
                            child: Container(
                              child: TextFormField(
                                initialValue: "+91",
                                maxLength: 3,
                                textAlign: TextAlign.left,
                                decoration: InputDecoration(
                                    fillColor: Colors.white,
                                    labelStyle: TextStyle(color: Colors.grey[800]),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.all(Radius.circular(10.0),),
                                      borderSide: BorderSide(color: Color(0xFF00777F),width: 2),
                                    ),
                                    border: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(Radius.circular(10.0),)
                                    ),
                                    filled: true,
                                    hintStyle:
                                    TextStyle(color: Colors.grey[800]),
                                    labelText: "Code",
                                    contentPadding:
                                    EdgeInsets.only(left: 30.0),
                                    hintText: "+91"),
                                keyboardType: TextInputType.number,
                                onFieldSubmitted: (value) {},
                                validator: (value) {
                                  code = value;
                                },
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 20,
                          ),
                          Flexible(
                            flex: 2,
                            child: Container(
                              child: TextFormField(
                                maxLength: 10,
                                textAlign: TextAlign.left,
                                decoration: InputDecoration(
                                    fillColor: Colors.white,
                                    labelStyle: TextStyle(color: Colors.grey[800]),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.all(Radius.circular(10.0),),
                                      borderSide: BorderSide(color: Color(0xFF00777F),width: 2),
                                    ),
                                    border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10.0))),
                                    filled: true,
                                    hintStyle:
                                    TextStyle(color: Colors.grey[800]),
                                    labelText: "Mobile No.",
                                    contentPadding:
                                    EdgeInsets.only(left: 30.0),
                                    hintText: "Enter mobile no."
                                ),
                                keyboardType: TextInputType.phone,
                                onFieldSubmitted: (value) {},
                                validator: (value) {
                                  mobileno = value;
                                  if (mobileno!.isEmpty || !RegExp(r'^(?:[+0]9)?[0-9]{10}$').hasMatch(mobileno)) {

                                    return 'Enter valid mobile number.';
                                  }
                                  return null;
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                        padding: EdgeInsets.only(left: 30.0, top: 20.0, right: 30.0),
                      child: Center(
                      child: Text("We will send you an One Time Password \n on this number",
                        style: TextStyle(fontSize: 17,color: grey_60),textAlign: TextAlign.center,),
                    ),),
                    Container(
                      padding: EdgeInsets.only(left: 30.0, top: 60.0, right: 30.0),
                      child: InkWell(

                        onTap: () {
                          if(_formkey.currentState!.validate()){
                            _submit();
                          }
                        },
                        child: new Container(
                          //width: 100.0,
                          height: 60.0,

                          decoration: new BoxDecoration(
                            color: PrimaryColor,
                            border: new Border.all(
                                color: Colors.white, width: 1.0),
                            borderRadius: new BorderRadius.circular(30.0),
                          ),
                          child: new Center(
                            child: new Text(
                              'Get OTP',
                              style: TextStyle(
                                color: Colors.white,
                                fontFamily: 'poppins_regular',
                                fontSize: 18,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

}

class CustomClipPath extends CustomClipper<Path> {
  var radius=10.0;
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(0, size.height);
    path.quadraticBezierTo(size.width/4, size.height - 40, size.width/2, size.height-40);
    path.quadraticBezierTo(3/4*size.width, size.height-40, size.width, size.height/2);
    path.lineTo(size.width, 0);

    return path;
  }
  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
