
import 'dart:async';
import 'dart:convert';
import 'dart:io' show Platform;
import 'package:http/http.dart' as http;
import 'package:device_info/device_info.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_medinote/dashboard/DashBoardActivity.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:firebase_core/firebase_core.dart';

import '../response/OtpVerificationResponse.dart';
import '../utils/AppColors.dart';
import '../utils/PreferenceManager.dart';

class OTPVerificationActivtiy extends StatefulWidget {
  const OTPVerificationActivtiy({Key? key}) : super(key: key);

  @override
  State<OTPVerificationActivtiy> createState() => _OTPVerificationActivtiyState();
}

class _OTPVerificationActivtiyState extends State<OTPVerificationActivtiy> {
  var _formkey = GlobalKey<FormState>();
  TextEditingController _textEditingController = TextEditingController();
  StreamController<ErrorAnimationType>? errorController;
  bool hasError = false;

  late String phoneNo;
  late String smsOTP;
  late String verificationId,loginType;
  String errorMessage = '';
  String text = '';
  var _isLoading = false;


  static int listLength = 5;
  List<FocusNode> _focusNodes =
  List<FocusNode>.generate(listLength, (int index) => FocusNode());
  List<TextEditingController> _text = List<TextEditingController>.generate(
      listLength, (index) => TextEditingController());
  bool _validate = false;
  late ScaffoldMessengerState _scaffoldMessengerState;
  var  userId,device_brand,device_model,device_type ;

  var verify_code = null;

  var  CustomerId="", otpString;

  List listRoute = [];
  String? device_token;


  @override
  void initState() {
    errorController = StreamController<ErrorAnimationType>();
    // _startCountDown();
    super.initState();
    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {userId = value;}));

  }


  @override
  Widget build(BuildContext context) {

    _scaffoldMessengerState = ScaffoldMessenger.of(context);

    return Scaffold(
      body: LoadingOverlay(
        isLoading: _isLoading,
        color: Colors.black54,
        opacity: 0.6,
        child: SingleChildScrollView(
          child: Stack(
            children: [
              Padding(
                padding: const EdgeInsets.all(0.0),
                child: ClipPath(
                  clipper: CustomClipPath(),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: 350,
                    color: const Color(0xFF00777F),
                  ),
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(left:  20.0,top: 130),
                    child: Text("Welcome to",
                      style: TextStyle(
                          fontSize: 25,color: Colors.white,fontWeight: FontWeight.bold ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left:  30.0),
                    child: Image.asset('images/logo_squre_midinote_white.png',
                      width: 130,
                      height: 130,),
                  ),


                  Padding(
                    padding:
                    EdgeInsets.only(left: 30.0, top: 70.0, right: 30.0),
                    child: Text(
                      "Please enter the verification code \n sent to Mobile Number",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontFamily: "poppins_regular", color: Colors.black54, fontSize: 16.0),
                    ),
                  ),

                  Form(
                    key: _formkey,
                    child: Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 28.0, horizontal: 60),
                        child: PinCodeTextField(
                          appContext: context,
                          pastedTextStyle: TextStyle(
                            color: Colors.green.shade600,
                            fontWeight: FontWeight.bold,
                          ),
                          length: 4,
                          obscureText: true,
                          obscuringCharacter: '*',
                          obscuringWidget: FlutterLogo(
                            size: 24,
                          ),
                          blinkWhenObscuring: true,
                          animationType: AnimationType.fade,
                          validator: (v) {
                            if (v!.length < 3) {
                              return "Please enter otp";
                            } else {
                              return null;
                            }
                          },
                          pinTheme: PinTheme(
                            shape: PinCodeFieldShape.box,
                            borderRadius: BorderRadius.circular(5),
                            fieldHeight: 50,
                            fieldWidth: 50,
                            inactiveColor: Colors.grey,
                            disabledColor: Colors.transparent,
                            inactiveFillColor: Colors.white,
                            activeColor: Colors.white,
                            selectedFillColor: Colors.white,
                            borderWidth: 1,
                            activeFillColor: Colors.white,
                          ),

                          cursorColor: Colors.black54,
                          animationDuration: Duration(milliseconds: 300),
                          enableActiveFill: true,
                          errorAnimationController: errorController,
                          controller: _textEditingController,
                          keyboardType: TextInputType.number,
                          boxShadows: [
                            BoxShadow(
                              offset: Offset(0, 1),
                              color: Colors.black12,
                              blurRadius: 10,
                            )
                          ],
                          onCompleted: (v) {
                            print("Completed");
                          },
                          // onTap: () {
                          //   print("Pressed");
                          // },
                          onChanged: (value) {
                            print(value);
                            setState(() {
                              otpString = value;
                            });
                          },
                          beforeTextPaste: (text) {
                            print("Allowing to paste $text");
                            //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                            //but you can show anything you want here, like your pop up saying wrong paste format or etc
                            return true;
                          },
                        )),
                  ),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 30.0),
                    child: Text(
                      hasError
                          ? "*Please fill up all the cells properly"
                          : "",
                      style: TextStyle(
                          color: Colors.red,
                          fontSize: 12,
                          fontWeight: FontWeight.w400),
                    ),
                  ),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Didn't receive the code? ",
                        style:
                        TextStyle(color: Colors.black54, fontSize: 15),
                      ),
                      TextButton(
                          onPressed: () => {
                            snackBar("OTP resend!!"),
                            // _startCountDown()
                          },
                          child: Text(
                            "RESEND",
                            style: TextStyle(
                                color: Color(0xFF757575),
                                fontWeight: FontWeight.bold,
                                fontSize: 16),
                          ))
                    ],
                  ),

                  Container(
                    padding:
                    EdgeInsets.only(left: 30.0, top: 60.0, right: 30.0),
                    child: InkWell(
                      onTap: () {
                        _formkey.currentState!.validate();
                        // conditions for validating
                        if (otpString.length != 4) {
                          errorController!.add(ErrorAnimationType.shake); // Triggering error shake animation
                          setState(() => hasError = true);
                        } else {
                          setState(() {
                            hasError = false;
                            _submit();
                          },
                          );
                        }
                      },
                      child: new Container(
                        //width: 100.0,
                        height: 60.0,

                        decoration: new BoxDecoration(
                          color: PrimaryColor,
                          border: new Border.all(
                              color: Colors.white, width: 1.0),
                          borderRadius: new BorderRadius.circular(30.0),
                        ),
                        child: new Center(
                          child: new Text(
                            'Verify OTP',
                            style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'poppins_regular',
                              fontSize: 18,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  snackBar(String? message) {
    return ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message!),
        duration: Duration(seconds: 2),
      ),
    );
  }

  Future<void> _submit() async {

    //Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => DashBoardActivity()));
    if (Platform.isAndroid) {
      var androidInfo = await DeviceInfoPlugin().androidInfo;
      var release = androidInfo.version.release;
      var sdkInt = androidInfo.version.sdkInt;
      var manufacturer = androidInfo.manufacturer;
      var model = androidInfo.model;
      device_type = 'Android $release (SDK $sdkInt)';
      device_brand = manufacturer;
      device_model = androidInfo.model;
      print('Android $release (SDK $sdkInt), $manufacturer $model');
      // Android 9 (SDK 28), Xiaomi Redmi Note 7
      print("$device_type");
      print("$device_brand");
      print("$device_model");

    }

    if (Platform.isIOS) {
      var iosInfo = await DeviceInfoPlugin().iosInfo;
      var systemName = iosInfo.systemName;
      var version = iosInfo.systemVersion;
      device_type = iosInfo.systemName;
      device_brand = iosInfo.name;
      device_model = iosInfo.model;
      // print('$systemName $version, $name $model');
      print('$device_type $device_brand, $device_model');
      // iOS 13.1, iPhone 11 Pro Max iPhone
    }



    await Firebase.initializeApp();
    device_token = await FirebaseMessaging.instance.getToken();



    print("$userId");
    print("$device_token");

    if (_isLoading) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    Map data = {
      'customer_id': CustomerId.toString().trim(),
      'verify_code': otpString,
      'user_id': userId,
      'device_token': device_token,
      'device_type': device_type,
      'device_model': device_model,
      'device_brand': device_brand
    };

    final response = await http.post(
      Uri.parse("https://safal.datanote.co.in/api/medinote/MobileApp/MediNoteUserOTPVerification"), body: data,);
    setState(() {
      _isLoading = false;
    });
    var jsonData = null;
    if (response.statusCode == 200) {
      jsonData = json.decode(response.body);

      var map = Map<String, dynamic>.from(jsonData);
      var response1 = OtpVerificationResponse.fromJson(map);

      if (response1.settings.success == "1") {

        PreferenceManager.instance.setBooleanValue("loggedin", true);
        PreferenceManager.instance.setStringValue("mobileno", response1.data[0].mobile);
        PreferenceManager.instance.setStringValue("uesrEmail", response1.data[0].email);
        PreferenceManager.instance.setStringValue("userName", response1.data[0].userName);
        PreferenceManager.instance.setStringValue("userRelation", response1.data[0].relation);
        PreferenceManager.instance.setStringValue("userGender", response1.data[0].gender);
        PreferenceManager.instance.setStringValue("deviceToken", device_token!);


        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message)));

        /*if(loginType=="Customer" ){
          Navigator.pushReplacement(context, MaterialPageRoute(
              builder: (context) => DashBoardScreen(), settings: RouteSettings(arguments: response1,)),);
        }else{
          Navigator.pushReplacement(context, MaterialPageRoute(
              builder: (context)=>ClientDashBoard(),settings: RouteSettings(arguments: response1)),);
        }*/

        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => DashBoardActivity()));
      } else {
        _scaffoldMessengerState.showSnackBar(SnackBar(
            content: Text(response1.settings.message,
                style: TextStyle(fontFamily: "poppins_regular", fontSize: 14.0))));
      }
    } else {
      _scaffoldMessengerState.showSnackBar(SnackBar(
          content: Text("Something went wrong please try again later.")));
    }
  }


  @override
  void dispose() {
    errorController!.close();
    // _otpCountDown.cancelTimer();
    super.dispose();
  }
}

class CustomClipPath extends CustomClipper<Path> {
  var radius=10.0;
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(0, size.height);
    path.quadraticBezierTo(size.width/4, size.height - 40, size.width/2, size.height-40);
    path.quadraticBezierTo(3/4*size.width, size.height-40, size.width, size.height/2);
    path.lineTo(size.width, 0);

    return path;
  }
  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
