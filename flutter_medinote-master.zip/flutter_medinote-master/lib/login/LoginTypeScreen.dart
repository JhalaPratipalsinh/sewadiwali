

import 'package:flutter/material.dart';
import 'package:flutter_medinote/login/LoginActivity.dart';

class LoginTypeScreen extends StatefulWidget {
  const LoginTypeScreen({Key? key}) : super(key: key);

  @override
  State<LoginTypeScreen> createState() => _LoginTypeScreenState();
}

class _LoginTypeScreenState extends State<LoginTypeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
            padding: const EdgeInsets.only(top: 200.0),
            child: Center(
              child: Container(
                child: Image.asset('images/logo_squre_midinote.png',
                height: 200,
                width: 200,),
              ),
            ),
          ),
              Padding(
                padding: const EdgeInsets.only(left: 8.0,right: 8.0,top: 50),
                child: InkWell(
                  onTap: () {
                    Navigator.of(context).pushReplacement(MaterialPageRoute(
                        builder: (context) => LoginActivity(),));
                  },
                  child: Container(
                    height: 50,
                    decoration: BoxDecoration(
                      color: Color(0xFF00777F),
                      border: Border.all(color: Color(0xFF00777F)),
                      borderRadius: BorderRadius.circular(30.0)
                    ),
                    child: Row(children: [
                      /*Icon(Icons.phone_android_sharp,size: 40,color: Colors.white,),*/
                      Padding(
                        padding: const EdgeInsets.only(left: 20.0),
                        child: Image.asset('images/smartphone.png',
                        height: 30,
                        width: 30,
                        color: Colors.white,),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10.0),
                        child: Text("Continue with phone number",
                        style: TextStyle(color: Colors.white),),
                      ),
                    ]),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 8.0,right: 8.0,top: 8.0),
                child: Container(
                  height: 50,
                  decoration: BoxDecoration(
                    color: Color(0xFF00777F),
                    border: Border.all(color: Color(0xFF00777F)),
                    borderRadius: BorderRadius.circular(30.0)
                  ),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 20.0),
                        child: Image.asset('images/google.png',
                        height: 30,
                        width: 30,),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10.0),
                        child: Text("Continue with google",
                          style: TextStyle(color: Colors.white),),
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 8.0,right: 8.0,top: 8.0),
                child: Container(
                  height: 50,
                  decoration: BoxDecoration(
                    color: Color(0xFF00777F),
                    border: Border.all(color: Color(0xFF00777F)),
                    borderRadius: BorderRadius.circular(30.0)
                  ),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 20.0),
                        child: Image.asset('images/facebook.png',
                        width: 30,
                        height: 30,
                        color: Colors.white ,),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10.0),
                        child: Text("Continue with facebook", style: TextStyle(color: Colors.white),),
                      ),
                    ],
                  ),
                ),
              ),
        ]),
      ),
    );
  }
}
