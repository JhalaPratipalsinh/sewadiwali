import 'package:flutter/material.dart';


var BASE_URL = "https://safal.datanote.co.in/api/medinote/";