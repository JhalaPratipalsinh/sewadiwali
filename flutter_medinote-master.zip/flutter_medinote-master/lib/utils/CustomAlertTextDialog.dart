import 'dart:convert';
import 'dart:developer';
import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:flutter_medinote/utils/AppColors.dart';
import 'package:flutter_medinote/utils/EmployeeTypeHelper.dart';
import 'package:flutter_medinote/utils/GetEditTextValueHelper.dart';
import 'package:fluttertoast/fluttertoast.dart';

class CustomAlertTextDialog extends StatefulWidget {

  const CustomAlertTextDialog({
      required this.dialogTitle,
      required this.doneTitle,
      required this.cancelTitle,
      required this.position,
      required this.onClick,
      required this.onCancel,
      required this.onDelete,
      required this.relationController,
      required this.editId,
      required this.editName,
      required this.editTxtField2,
      required this.editTxtField3,
      required this.txtFiel1,
      required this.txtFiel2IsVisible,
      required this.txtFiel3IsVisible,
      required this.isEdit,
    Key? key})
      : super(key: key);

  final String doneTitle, cancelTitle, position,editId,editName,editTxtField2,editTxtField3,dialogTitle,txtFiel1,isEdit;
  final bool txtFiel2IsVisible,txtFiel3IsVisible;


  final TextEditingController relationController;



  final Function(String,String, String,TextEditingController relationController,String,String) onClick;
  final Function(String) onCancel;
  final Function(String) onDelete;
  @override
  State<CustomAlertTextDialog> createState() =>
      _CustomAlertTextDialogState(
          dialogTitle,
          doneTitle,
          cancelTitle,
          position,
          onClick,
          onCancel,
          onDelete,
          relationController,
          editId,
          editName,
        editTxtField2,
        editTxtField3,
          txtFiel1,
        txtFiel2IsVisible,
        txtFiel3IsVisible,
          isEdit
      );
}

class _CustomAlertTextDialogState extends State<CustomAlertTextDialog> {

  late String cancelTitle,editId,editName,editTxtField2,editTxtField3,dialogTitle,txtFiel1,isEdit;
  final bool txtFiel2IsVisible,txtFiel3IsVisible;
  late String doneTitle;
  late String position;
  late TextEditingController relationController =TextEditingController();
  TextEditingController diseaseNameController = TextEditingController();
  TextEditingController txtfield2Controller = TextEditingController();
  TextEditingController txtfield3Controller = TextEditingController();

  late Function(String,String, String,TextEditingController relationController,String,String) onClick;
  late Function(String) onCancel;
  late Function(String) onDelete;

  var _search_controller;
  var customIcon = Container();


  var selectionName;


  var txtfield1Value="",txtfield2Value="",txtfield3Value="";

  var clientUrl;
  var customerId;
  var userId;

  var pageIndex = "1";

  var tools;

  var jsonData;
  var mapEntry;
  var map;

  @override
  void initState() {
    //setPreferenceValue();
    //tools = Tools(context);
   //searchresult.addAll(selectionList);
    SetData();
  }

  Future SetData() async{

    if(editName.toString()!=null && editName.toString().length>0){
      setState((){
        txtfield1Value = editName.toString();
        diseaseNameController.text = editName.toString();
      });
    }
    if(editTxtField2.toString()!=null && editTxtField2.toString().length>0){
      setState((){
        txtfield2Value = editTxtField2.toString();
        txtfield2Controller.text = editTxtField2.toString();
      });
    }
    if(editTxtField3.toString()!=null && editTxtField3.toString().length>0){
      setState((){
        txtfield3Value = editTxtField3.toString();
        txtfield3Controller.text = editTxtField3.toString();
      });
    }


  }

  /*setPreferenceValue() async {
    PreferenceManager preferenceManager = PreferenceManager.instance;
    setState(() {
      preferenceManager
          .getStringValue("clientUrl")
          .then((value) => setState(() {
                clientUrl = value;
              }));
      preferenceManager
          .getStringValue("customer_id")
          .then((value) => setState(() {
                customerId = value;
              }));
      preferenceManager.getStringValue("user_id").then((value) => setState(() {
            userId = value;
          }));
    });
  }*/

  _CustomAlertTextDialogState(

      this.dialogTitle,
      this.doneTitle,
      this.cancelTitle,
      this.position,
      this. onClick,
      this.onCancel,
      this.onDelete,
      this.relationController,
      this.editId,
      this.editName,
      this.editTxtField2,
      this.editTxtField3,
      this.txtFiel1,
      this.txtFiel2IsVisible,
      this.txtFiel3IsVisible,
      this.isEdit,
      );

  @override
  Widget build(BuildContext context) {

    SetData();
    return Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
        elevation: 0.0,
        backgroundColor: Colors.transparent,
        child: Container(
            margin: const EdgeInsets.only(left: 0.0, right: 0.0),
            child: Stack(
              alignment: Alignment.topCenter,
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.only(top: 0.0,),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.rectangle,
                      borderRadius: BorderRadius.circular(30.0)),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      /*Flexible(
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          child: Container(
                            height: 40,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(30),
                              color: Colors.white,
                              boxShadow: const [
                                BoxShadow(color: Color(0XFF555555), spreadRadius: 1),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Flexible(
                                  child: Container(
                                    margin: const EdgeInsets.only(
                                        left: 15, top: 18),
                                    child: TextField(
                                      textAlign: TextAlign.left,
                                      controller: _search_controller,
                                      decoration: const InputDecoration(
                                        border: InputBorder.none,
                                        hintStyle:
                                            TextStyle(color: Colors.grey),
                                        hintText: "Search ",
                                        counterText: "",
                                      ),
                                      onChanged: (value) {
                                        //filterSearchResults(value);
                                      },
                                      maxLines: 1,
                                      maxLength: 50,
                                    ),
                                  ),
                                  flex: 1,
                                ),
                                Flexible(
                                  child: IconButton(
                                      onPressed: () {},
                                      icon: const Icon(
                                        Icons.search,
                                        color: Color(0xFF555555),
                                      )),
                                  flex: 0,
                                )
                              ],
                            ),
                          ),
                        ),
                      ),*/
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Flexible(
                            child: Row(
                              children: [
                                Flexible(
                                  child: Container(
                                    width: MediaQuery.of(context).size.width ,
                                    height: 40,
                                    padding: const EdgeInsets.all(0),
                                    decoration: const BoxDecoration(
                                        color: PrimaryColor,
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(29),
                                            topRight: Radius.circular(29),

                                        )),
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          SizedBox(),
                                          Expanded(
                                            child: Align(
                                              alignment: Alignment.center,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 10.0),
                                                child: Text(
                                                  dialogTitle,
                                                  style: const TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 18.0,
                                                      fontFamily: 'poppins_regular'),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Visibility(
                                            visible: isEdit=="1"?false:true,
                                            child: Align(
                                              alignment: Alignment.centerRight,
                                              child: Padding(
                                                padding: const EdgeInsets.only(right: 10.0),
                                                child: InkWell(
                                                  onTap: (){
                                                    Navigator.pop(context);

                                                    onDelete(editId);
                                                  },
                                                  child: Container(
                                                    child: Icon(Icons.delete,color: Colors.white,),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 250,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 20.0,left: 8,right: 8),
                          child: Column(
                            children: [
                              //textfield1
                              TextFormField(
                                controller: diseaseNameController,
                                decoration: InputDecoration(
                                  labelText: txtFiel1,
                                  labelStyle: TextStyle(color: PrimaryColor),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: grey_60,width: 1),
                                    borderRadius: BorderRadius.circular(10)
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: grey_20),
                                    borderRadius: BorderRadius.circular(10)
                                  ),
                                ),
                                onChanged: (value){
                                  txtfield1Value = value.toString();
                                  print(txtfield1Value);
                                },
                              ),
                              //textfield2
                              Visibility(
                                visible: txtFiel2IsVisible,
                                  child: SizedBox(height: 10,)),
                              Visibility(
                                visible: txtFiel2IsVisible,
                                child: TextFormField(
                                  controller: txtfield2Controller,
                                  decoration: InputDecoration(
                                    labelText: "Laboratory Type",
                                    labelStyle: TextStyle(color: PrimaryColor),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: grey_60,width: 1),
                                      borderRadius: BorderRadius.circular(10)
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: grey_20),
                                      borderRadius: BorderRadius.circular(10)
                                    ),
                                  ),
                                  onChanged: (value){
                                    txtfield2Value = value.toString();
                                    print(txtfield2Value);
                                  },
                                ),
                              ),
                              //textfield3
                              Visibility(
                                visible: txtFiel3IsVisible,
                                  child: SizedBox(height: 10,)),
                              Visibility(
                                visible: txtFiel3IsVisible,
                                child: TextFormField(
                                  controller: txtfield3Controller,
                                  decoration: InputDecoration(
                                    labelText: "Laboratory Address",
                                    labelStyle: TextStyle(color: PrimaryColor),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: grey_60,width: 1),
                                      borderRadius: BorderRadius.circular(10)
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: grey_20),
                                      borderRadius: BorderRadius.circular(10)
                                    ),
                                  ),
                                  onChanged: (value){
                                    txtfield3Value = value.toString();
                                    print(txtfield3Value);
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 24.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Flexible(
                            child: InkWell(
                              child: Container(
                                width: MediaQuery.of(context).size.width / 2,
                                padding: const EdgeInsets.all(5),
                                decoration: const BoxDecoration(
                                    color: Color(0xFF555555),
                                    borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30))),
                                child: Text(
                                  cancelTitle,
                                  style: const TextStyle(color: Colors.white, fontSize: 18.0, fontFamily: 'poppins_regular'),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              onTap: () {
                                onCancel("sAJID");
                                Navigator.pop(context);
                              },
                            ),
                          ),
                          Flexible(
                            child: InkWell(
                              child: Container(
                                width: MediaQuery.of(context).size.width / 2,
                                padding: const EdgeInsets.all(5),
                                decoration: const BoxDecoration(
                                    color: Color(0XFFE66D0A),
                                    borderRadius: BorderRadius.only(
                                      bottomRight: Radius.circular(30.0),
                                    )),
                                child: Text(
                                  doneTitle,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 18.0,
                                      fontFamily: 'poppins_regular'),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              onTap: () => {
                                if(txtFiel2IsVisible){
                                  if (txtfield1Value != null && txtfield1Value.length>0){
                                    if (txtfield2Value != null && txtfield2Value.length>0){
                                      if (txtfield3Value != null && txtfield3Value.length>0){
                                        onClick(
                                          editId,
                                          txtfield1Value.toString(),
                                          position.toString(),
                                          relationController,
                                          txtfield2Value,
                                          txtfield3Value,

                                        ),
                                        Navigator.pop(context),
                                      } else {
                                        Fluttertoast.showToast(msg: "Please enter laboratory address.", textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER, toastLength: Toast.LENGTH_SHORT)
                                      }
                                    } else {
                                      Fluttertoast.showToast(msg: "Please enter laboratory type.", textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER, toastLength: Toast.LENGTH_SHORT)
                                    }
                                  } else {
                                    Fluttertoast.showToast(msg: "Please enter laboratory name.", textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER, toastLength: Toast.LENGTH_SHORT)
                                  }
                                }else{
                                  if (txtfield1Value != null && txtfield1Value.length>0){
                                    onClick(
                                      editId,
                                      txtfield1Value.toString(),
                                      position.toString(),
                                      relationController,
                                      txtfield2Value,
                                      txtfield3Value,

                                    ),
                                      Navigator.pop(context),
                                  }
                                  else {
                                    Fluttertoast.showToast(
                                        msg: "Please enter disease name.",
                                        textColor: Colors.white,
                                        backgroundColor: Colors.red,
                                        gravity: ToastGravity.CENTER,
                                        toastLength: Toast.LENGTH_SHORT)
                                  }
                                }

                              },
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            )));
  }



  /*Future<dynamic> filterSearchResults(String value) async {
    var fieldString = "";
    companyCode = companyCode;
    arrayList.toSet().forEach((element) {
      if (element.type == "Selection") {
        fieldString += "${{
          "cmbname" ':' + json.encode(element.cmbname),
          "value" ':' + json.encode(element.id),
          "type" ':' + json.encode(element.type),
          "validation" ':' + json.encode(element.validation)
        }},";
      } else {
        fieldString += "${{
          "cmbname" ':' + json.encode(element.cmbname),
          "value" ':' + json.encode(element.value),
          "type" ':' + json.encode(element.type),
          "validation" ':' + json.encode(element.validation)
        }},";
      }
    });
    var fieldData = '[ $fieldString ]';
    // tools.showProgressDialog(context);
    Map data = {
      'name_startsWith': value.toString(),
      'customer_id': customerId.toString().trim(),
      'user_id': userId.toString().trim(),
      'Co_Code': companyCode.toString().trim(),
      'Sp_Name': spName.toString().trim(),
      'urnno': urnNo.toString().trim(),
      'FieldsString': fieldData
    };
    log('CustomAlertTextDialog :=> Mobile_Api_Autoselection_Lead Api Body ==> $data');
    await Future.wait([
      http.post(
          Uri.parse(clientUrl + "MobileApp_Lead/Mobile_Api_Autoselection_Lead"),
          body: data)
    ]).then((value) {
      // tools.stopLoading();
      if (value[0].statusCode == 200) {
        jsonData = json.decode(value[0].body);
        map = Map<String, dynamic>.from(jsonData);
        log('CustomAlertTextDialog :=>  Auto Selection:: ${json.decode(value[0].body)}'); // Map map = arrayList.toList().asMap();
        if (value.isNotEmpty) {
          var filterList = [];
          map.forEach((key, value) {
            if (key == "data") {
              filterList.clear();
              for (int i1 = 0; i1 < map["data"].length; i1++) {
                mapEntry = map[key][i1];
                for (final data in mapEntry.entries) {
                  filterList
                      .add(EmployeeTypeHelper(data.value, data.key, false));
                  print(
                      'Key ${data.key}, Value: ${data.value}'); // Key: a, Value: 1 ...
                }
              }
            }
          });
          setState(() {
            searchresult.clear();
            searchresult.addAll(filterList);
          });
        } else {
          setState(() {
            searchresult.clear();
            searchresult.addAll(selectionList);
          });
        }
      } else {
        // tools.stopLoading();
        throw Exception("Create Lead exception");
      }
    }, onError: (error) {
      // tools.stopLoading();
      Fluttertoast.showToast(
          msg: error,
          textColor: Colors.white,
          backgroundColor: Colors.red,
          gravity: ToastGravity.CENTER,
          toastLength: Toast.LENGTH_SHORT);
    });
  }*/
}

class RadioItem extends StatelessWidget {
  var searchresult;

  RadioItem(this.searchresult);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[
          Container(
            width: 70,
            height: 70,
            child: Image.asset(searchresult.icon,color: searchresult.isChecked ? PrimaryColor :Colors.red,),

          ),
        ],
      ),
    );
  }
}
