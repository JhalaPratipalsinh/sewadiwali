import 'dart:convert';
import 'dart:developer';
import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:flutter_medinote/utils/EmployeeTypeHelper.dart';
import 'package:flutter_medinote/utils/GetEditTextValueHelper.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'AppColors.dart';

class CustomAlertSelectionDialog extends StatefulWidget {
  const CustomAlertSelectionDialog({

      required this.idtfDialog,
      required this.selectedId,
      required this.selectionList,
      required this.doneTitle,
      required this.cancelTitle,
      required this.position,
      required this.onClick,
      required this.onCancel,
      required this.rowClickPos,
      required this.relationController,
      Key? key})
      : super(key: key);

  final String doneTitle, cancelTitle, selectedId, position,idtfDialog;
  final int rowClickPos;
  final TextEditingController relationController;

  //final List<TextEditingController> controllersHsnCode;
  final List<EmployeeTypeHelper> selectionList;
  final Function(String,String, String, String,int,TextEditingController relationController,String) onClick;
  final Function(String) onCancel;
  @override
  State<CustomAlertSelectionDialog> createState() =>
      _CustomAlertSelectionDialogState(
          idtfDialog,
          selectedId,
          selectionList,
          doneTitle,
          cancelTitle,
          position,
          onClick,
          onCancel,
          rowClickPos,relationController);
}

class _CustomAlertSelectionDialogState
    extends State<CustomAlertSelectionDialog> {
  late String idtfDialog;
  late String cancelTitle;
  late String doneTitle;
  late String selectedId;
  late String position;
  late int rowClickPos;
  late TextEditingController relationController =TextEditingController();


  late Function(String,String, String, String,int rowClickPos,TextEditingController relationController,String) onClick;
  late Function(String) onCancel;

  var _search_controller;
  var customIcon = Container();
  late List<EmployeeTypeHelper> selectionList = [];
  List searchresult = [];

  var selectionName,extraStr;

  var clientUrl;
  var customerId;
  var userId;

  var pageIndex = "1";

  var tools;

  var jsonData;
  var map;

  @override
  void initState() {
    //setPreferenceValue();
    //tools = Tools(context);
    searchresult.addAll(selectionList);
  }

  /*setPreferenceValue() async {
    PreferenceManager preferenceManager = PreferenceManager.instance;
    setState(() {
      preferenceManager
          .getStringValue("clientUrl")
          .then((value) => setState(() {
                clientUrl = value;
              }));
      preferenceManager
          .getStringValue("customer_id")
          .then((value) => setState(() {
                customerId = value;
              }));
      preferenceManager.getStringValue("user_id").then((value) => setState(() {
            userId = value;
          }));
    });
  }*/

  _CustomAlertSelectionDialogState(
      this.idtfDialog,
      this.selectedId,
      this.selectionList,
      this.doneTitle,
      this.cancelTitle,
      this.position,
      this. onClick,
      this.onCancel,
      this.rowClickPos,
      this.relationController,
      );

  @override
  Widget build(BuildContext context) {
    return Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
        elevation: 0.0,
        backgroundColor: Colors.transparent,
        child: Container(
            margin: const EdgeInsets.only(left: 0.0, right: 0.0),
            child: Stack(
              alignment: Alignment.topCenter,
              children: <Widget>[
                Container(
                  margin: const EdgeInsets.only(top: 13.0, right: 8.0),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.rectangle,
                      borderRadius: BorderRadius.circular(30.0)),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Flexible(
                            child: Row(
                              children: [
                                Flexible(
                                  child: Container(
                                    width: MediaQuery.of(context).size.width ,
                                    height: 40,
                                    padding: const EdgeInsets.all(0),
                                    decoration: const BoxDecoration(
                                        color: PrimaryColor,
                                        borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(29),
                                          topRight: Radius.circular(29),

                                        )),
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          SizedBox(),
                                          Expanded(
                                            child: Align(
                                              alignment: Alignment.center,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 10.0),
                                                child: Text(
                                                  "Select "+idtfDialog,
                                                  style: const TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 18.0,
                                                      fontFamily: 'poppins_regular'),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Visibility(
                                            visible: false,
                                            child: Align(
                                              alignment: Alignment.centerRight,
                                              child: Padding(
                                                padding: const EdgeInsets.only(right: 10.0),
                                                child: InkWell(
                                                  onTap: (){
                                                    //onDelete(editId);
                                                  },
                                                  child: Container(
                                                    child: Icon(Icons.delete,color: Colors.white,),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),

                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      Flexible(
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          child: Container(
                            height: 40,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(30),
                              color: Colors.white,
                              boxShadow: const [
                                BoxShadow(color: Color(0XFF555555), spreadRadius: 1),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Flexible(
                                  flex: 1,
                                  child: Container(
                                    margin: const EdgeInsets.only(
                                        left: 15, top: 18),
                                    child: TextField(
                                      textAlign: TextAlign.left,
                                      controller: _search_controller,
                                      decoration: const InputDecoration(
                                        border: InputBorder.none,
                                        hintStyle:
                                            TextStyle(color: Colors.grey),
                                        hintText: "Search ",
                                        counterText: "",
                                      ),
                                      onChanged: (value) {
                                        filterSearchResults(value,selectionList);
                                      },
                                      maxLines: 1,
                                      maxLength: 50,
                                    ),
                                  ),
                                ),
                                Flexible(
                                  flex: 0,
                                  child: IconButton(
                                      onPressed: () {

                                      },
                                      icon: const Icon(
                                        Icons.search,
                                        color: Color(0xFF555555),
                                      )),
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 250,
                        child: ListView.builder(
                          shrinkWrap: true,
                          itemCount: searchresult.length,
                          itemBuilder: (BuildContext context, int index) {
                            return InkWell(
                                    //highlightColor: Colors.red,
                                    splashColor: Colors.blueAccent,
                                    onTap: () {
                                      setState(() {
                                        for (var element in searchresult) {
                                          element.isChecked = false;
                                        }
                                        searchresult[index].isChecked = true;
                                        selectedId = searchresult[index].id.toString();
                                        selectionName = searchresult[index].name.toString();
                                        extraStr = searchresult[index].extraStr.toString();
                                      });
                                    },
                                    child: RadioItem(searchresult[index]));

                          },
                        ),
                      ),
                      const SizedBox(height: 24.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Flexible(
                            child: InkWell(
                              child: Container(
                                width: MediaQuery.of(context).size.width / 2,
                                padding: const EdgeInsets.all(5),
                                decoration: const BoxDecoration(
                                    color: Color(0xFF555555),
                                    borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30))),
                                child: Text(
                                  cancelTitle,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 18.0,
                                      fontFamily: 'poppins_regular'),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              onTap: () {
                                onCancel("sAJID");
                                Navigator.pop(context);
                              },
                            ),
                          ),
                          Flexible(
                            child: InkWell(
                              child: Container(
                                width: MediaQuery.of(context).size.width / 2,
                                padding: const EdgeInsets.all(5),
                                decoration: const BoxDecoration(
                                    color: Color(0XFFE66D0A),
                                    borderRadius: BorderRadius.only(
                                      bottomRight: Radius.circular(30.0),
                                    )),
                                child: Text(
                                  doneTitle,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 18.0,
                                      fontFamily: 'poppins_regular'),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              onTap: () => {
                                if (selectionName != null){

                                    onClick(
                                        idtfDialog,
                                        selectedId.toString(),
                                        selectionName.toString(),
                                        position.toString(),
                                        rowClickPos,
                                        relationController,
                                        extraStr
                                    ),

                                    for (var element in searchresult) {
                                    element.isChecked = false
                                    },

                                    Navigator.pop(context),
                                  } else {
                                    Fluttertoast.showToast(
                                        msg: "Please select item",
                                        textColor: Colors.white, backgroundColor: Colors.red,
                                        gravity: ToastGravity.CENTER, toastLength: Toast.LENGTH_SHORT)
                                  }
                              },
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            )));
  }

  Future<dynamic> filterSearchResults(String value, List<EmployeeTypeHelper> toItemList) async {

      // tools.stopLoading();
    if (value.isNotEmpty) {
          var filterList = [];
            if (value.length>0) {
              filterList.clear();

              for (int i=0; i<toItemList.length; i++) {
                if (toItemList[i].name!.toLowerCase().contains(value.toLowerCase())) {
                  filterList.add(EmployeeTypeHelper(toItemList[i].name,toItemList[i].id,"", false,toItemList[i].extraStr));
                }
              }
            }
          setState(() {
            searchresult.clear();
            searchresult.addAll(filterList);
          });
        } else {
          setState(() {
            searchresult.clear();
            searchresult.addAll(selectionList);
          });
        }

  }
}

class RadioItem extends StatelessWidget {
  var searchresult;

  RadioItem(this.searchresult);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(15.0),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[
          Flexible(
            child: Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.black, width: 2),
                  borderRadius: BorderRadius.circular(60)),
              child: Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                    color: searchresult.isChecked ? const Color(0XFFE66D0A) : Colors.white,
                    borderRadius: BorderRadius.circular(60)),
              ),
            ),
          ),
          Flexible(
            child: Container(
              margin: const EdgeInsets.only(left: 10.0),
              child: Text(
                searchresult.name,
                style: const TextStyle(
                    color: Color(0xFF555555),
                    fontSize: 14.0,
                    fontFamily: 'poppins_regular'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
