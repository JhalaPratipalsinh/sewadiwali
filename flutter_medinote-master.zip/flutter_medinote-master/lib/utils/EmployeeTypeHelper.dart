import 'package:flutter/material.dart';

class EmployeeTypeHelper{
   String? name;
   String? id;
   bool? isChecked;
   String icon;
   String extraStr;

   EmployeeTypeHelper(this.name, this.id, this.icon,this.isChecked,this.extraStr);
}