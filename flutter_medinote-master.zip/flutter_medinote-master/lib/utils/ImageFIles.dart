class ImageFiles{
   String? name;
   String? path;
   String? type;

   ImageFiles(this.name, this.path, this.type);
}