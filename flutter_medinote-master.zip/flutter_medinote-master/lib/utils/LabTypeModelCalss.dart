
import 'package:flutter/material.dart';

class LabTypeModelCalss{

  //common
  String? strlabType;
  String? strLable;
  String? strReportId;
  String? strpatient;
  String? strpatientId;
  String? strdate;
  String? strlaboratory;
  String? strlaboratoryId;

  //for diabetes
  String? strbloodGlucoseResult;
  String? strpostPrandialBloodGluAfter;
  String? strUrineAcetoneResult;

  //for blood pressure
  String? strTestAt;
  String? strSystolic;
  String? strDiastolic;

  LabTypeModelCalss(
      this.strlabType,
      this.strLable,
      this.strReportId,
      this.strpatient,
      this.strpatientId,
      this.strdate,
      this.strlaboratory,
      this.strlaboratoryId,
      this.strbloodGlucoseResult,
      this.strpostPrandialBloodGluAfter,
      this.strUrineAcetoneResult,
      this.strTestAt,
      this.strSystolic,
      this.strDiastolic);

}