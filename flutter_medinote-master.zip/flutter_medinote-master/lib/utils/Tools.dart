

import 'package:flutter/material.dart';

class Tools{
  BuildContext context;

  Tools(this.context);

  void ShowDialog(BuildContext context) {
    AlertDialog alert = AlertDialog(
      content: Row(children: [
        const CircularProgressIndicator(
          backgroundColor: Colors.red,
        ),
        Container(
            margin: const EdgeInsets.only(left: 10),
            child: const Text("Loading...")),
      ]),
    );

    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  void showProgressDialog(BuildContext context) {
    AlertDialog alert = AlertDialog(
        backgroundColor: Colors.transparent,
        content: Row(mainAxisSize: MainAxisSize.min, children: [
          Center(
              child: Container(
                margin: const EdgeInsets.all(50),
                /*child: Lottie.asset(
                  'images/loading.json',
                  width: 100,
                  height: 100,
                  fit: BoxFit.fill,
                ),*/
              ))
        ]));

    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  void stopLoading() {
    Navigator.of(context).pop();
  }
}