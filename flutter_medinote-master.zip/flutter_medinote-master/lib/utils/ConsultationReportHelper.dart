import 'package:flutter/material.dart';

class ConsultationReportHelper{
   String medicineName;
   String atMorning;
   String atAfternoon;
   String atEvening;
   String beforOrAfter;
   String medicineWith;
   String medicineSchedule;
   String medicineType;
   String drugName;
   String medicinePrice;
   String manufacturer;

   ConsultationReportHelper(
      this.medicineName,
      this.atMorning,
      this.atAfternoon,
      this.atEvening,
      this.beforOrAfter,
      this.medicineWith,
      this.medicineSchedule,
      this.medicineType,
      this.drugName,
      this.medicinePrice,
      this.manufacturer);
}