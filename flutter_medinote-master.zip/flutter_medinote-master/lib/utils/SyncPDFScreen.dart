
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:share_extend/share_extend.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

class SyncPDFScreen extends StatefulWidget {
  final String? path;

  SyncPDFScreen(this.path, {Key? key}) : super(key: key);

  @override
  _SyncPDFScreenState createState() => _SyncPDFScreenState();
}

class _SyncPDFScreenState extends State<SyncPDFScreen> {

  int? pages = 0;
  int? currentPage = 0;
  bool isReady = false;
  String errorMessage = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: const Text("Document",style: TextStyle(fontFamily: "poppins_regular",fontWeight: FontWeight.w400,fontSize: 18.0),),
          actions: <Widget>[
            IconButton(
              icon: const Icon(
                Icons.share,
                color: Colors.white,
              ),
              onPressed: () {
                _shareStorageFile();
              },
            ),
          ],
        ),
        body: SfPdfViewer.file(File(widget.path.toString()))
    );
  }


  _shareStorageFile() async {

    File testFile = File(widget.path.toString());
    if (!await testFile.exists()) {
      await testFile.create(recursive: true);
      testFile.writeAsStringSync("DataNote file sharing");
    }
    ShareExtend.share(testFile.path, "file");
  }
}