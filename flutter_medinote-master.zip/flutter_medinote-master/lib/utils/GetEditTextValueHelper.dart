
class GetEditTextValueHelper {
   String? id;
   String? cmbname;
   String? value;
   String? type;
   String? validation;
   String? fieldIdName;
   String? companyCode;
   String? spName;
   String? datetimeyesno;



   GetEditTextValueHelper({this.id,this.cmbname, this.value, this.type, this.validation,this.fieldIdName,this.companyCode,this.spName,this.datetimeyesno});

   factory GetEditTextValueHelper.fromJson(Map<String, dynamic> json) => _$GetEditTextValueHelperFromJson(json);
   Map<String, dynamic> toJson() => _$GetEditTextValueHelperToJson(this);




}
_$GetEditTextValueHelperFromJson(Map<String, dynamic> json) {}
_$GetEditTextValueHelperToJson(GetEditTextValueHelper getEditTextValueHelper) {}
