
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'AppColors.dart';

class CustomAddRatingDialog extends StatefulWidget {

  final String doneTitle, cancelTitle, position,editId,editName,editTxtField2,editTxtField3,dialogTitle,txtFiel1;
  final bool txtFiel2IsVisible,txtFiel3IsVisible;


  final TextEditingController relationController;



  final Function(String,String, String,TextEditingController relationController,String,String) onClick;
  final Function(String) onCancel;
  final Function(String) onDelete;

  const CustomAddRatingDialog({
    required this.dialogTitle,
    required this.doneTitle,
    required this.cancelTitle,
    required this.position,
    required this.onClick,
    required this.onCancel,
    required this.onDelete,
    required this.relationController,
    required this.editId,
    required this.editName,
    required this.editTxtField2,
    required this.editTxtField3,
    required this.txtFiel1,
    required this.txtFiel2IsVisible,
    required this.txtFiel3IsVisible,Key? key}) : super(key: key);

  @override
  State<CustomAddRatingDialog> createState() => _CustomAddRatingDialogState(
    dialogTitle,
    doneTitle,
    cancelTitle,
    position,
    onClick,
    onCancel,
    onDelete,
    relationController,
    editId,
    editName,
    editTxtField2,
    editTxtField3,
    txtFiel1,
    txtFiel2IsVisible,
    txtFiel3IsVisible,);

}

class _CustomAddRatingDialogState extends State<CustomAddRatingDialog> {

  late String cancelTitle,editId,editName,editTxtField2,editTxtField3,dialogTitle,txtFiel1;
  final bool txtFiel2IsVisible,txtFiel3IsVisible;
  late String doneTitle;
  late String position;
  late TextEditingController relationController =TextEditingController();
  TextEditingController reviewController = TextEditingController();
  TextEditingController txtfield2Controller = TextEditingController();
  TextEditingController txtfield3Controller = TextEditingController();



  late Function(String,String, String,TextEditingController relationController,String,String) onClick;
  late Function(String) onCancel;
  late Function(String) onDelete;

  var _search_controller;
  var customIcon = Container();


  var selectionName,strRating='OKAY',strRatingText='';


  var txtfield1Value="",txtfield2Value="",txtfield3Value="";

  var clientUrl;
  var customerId;
  var userId;

  var pageIndex = "1";

  var tools;

  var jsonData;
  var mapEntry;
  var map;

  _CustomAddRatingDialogState(

      this.dialogTitle,
      this.doneTitle,
      this.cancelTitle,
      this.position,
      this. onClick,
      this.onCancel,
      this.onDelete,
      this.relationController,
      this.editId,
      this.editName,
      this.editTxtField2,
      this.editTxtField3,
      this.txtFiel1,
      this.txtFiel2IsVisible,
      this.txtFiel3IsVisible,
      );

  @override
  void initState() {
    //setPreferenceValue();
    //tools = Tools(context);
    //searchresult.addAll(selectionList);
    SetData();
  }


  Future SetData() async{

    if(editName.toString()!=null && editName.toString().length>0){
      setState((){
        txtfield1Value = editName.toString();
        reviewController.text = editName.toString();
      });
    }
    if(editTxtField2.toString()!=null && editTxtField2.toString().length>0){
      setState((){
        txtfield2Value = editTxtField2.toString();
        txtfield2Controller.text = editTxtField2.toString();
      });
    }
    if(editTxtField3.toString()!=null && editTxtField3.toString().length>0){
      setState((){
        txtfield3Value = editTxtField3.toString();
        txtfield3Controller.text = editTxtField3.toString();
      });
    }


  }

  @override
  Widget build(BuildContext context) {

    SetData();
    return Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
        elevation: 0.0,
        backgroundColor: Colors.transparent,
        child: Container(
            margin: const EdgeInsets.only(left: 0.0, right: 0.0),
            child: Stack(
              alignment: Alignment.topCenter,
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.only(top: 0.0,),
                  decoration: BoxDecoration(color: Colors.white, shape: BoxShape.rectangle, borderRadius: BorderRadius.circular(30.0)),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      /*Flexible(
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          child: Container(
                            height: 40,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(30),
                              color: Colors.white,
                              boxShadow: const [
                                BoxShadow(color: Color(0XFF555555), spreadRadius: 1),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Flexible(
                                  child: Container(
                                    margin: const EdgeInsets.only(
                                        left: 15, top: 18),
                                    child: TextField(
                                      textAlign: TextAlign.left,
                                      controller: _search_controller,
                                      decoration: const InputDecoration(
                                        border: InputBorder.none,
                                        hintStyle:
                                            TextStyle(color: Colors.grey),
                                        hintText: "Search ",
                                        counterText: "",
                                      ),
                                      onChanged: (value) {
                                        //filterSearchResults(value);
                                      },
                                      maxLines: 1,
                                      maxLength: 50,
                                    ),
                                  ),
                                  flex: 1,
                                ),
                                Flexible(
                                  child: IconButton(
                                      onPressed: () {},
                                      icon: const Icon(
                                        Icons.search,
                                        color: Color(0xFF555555),
                                      )),
                                  flex: 0,
                                )
                              ],
                            ),
                          ),
                        ),
                      ),*/
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Flexible(
                            child: Row(
                              children: [
                                Flexible(
                                  child: Container(
                                    width: MediaQuery.of(context).size.width ,
                                    height: 40,
                                    padding: const EdgeInsets.all(0),
                                    decoration: const BoxDecoration(
                                        color: PrimaryColor,
                                        borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(29),
                                          topRight: Radius.circular(29),

                                        )),
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          SizedBox(),
                                          Expanded(
                                            child: Align(
                                              alignment: Alignment.center,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 10.0),
                                                child: Text(dialogTitle, style: const TextStyle(color: Colors.white, fontSize: 18.0, fontFamily: 'poppins_regular'),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Visibility(
                                            visible: false,
                                            child: Align(
                                              alignment: Alignment.centerRight,
                                              child: Padding(
                                                padding: const EdgeInsets.only(right: 10.0),
                                                child: InkWell(
                                                  onTap: (){
                                                    onDelete(editId);
                                                  },
                                                  child: Container(
                                                    child: Icon(Icons.delete,color: Colors.white,),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),

                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 310,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 20.0,left: 8,right: 8),
                          child: Column(
                            children: [
                              Container(
                                child: setRating(context),

                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Text(strRatingText),
                              SizedBox(
                                height: 10,
                              ),
                              RatingBar.builder(
                                itemSize: 50,
                                minRating: 1,
                                itemCount: 5,
                                itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                                itemBuilder: (context, index) => Icon(Icons.star, color: Colors.amber,),
                                onRatingUpdate: (rating) {
                                  print(rating);
                                  if(rating==1.0){
                                    setState((){
                                      strRating = 'AWFUL';
                                      strRatingText = 'AWFUL';
                                    });
                                  }else if(rating==2.0){
                                    setState((){
                                      strRating = 'BAD';
                                      strRatingText = 'BAD';
                                    });
                                  }else if(rating==3.0){
                                    setState((){
                                      strRating = 'OKAY';
                                      strRatingText = 'OKAY';
                                    });
                                  }else if(rating==4.0){
                                    setState((){
                                      strRating = 'GOOD';
                                      strRatingText = 'GOOD';
                                    });
                                  }else if(rating==5.0){
                                    setState((){
                                      strRating = 'GREAT';
                                      strRatingText = 'GREAT';
                                    });
                                  }else{
                                    setState((){
                                      strRating='';
                                      strRatingText='';
                                    });
                                  }
                                },),
                              SizedBox(
                                height: 20,
                              ),
                              //textfield1
                              TextFormField(
                                controller: reviewController,
                                maxLines: 2,
                                decoration: InputDecoration(
                                  labelText: txtFiel1,
                                  labelStyle: TextStyle(color: PrimaryColor),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: grey_60,width: 1),
                                      borderRadius: BorderRadius.circular(10)
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: grey_20),
                                      borderRadius: BorderRadius.circular(10)
                                  ),
                                ),
                                onChanged: (value){
                                  txtfield1Value = value.toString();
                                  print(txtfield1Value);
                                },
                              ),
                           
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 24.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Flexible(
                            child: InkWell(
                              child: Container(
                                width: MediaQuery.of(context).size.width / 2,
                                padding: const EdgeInsets.all(5),
                                decoration: const BoxDecoration(
                                    color: Color(0xFF555555),
                                    borderRadius: BorderRadius.only(
                                        bottomLeft: Radius.circular(30))),
                                child: Text(
                                  cancelTitle,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 18.0,
                                      fontFamily: 'poppins_regular'),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              onTap: () {
                                onCancel("sAJID");
                                Navigator.pop(context);
                              },
                            ),
                          ),
                          Flexible(
                            child: InkWell(
                              child: Container(
                                width: MediaQuery.of(context).size.width / 2,
                                padding: const EdgeInsets.all(5),
                                decoration: const BoxDecoration(
                                    color: Color(0XFFE66D0A),
                                    borderRadius: BorderRadius.only(
                                      bottomRight: Radius.circular(30.0),
                                    )),
                                child: Text(
                                  doneTitle,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 18.0,
                                      fontFamily: 'poppins_regular'),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              onTap: () => {
                                if(strRatingText!=''){
                                  if (txtfield1Value != null && txtfield1Value.length>0){
                                    onClick(
                                      editId,
                                      txtfield1Value.toString(),
                                      position.toString(),
                                      relationController,
                                      strRatingText,
                                      txtfield3Value,
                                    ),

                                  } else {
                                    Fluttertoast.showToast(msg: "Please enter review.", textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER, toastLength: Toast.LENGTH_SHORT)
                                  }
                                }else{
                                  Fluttertoast.showToast(msg: "Please select atleast one star.", textColor: Colors.white, backgroundColor: Colors.red, gravity: ToastGravity.CENTER, toastLength: Toast.LENGTH_SHORT)
                                }
                              },
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            )));
  }
  Widget setRating(BuildContext context) {
    if(strRating=='AWFUL') {
      return Image.asset('images/awful.png', width: 100, height: 100,);
    }else if(strRating == "BAD") {
      return Image.asset('images/bad.png', width: 100, height: 100,);
    }else if(strRating == "OKAY") {
      return Image.asset('images/ok.png', width: 100, height: 100,);
    }else if(strRating == "GOOD") {
      return Image.asset('images/good.png', width: 100, height: 100,);
    } else {
      return Image.asset('images/great.png', width: 100, height: 100,);
    }

  }

  _InitialValue(String rating) {
    if (rating == "AWFUL") {
      return 1.0;
    } else if(rating == "BAD") {
      return 2.0;
    }else if(rating == "OKAY") {
      return 3.0;
    }else if(rating == "GOOD") {
      return 4.0;
    } else {
      return 5.0;
    }
  }


}
class RadioItem extends StatelessWidget {
  var searchresult;

  RadioItem(this.searchresult);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[
          Container(
            width: 70,
            height: 70,
            child: Image.asset(searchresult.icon,color: searchresult.isChecked ? PrimaryColor :Colors.red,),

          ),
        ],
      ),
    );
  }


}
