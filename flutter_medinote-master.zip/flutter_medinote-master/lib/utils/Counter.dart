
import 'package:flutter/material.dart';

class Counter extends ChangeNotifier {
  var _count = false;
   get getCounter {
    return _count;
  }

  void incrementCounter() {
    _count  = true;
    notifyListeners();
  }
  void decrimentCounter() {
    _count  = false;
    notifyListeners();
  }
}