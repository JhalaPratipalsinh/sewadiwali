import 'dart:convert';
import 'dart:developer';
import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:flutter_medinote/utils/AppColors.dart';
import 'package:flutter_medinote/utils/EmployeeTypeHelper.dart';
import 'package:flutter_medinote/utils/GetEditTextValueHelper.dart';
import 'package:fluttertoast/fluttertoast.dart';

class CustomAlertSelectionImageDialog extends StatefulWidget {
  const CustomAlertSelectionImageDialog({

      required this.selectedId,
      required this.selectionList,
      required this.doneTitle,
      required this.cancelTitle,
      required this.position,
      required this.arrayList,
      required this.onClick,
      required this.onCancel,
      required this.rowClickPos,
      required this.relationController,
      Key? key})
      : super(key: key);

  final String doneTitle, cancelTitle, selectedId, position;
  final int rowClickPos;
  final TextEditingController relationController;

  //final List<TextEditingController> controllersHsnCode;
  final List<GetEditTextValueHelper> arrayList;
  final List<EmployeeTypeHelper> selectionList;
  final Function(String, String, String, List<GetEditTextValueHelper>,int,TextEditingController relationController) onClick;
  final Function(String) onCancel;
  @override
  State<CustomAlertSelectionImageDialog> createState() =>
      _CustomAlertSelectionImageDialogState(
          selectedId,
          selectionList,
          doneTitle,
          cancelTitle,
          position,
          arrayList,
          onClick,
          onCancel,
          rowClickPos,relationController);
}

class _CustomAlertSelectionImageDialogState
    extends State<CustomAlertSelectionImageDialog> {
  late String cancelTitle;
  late String doneTitle;
  late String selectedId;
  late String position;
  late int rowClickPos;
  late TextEditingController relationController =TextEditingController();

  late List<GetEditTextValueHelper> arrayList;

  late Function(String, String, String, List<GetEditTextValueHelper>,int rowClickPos,TextEditingController relationController) onClick;
  late Function(String) onCancel;

  var _search_controller;
  var customIcon = Container();
  late List<EmployeeTypeHelper> selectionList = [];
  List searchresult = [];

  var selectionName;

  var clientUrl;
  var customerId;
  var userId;

  var pageIndex = "1";

  var tools;

  var jsonData;
  var mapEntry;
  var map;

  @override
  void initState() {
    //setPreferenceValue();
    //tools = Tools(context);
    searchresult.addAll(selectionList);
  }

  /*setPreferenceValue() async {
    PreferenceManager preferenceManager = PreferenceManager.instance;
    setState(() {
      preferenceManager
          .getStringValue("clientUrl")
          .then((value) => setState(() {
                clientUrl = value;
              }));
      preferenceManager
          .getStringValue("customer_id")
          .then((value) => setState(() {
                customerId = value;
              }));
      preferenceManager.getStringValue("user_id").then((value) => setState(() {
            userId = value;
          }));
    });
  }*/

  _CustomAlertSelectionImageDialogState(
      this.selectedId,
      this.selectionList,
      this.doneTitle,
      this.cancelTitle,
      this.position,
      this.arrayList,
      this. onClick,
      this.onCancel,
      this.rowClickPos,
      this.relationController,
      );

  @override
  Widget build(BuildContext context) {
    return Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
        elevation: 0.0,
        backgroundColor: Colors.transparent,
        child: Container(
            margin: const EdgeInsets.only(left: 0.0, right: 0.0),
            child: Stack(
              alignment: Alignment.topCenter,
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.only(
                    top: 20.0,
                  ),
                  margin: const EdgeInsets.only(top: 13.0, right: 8.0),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.rectangle,
                      borderRadius: BorderRadius.circular(30.0)),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      /*Flexible(
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          child: Container(
                            height: 40,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(30),
                              color: Colors.white,
                              boxShadow: const [
                                BoxShadow(color: Color(0XFF555555), spreadRadius: 1),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Flexible(
                                  child: Container(
                                    margin: const EdgeInsets.only(
                                        left: 15, top: 18),
                                    child: TextField(
                                      textAlign: TextAlign.left,
                                      controller: _search_controller,
                                      decoration: const InputDecoration(
                                        border: InputBorder.none,
                                        hintStyle:
                                            TextStyle(color: Colors.grey),
                                        hintText: "Search ",
                                        counterText: "",
                                      ),
                                      onChanged: (value) {
                                        //filterSearchResults(value);
                                      },
                                      maxLines: 1,
                                      maxLength: 50,
                                    ),
                                  ),
                                  flex: 1,
                                ),
                                Flexible(
                                  child: IconButton(
                                      onPressed: () {},
                                      icon: const Icon(
                                        Icons.search,
                                        color: Color(0xFF555555),
                                      )),
                                  flex: 0,
                                )
                              ],
                            ),
                          ),
                        ),
                      ),*/
                      SizedBox(
                        height: 250,
                        child: GridView.builder(
                          shrinkWrap: true,
                          itemCount: searchresult.length,
                          itemBuilder: (BuildContext context, int index) {
                            return InkWell(
                                    //highlightColor: Colors.red,
                                    splashColor: Colors.blueAccent,
                                    onTap: () {
                                      setState(() {
                                        for (var element in searchresult) {
                                          element.isChecked = false;
                                        }
                                        searchresult[index].isChecked = true;
                                        selectedId = searchresult[index].id.toString();
                                        selectionName = searchresult[index].name.toString();
                                      });
                                    },
                                    child: RadioItem(searchresult[index]));

                          }, gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
                        ),
                      ),
                      const SizedBox(height: 24.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Flexible(
                            child: InkWell(
                              child: Container(
                                width: MediaQuery.of(context).size.width / 2,
                                padding: const EdgeInsets.all(5),
                                decoration: const BoxDecoration(
                                    color: Color(0xFF555555),
                                    borderRadius: BorderRadius.only(
                                        bottomLeft: Radius.circular(30))),
                                child: Text(
                                  cancelTitle,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 18.0,
                                      fontFamily: 'poppins_regular'),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              onTap: () {
                                onCancel("sAJID");
                                Navigator.pop(context);
                              },
                            ),
                          ),
                          Flexible(
                            child: InkWell(
                              child: Container(
                                width: MediaQuery.of(context).size.width / 2,
                                padding: const EdgeInsets.all(5),
                                decoration: const BoxDecoration(
                                    color: Color(0XFFE66D0A),
                                    borderRadius: BorderRadius.only(
                                      bottomRight: Radius.circular(30.0),
                                    )),
                                child: Text(
                                  doneTitle,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 18.0,
                                      fontFamily: 'poppins_regular'),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              onTap: () => {
                                if (selectionName != null){

                                    onClick(
                                        selectedId.toString(),
                                        selectionName.toString(),
                                        position.toString(),
                                        arrayList,
                                        rowClickPos,
                                        relationController
                                    ),

                                    for (var element in searchresult) {
                                    element.isChecked = false
                                    },
                                    Navigator.pop(context),
                                  }
                                else
                                  {
                                    Fluttertoast.showToast(
                                        msg: "Please select item",
                                        textColor: Colors.white,
                                        backgroundColor: Colors.red,
                                        gravity: ToastGravity.CENTER,
                                        toastLength: Toast.LENGTH_SHORT)
                                  }
                              },
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            )));
  }

  /*Future<dynamic> filterSearchResults(String value) async {
    var fieldString = "";
    companyCode = companyCode;
    arrayList.toSet().forEach((element) {
      if (element.type == "Selection") {
        fieldString += "${{
          "cmbname" ':' + json.encode(element.cmbname),
          "value" ':' + json.encode(element.id),
          "type" ':' + json.encode(element.type),
          "validation" ':' + json.encode(element.validation)
        }},";
      } else {
        fieldString += "${{
          "cmbname" ':' + json.encode(element.cmbname),
          "value" ':' + json.encode(element.value),
          "type" ':' + json.encode(element.type),
          "validation" ':' + json.encode(element.validation)
        }},";
      }
    });
    var fieldData = '[ $fieldString ]';
    // tools.showProgressDialog(context);
    Map data = {
      'name_startsWith': value.toString(),
      'customer_id': customerId.toString().trim(),
      'user_id': userId.toString().trim(),
      'Co_Code': companyCode.toString().trim(),
      'Sp_Name': spName.toString().trim(),
      'urnno': urnNo.toString().trim(),
      'FieldsString': fieldData
    };
    log('CustomAlertSelectionImageDialog :=> Mobile_Api_Autoselection_Lead Api Body ==> $data');
    await Future.wait([
      http.post(
          Uri.parse(clientUrl + "MobileApp_Lead/Mobile_Api_Autoselection_Lead"),
          body: data)
    ]).then((value) {
      // tools.stopLoading();
      if (value[0].statusCode == 200) {
        jsonData = json.decode(value[0].body);
        map = Map<String, dynamic>.from(jsonData);
        log('CustomAlertSelectionImageDialog :=>  Auto Selection:: ${json.decode(value[0].body)}'); // Map map = arrayList.toList().asMap();
        if (value.isNotEmpty) {
          var filterList = [];
          map.forEach((key, value) {
            if (key == "data") {
              filterList.clear();
              for (int i1 = 0; i1 < map["data"].length; i1++) {
                mapEntry = map[key][i1];
                for (final data in mapEntry.entries) {
                  filterList
                      .add(EmployeeTypeHelper(data.value, data.key, false));
                  print(
                      'Key ${data.key}, Value: ${data.value}'); // Key: a, Value: 1 ...
                }
              }
            }
          });
          setState(() {
            searchresult.clear();
            searchresult.addAll(filterList);
          });
        } else {
          setState(() {
            searchresult.clear();
            searchresult.addAll(selectionList);
          });
        }
      } else {
        // tools.stopLoading();
        throw Exception("Create Lead exception");
      }
    }, onError: (error) {
      // tools.stopLoading();
      Fluttertoast.showToast(
          msg: error,
          textColor: Colors.white,
          backgroundColor: Colors.red,
          gravity: ToastGravity.CENTER,
          toastLength: Toast.LENGTH_SHORT);
    });
  }*/
}

class RadioItem extends StatelessWidget {
  var searchresult;

  RadioItem(this.searchresult);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[
          Container(
            width: 70,
            height: 70,
            child: Image.asset(searchresult.icon,color: searchresult.isChecked ? PrimaryColor :Colors.red,),

          ),
        ],
      ),
    );
  }
}
