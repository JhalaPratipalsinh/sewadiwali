import 'dart:convert';
import 'dart:developer';
import 'dart:ffi';

import 'package:custom_radio_grouped_button/custom_radio_grouped_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_medinote/utils/AppColors.dart';
import 'package:flutter_medinote/utils/EmployeeTypeHelper.dart';
import 'package:flutter_medinote/utils/GetEditTextValueHelper.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:numberpicker/numberpicker.dart';

class CustomAlertDialog extends StatefulWidget {
  const CustomAlertDialog({

      required this.selectedId,
      required this.selectionList,
      required this.doneTitle,
      required this.cancelTitle,
      required this.position,
      required this.arrayList,
      required this.onClick,
      required this.onCancel,
      required this.rowClickPos,
      required this.relationController,
      required this.strName,
      Key? key})
      : super(key: key);

  final String doneTitle, cancelTitle, selectedId, position,strName;
  final int rowClickPos;
  final TextEditingController relationController;

  //final List<TextEditingController> controllersHsnCode;
  final List<GetEditTextValueHelper> arrayList;
  final List<EmployeeTypeHelper> selectionList;
  final Function(String, String, String, List<GetEditTextValueHelper>,int,TextEditingController relationController,String,String,String,String) onClick;
  final Function(String) onCancel;
  @override
  State<CustomAlertDialog> createState() =>
      _CustomAlertDialogState(
          selectedId,
          selectionList,
          doneTitle,
          cancelTitle,
          position,
          arrayList,
          onClick,
          onCancel,
          rowClickPos,
          relationController,
          strName);
}

class _CustomAlertDialogState extends State<CustomAlertDialog> {
  List<Gender> genders = <Gender>[];
  int _currentValue = 0;
  int _currentValuePoint = 0;
  String positiveMinValue="";
  late String cancelTitle;
  late String doneTitle;
  late String selectedId,strName;
  late String position;
  late int rowClickPos;
  late TextEditingController relationController =TextEditingController();

  late List<GetEditTextValueHelper> arrayList;

  late Function(String, String, String, List<GetEditTextValueHelper>,int rowClickPos,TextEditingController relationController,String,String,String,String) onClick;
  late Function(String) onCancel;

  var _search_controller;
  var customIcon = Container();
  late List<EmployeeTypeHelper> selectionList = [];
  List searchresult = [];

  var selectionName;

  var clientUrl;
  var customerId;
  var userId;

  var pageIndex = "1";

  var tools;

  var jsonData;
  var mapEntry;
  var map;

  @override
  void initState() {
    //setPreferenceValue();
    //tools = Tools(context);
    searchresult.addAll(selectionList);
    genders.add(new Gender("+", Icons.add, false));
    genders.add(new Gender("-", Icons.remove, false));
  }

  /*setPreferenceValue() async {
    PreferenceManager preferenceManager = PreferenceManager.instance;
    setState(() {
      preferenceManager
          .getStringValue("clientUrl")
          .then((value) => setState(() {
                clientUrl = value;
              }));
      preferenceManager
          .getStringValue("customer_id")
          .then((value) => setState(() {
                customerId = value;
              }));
      preferenceManager.getStringValue("user_id").then((value) => setState(() {
            userId = value;
          }));
    });
  }*/

  _CustomAlertDialogState(
      this.selectedId,
      this.selectionList,
      this.doneTitle,
      this.cancelTitle,
      this.position,
      this.arrayList,
      this. onClick,
      this.onCancel,
      this.rowClickPos,
      this.relationController,
      this.strName
      );

  @override
  Widget build(BuildContext context) {
    return Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
        elevation: 0.0,
        backgroundColor: Colors.transparent,
        child: Container(
            margin: const EdgeInsets.only(left: 0.0, right: 0.0),
            child: Stack(
              alignment: Alignment.topCenter,
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.only(top: 0,),
                  margin: const EdgeInsets.only(top: 13.0, right: 8.0),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.rectangle,
                      borderRadius: BorderRadius.circular(30.0)),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      //title
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Flexible(
                            child: InkWell(
                              child: Container(
                                width: MediaQuery.of(context).size.width,
                                padding: const EdgeInsets.all(5),
                                decoration: const BoxDecoration(
                                    color: PrimaryColor,
                                    borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(30),
                                    topRight: Radius.circular(30))),
                                child: Padding(
                                  padding: const EdgeInsets.all(5.0),
                                  child: Text(
                                    "Eye Number",
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 18.0,
                                        fontFamily: 'poppins_regular'),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ),

                            ),
                          ),
                        ],
                      ),

                      /*Flexible(
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          child: Container(
                            height: 40,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(30),
                              color: Colors.white,
                              boxShadow: const [
                                BoxShadow(color: Color(0XFF555555), spreadRadius: 1),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Flexible(
                                  child: Container(
                                    margin: const EdgeInsets.only(
                                        left: 15, top: 18),
                                    child: TextField(
                                      textAlign: TextAlign.left,
                                      controller: _search_controller,
                                      decoration: const InputDecoration(
                                        border: InputBorder.none,
                                        hintStyle:
                                            TextStyle(color: Colors.grey),
                                        hintText: "Search ",
                                        counterText: "",
                                      ),
                                      onChanged: (value) {
                                        //filterSearchResults(value);
                                      },
                                      maxLines: 1,
                                      maxLength: 50,
                                    ),
                                  ),
                                  flex: 1,
                                ),
                                Flexible(
                                  child: IconButton(
                                      onPressed: () {},
                                      icon: const Icon(
                                        Icons.search,
                                        color: Color(0xFF555555),
                                      )),
                                  flex: 0,
                                )
                              ],
                            ),
                          ),
                        ),
                      ),*/
                      SizedBox(
                        height: 220,
                        child: Container(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(left: 20.0),
                                    child: Container(
                                      width: 80,
                                      height: 80,
                                      child: ListView.builder(
                                          scrollDirection: Axis.vertical,
                                          itemCount: genders.length,
                                          itemBuilder: (context, index) {
                                            return InkWell(
                                              splashColor: Colors.pinkAccent,
                                              onTap: () {
                                                setState(() {
                                                  genders.forEach((gender) => gender.isSelected = false);
                                                  genders[index].isSelected = true;
                                                  if(genders[index].name=="+"){
                                                    positiveMinValue = "+";
                                                  }else{
                                                    positiveMinValue = "-";
                                                  }
                                                });
                                              },
                                              child:  CustomRadio(genders[index]),
                                            );
                                          }),
                                    ),
                                  ),
                                  Expanded(
                                    child: NumberPicker(
                                      value: _currentValue,
                                      minValue: 0,
                                      maxValue: 100,
                                      onChanged: (value) => setState(() => _currentValue = value),
                                    ),
                                  ),
                                  Expanded(
                                    child: NumberPicker(
                                      value: _currentValuePoint,
                                      minValue: 0,
                                      maxValue: 100,
                                      onChanged: (value) => setState(() => _currentValuePoint = value),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              Text('$positiveMinValue $_currentValue .$_currentValuePoint',style: TextStyle(fontSize: 20),),
                            ],
                          )
                        ),
                      ),
                      const SizedBox(height: 24.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Flexible(
                            child: InkWell(
                              child: Container(
                                width: MediaQuery.of(context).size.width / 2,
                                padding: const EdgeInsets.all(5),
                                decoration: const BoxDecoration(
                                    color: Color(0xFF555555),
                                    borderRadius: BorderRadius.only(
                                        bottomLeft: Radius.circular(30))),
                                child: Text(
                                  cancelTitle,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 18.0,
                                      fontFamily: 'poppins_regular'),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              onTap: () {
                                onCancel("sAJID");
                                Navigator.pop(context);
                              },
                            ),
                          ),
                          Flexible(
                            child: InkWell(
                              child: Container(
                                width: MediaQuery.of(context).size.width / 2,
                                padding: const EdgeInsets.all(5),
                                decoration: const BoxDecoration(
                                    color: Color(0XFFE66D0A),
                                    borderRadius: BorderRadius.only(
                                      bottomRight: Radius.circular(30.0),
                                    )),
                                child: Text(
                                  doneTitle,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 18.0,
                                      fontFamily: 'poppins_regular'),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              onTap: () => {
                                if (_currentValue != 0 || _currentValuePoint !=0){

                                  if(positiveMinValue!=""){
                                    onClick(
                                      selectedId.toString(),
                                      selectionName.toString(),
                                      position.toString(),
                                      arrayList,
                                      rowClickPos,
                                      relationController,
                                      positiveMinValue,
                                      _currentValue.toString(),
                                      _currentValuePoint.toString(),
                                      strName
                                    ),

                                    for (var element in searchresult) {
                                      element.isChecked = false
                                    },
                                    Navigator.pop(context),
                                  }else{
                                    Fluttertoast.showToast(
                                        msg: "Please select number is positive or negative",
                                        textColor: Colors.white,
                                        backgroundColor: Colors.red,
                                        gravity: ToastGravity.CENTER,
                                        toastLength: Toast.LENGTH_SHORT)
                                  }
                                } else
                                {
                                  Fluttertoast.showToast(
                                      msg: "Please eye number",
                                      textColor: Colors.white,
                                      backgroundColor: Colors.red,
                                      gravity: ToastGravity.CENTER,
                                      toastLength: Toast.LENGTH_SHORT)
                                }
                              },
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            )));
  }

  /*Future<dynamic> filterSearchResults(String value) async {
    var fieldString = "";
    companyCode = companyCode;
    arrayList.toSet().forEach((element) {
      if (element.type == "Selection") {
        fieldString += "${{
          "cmbname" ':' + json.encode(element.cmbname),
          "value" ':' + json.encode(element.id),
          "type" ':' + json.encode(element.type),
          "validation" ':' + json.encode(element.validation)
        }},";
      } else {
        fieldString += "${{
          "cmbname" ':' + json.encode(element.cmbname),
          "value" ':' + json.encode(element.value),
          "type" ':' + json.encode(element.type),
          "validation" ':' + json.encode(element.validation)
        }},";
      }
    });
    var fieldData = '[ $fieldString ]';
    // tools.showProgressDialog(context);
    Map data = {
      'name_startsWith': value.toString(),
      'customer_id': customerId.toString().trim(),
      'user_id': userId.toString().trim(),
      'Co_Code': companyCode.toString().trim(),
      'Sp_Name': spName.toString().trim(),
      'urnno': urnNo.toString().trim(),
      'FieldsString': fieldData
    };
    log('CustomAlertDialog :=> Mobile_Api_Autoselection_Lead Api Body ==> $data');
    await Future.wait([
      http.post(
          Uri.parse(clientUrl + "MobileApp_Lead/Mobile_Api_Autoselection_Lead"),
          body: data)
    ]).then((value) {
      // tools.stopLoading();
      if (value[0].statusCode == 200) {
        jsonData = json.decode(value[0].body);
        map = Map<String, dynamic>.from(jsonData);
        log('CustomAlertDialog :=>  Auto Selection:: ${json.decode(value[0].body)}'); // Map map = arrayList.toList().asMap();
        if (value.isNotEmpty) {
          var filterList = [];
          map.forEach((key, value) {
            if (key == "data") {
              filterList.clear();
              for (int i1 = 0; i1 < map["data"].length; i1++) {
                mapEntry = map[key][i1];
                for (final data in mapEntry.entries) {
                  filterList
                      .add(EmployeeTypeHelper(data.value, data.key, false));
                  print(
                      'Key ${data.key}, Value: ${data.value}'); // Key: a, Value: 1 ...
                }
              }
            }
          });
          setState(() {
            searchresult.clear();
            searchresult.addAll(filterList);
          });
        } else {
          setState(() {
            searchresult.clear();
            searchresult.addAll(selectionList);
          });
        }
      } else {
        // tools.stopLoading();
        throw Exception("Create Lead exception");
      }
    }, onError: (error) {
      // tools.stopLoading();
      Fluttertoast.showToast(
          msg: error,
          textColor: Colors.white,
          backgroundColor: Colors.red,
          gravity: ToastGravity.CENTER,
          toastLength: Toast.LENGTH_SHORT);
    });
  }*/

  Widget CustomRadio(Gender _gender) {
    return Card(
        color: _gender.isSelected ? PrimaryColor : grey_20,
        child: Container(
          alignment: Alignment.center,
          margin: new EdgeInsets.all(5.0),
          child: Column(
            children: <Widget>[
              Icon(
                _gender.icon,
                color: _gender.isSelected ? Colors.white : Colors.grey,
                size: 22,
              ),
            ],
          ),
        ));
  }
}

class RadioItem extends StatelessWidget {
  var searchresult;

  RadioItem(this.searchresult);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(15.0),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[
          Flexible(
            child: Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.black, width: 2),
                  borderRadius: BorderRadius.circular(60)),
              child: Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                    color: searchresult.isChecked ? const Color(0XFFE66D0A) : Colors.white,
                    borderRadius: BorderRadius.circular(60)),
              ),
            ),
          ),
          Flexible(
            child: Container(
              margin: const EdgeInsets.only(left: 10.0),
              child: Text(
                searchresult.name,
                style: const TextStyle(
                    color: Color(0xFF555555),
                    fontSize: 14.0,
                    fontFamily: 'poppins_regular'),
              ),
            ),
          ),
        ],
      ),
    );
  }




}

class Gender {
  String name;
  IconData icon;
  bool isSelected;

  Gender(this.name, this.icon, this.isSelected);
}
