import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_medinote/dashboard/DashBoardActivity.dart';
import 'package:flutter_medinote/login/LoginActivity.dart';
import 'package:flutter_medinote/login/LoginTypeScreen.dart';
import 'package:flutter_medinote/utils/Counter.dart';
import 'package:flutter_medinote/utils/PreferenceManager.dart';
import 'package:overlay_support/overlay_support.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(
      OverlaySupport(
        child: MaterialApp(
          theme: ThemeData(
              primaryColor:Colors.white,
              accentColor: const Color(0xFFe66d0a),
              fontFamily: 'poppins_regular'
          ),
          home: MyApp(),
          debugShowCheckedModeBanner: false,
        ),
      )
  );
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: Counter(),),
      ],
      child: MaterialApp(
        title: 'Flutter Demo',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.blue,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        home: SplashScreen(),
      ),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  double _progress = 0;
  bool isLoggedIn = false;
  var logInType="";

  @override
  void initState() {
    // TODO: implement initState
    super.initState();


    uservalidate().whenComplete(() async {
      startTime();
    });
    PreferenceManager.instance.getStringValue("logInType").then((value) => setState(() {
      logInType = value;
    }));
  }

  Future uservalidate() async {

    PreferenceManager.instance.getBooleanValue("loggedin").then((value) => setState(() {
      isLoggedIn = value;
    }));
    isLoggedIn = false;

  }

  startTime() {
    Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        if (_progress == 1) {
          timer.cancel();
          navigationPage();
        } else {
          _progress += 0.5;
        }
      });
    });
  }

  void navigationPage() {
    isLoggedIn ?
    _callDeshBoard()
        :
    Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (BuildContext context) => LoginTypeScreen()));
   /* Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (BuildContext context) => DashBoardActivity()));*/

  }

  Future _callDeshBoard() async{

    Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (BuildContext context) => DashBoardActivity()));

    /*PreferenceManager.instance.getStringValue("logInType").then((value) => setState(() {
      logInType = value;
    }));

    if(logInType=="Customer" ){

      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (BuildContext context) => DashBoardScreen()));
    }
    if(logInType=="User"){
      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (BuildContext context) => ClientDashBoard()));
    }*/

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //backgroundColor: Colors.yellow,
      body: Center(
        child: Center(
          child: Container(
            constraints: const BoxConstraints.expand(),
            decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('images/banner.png'),
                  fit: BoxFit.fitHeight,
                )),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Center(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 0.0, top: 0.0, right: 0.0),
                    child: Container(
                      child: Image.asset('images/logo_horizontal_medinote.png',
                        height: 300,
                        width: 300,),
                    ),
                  ),
                ),
                const Padding(
                  padding:
                  EdgeInsets.only(left: 30.0, top: 30.0, right: 30.0),
                  /*child: Text(
                        "CHITSCAN",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontFamily: "poppins_regular",
                            color: Colors.cyan,
                            fontWeight: FontWeight.bold,
                            fontStyle: FontStyle.italic,
                            fontSize: 20.0),
                      ),*/
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

