
import 'dart:convert';

import 'package:custom_radio_grouped_button/custom_radio_grouped_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_medinote/consultation/DetailConsFragment.dart';
import 'package:flutter_medinote/consultation/EditConsultationMedicineActivity.dart';
import 'package:flutter_medinote/response/CommonResponse.dart';
import 'package:flutter_medinote/response/ConsultantMedDataListingResponse.dart';
import 'package:flutter_medinote/utils/AppColors.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:loading_overlay/loading_overlay.dart';
import '../utils/PreferenceManager.dart';
import '../utils/VariableBag.dart';
import 'AddConsultationMedicineActivity.dart';
import 'DetailConsFragment.dart' as globals;

class MedicineConsFragment extends StatefulWidget {
  final TabController _tabController;
  const MedicineConsFragment(this._tabController, {Key? key}) : super(key: key);

  @override
  State<MedicineConsFragment> createState() => _MedicineConsFragmentState(_tabController);
}

class _MedicineConsFragmentState extends State<MedicineConsFragment> {
  var strMeal = "Before Meal" ;
  late double _width;
  late double _height;
  var isVisible = false;
  List<bool> showQty=[];

  TextEditingController specialController = TextEditingController();

  var _isLoading = true;
  var userId,searchText="",customerId="",page_index="1",conId,medId="";
  var dataList;

  late ScaffoldMessengerState _scaffoldMessengerState;

  final TabController _tabController;
  _MedicineConsFragmentState(this._tabController);

  void _showPopupMenu(Offset offset, BuildContext context, String medicineId) async {
    double left = offset.dx;
    double top = offset.dy;
    await showMenu(
      context: context,
      position: RelativeRect.fromLTRB(left, top, 50, 0),
      items: [
        PopupMenuItem<String>(
          onTap: (){
            print("--Edit");
            Future.delayed(
                const Duration(seconds: 0), () =>  NextPage(medicineId)
            );
          },
            child: const Text('Edit'), value: 'Edit'),
        PopupMenuItem<String>(
          onTap: () {
            print("--Delete");
            //alertDeletePatientDialog(context);
            Future.delayed(
              const Duration(seconds: 0), () => alertDeletePatientDialog(context)
            );
          },
            child: const Text('Delete'), value: 'Delete'),
      ],
      elevation: 8.0,
    );
  }
  @override

  void initState() {
    super.initState();

    for(int i=0;i<10;i++){
      showQty.add(false);
    }
    setPreferenceValue();
  }
  void showHide(int i){
    setState((){
      showQty[i]=!showQty[i];
    });
  }

  setPreferenceValue() async {
    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {
      userId = value;
    }));
    PreferenceManager.instance.getStringValue("conId").then((value) => setState((){
      conId = value;
      getConsultationMedicineList("");
    }));
  }

  Future getConsultationMedicineList(String searchtext) async{

    Map map ={
      'customer_id' : customerId,
      'user_id' : userId,
      'search_text' : searchtext,
      'page_index' : page_index,
      'con_id' : conId,
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/MediNoteConsultantMedDataListing"),body: map)
    ]).then((response) {

      var jasonData  = null;

      setState((){
        _isLoading = false;
      });

      if(response[0].statusCode==200){

        jasonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = ConsultantMedDataListingResponse.fromJson(map);

        if(response1.settings.success=="1"){

          dataList = ConsultantMedDataListingResponse.fromJson(map);

        }else{
          setState((){
            dataList = null;
          });
        }

      }else{
        _scaffoldMessengerState.showSnackBar(const SnackBar(content: Text("Something went wrong please try again later.")));
      }

    },onError: (error){
      setState((){
        _isLoading = false;
        Fluttertoast.showToast(msg: error.toString(),textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.CENTER);
      });
    });

  }

  @override
  Widget build(BuildContext context) {

    _width = MediaQuery.of(context).size.width;
    _height = MediaQuery.of(context).size.height;

    _scaffoldMessengerState = ScaffoldMessenger.of(context);

    return Scaffold(
      backgroundColor: grey_5,
      body: LoadingOverlay(
        isLoading: _isLoading,
        color: Colors.black54,
        opacity: 0.6,
        child: Padding(
          padding: const EdgeInsets.only(bottom: 8.0,top: 8.0),
          child: Container(
            width: _width,
            height: _height,
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
              child: Stack(
                children: [
                  Center(
                    child: _isLoading?Container(
                      child: const CircularProgressIndicator(),
                    ):dataList!=null ? BuildMedicineList(context,dataList) : Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const Image(width: 100, height: 100, image: AssetImage("images/folder.png"),color: PrimaryColor),
                        const SizedBox(
                          height: 10,
                        ),
                        const Align(alignment: Alignment.center, child: Text("Data not found",style: TextStyle(color: PrimaryColor,fontFamily: "poppins_regular",fontSize: 20.0),))
                      ],
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: FloatingActionButton(
                          backgroundColor: PrimaryColor,
                          onPressed: () async {

                            final reLoadPage = await Navigator.push(context, MaterialPageRoute(builder: (context) => AddConsultationMedicineActivity(conId),));
                            if(reLoadPage){
                              getConsultationMedicineList("");
                            }
                            },
                          child: const Icon(Icons.add,color: Colors.white,)
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: Container(
        child: InkWell(
          onTap: () {
            //_tabController.animateTo((_tabController.index + 1) % 4);
            if(dataList!=null){
              _tabController.animateTo((_tabController.index + 1) % 4);
            }else{
              _scaffoldMessengerState.showSnackBar(const SnackBar(content: Text("Please enter atleast one medicine")));

            }
          },
          child: Container(
            height: 50,
            decoration: BoxDecoration(
              color: PrimaryColor,
              borderRadius: BorderRadius.circular(30)
            ),
            child: const Center(
                child: Text("Next",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 25),)),
          ),
        ),
      ),
    );

  }

  Widget BuildMedicineList(BuildContext context,ConsultantMedDataListingResponse consultantMedDataListingResponse) {
    var value = consultantMedDataListingResponse.data;
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ListView.builder(
          itemCount: value!=null && value.length>0 ? value.length : 0,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 10.0),
              child: Card(
                elevation: 3,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      Row(
                        children: [
                          Container(
                            width: 30,
                            height: 30,
                            child: _medicineImg(value[index].medicineType),
                          ),
                          Expanded(child: Padding(
                            padding: const EdgeInsets.only(left: 5.0),
                            child: Text(value[index].medicineName.toString()),
                          )),
                          GestureDetector(
                              onTapDown: (TapDownDetails details){
                              print("dot click..");
                              medId = value[index].medicineId;
                              _showPopupMenu(details.globalPosition,context,value[index].medicineId);

                            },
                              child: const Icon(Icons.more_vert,size: 30,color: PrimaryColor,)
                          ),
                        ],
                      ),
                      const SizedBox(height: 10,),
                      const Divider(
                        thickness: 1, // thickness of the line
                        indent: 0, // empty space to the leading edge of divider.
                        endIndent: 0, // empty space to the trailing edge of the divider.
                        color: grey_10, // The color to use when painting the line.
                        height: 2, // The divider's height extent.
                      ),
                      const SizedBox(height: 10,),
                      AbsorbPointer(
                        absorbing: true,
                        child: CustomRadioButton(
                          key: UniqueKey(),
                          unSelectedBorderColor: grey_90,
                          selectedBorderColor: PrimaryColor,
                          height: 25,
                          width: _width/2.4,
                          elevation: 0,
                          absoluteZeroSpacing: true,
                          unSelectedColor: Colors.white,
                          defaultSelected: value[index].beforOrAfter.toString(),
                          buttonLables: const [
                            'Before Meal',
                            'After Meal',
                          ],
                          buttonValues: const [
                            'Before Meal',
                            'After Meal',
                          ],
                          buttonTextStyle: const ButtonTextStyle(
                              selectedColor: Colors.white,
                              unSelectedColor: grey_60,
                              textStyle: TextStyle(fontSize: 16)),
                          radioButtonValue: (value) {
                            print(value);
                            strMeal = value.toString();
                            print("meal"+strMeal);
                          },
                          enableShape: true,
                          selectedColor: PrimaryColor,
                        ),
                      ),
                      const SizedBox(height: 10,),
                      const Divider(
                        thickness: 1, // thickness of the line
                        indent: 0, // empty space to the leading edge of divider.
                        endIndent: 0, // empty space to the trailing edge of the divider.
                        color: grey_10, // The color to use when painting the line.
                        height: 2, // The divider's height extent.
                      ),
                      const SizedBox(height: 10,),
                      const Text("Frequency"),
                      const SizedBox(height: 10,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Flexible(
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: PrimaryColor)
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                const Padding(
                                  padding: EdgeInsets.only(left: 8.0,right: 2),
                                  child: Icon(Icons.remove,color: PrimaryColor,),
                                ),
                                const SizedBox(width: 10,),
                                Flexible(child: Text((value[index].atMorning.toString()))),
                                const SizedBox(width: 10,),
                                const Padding(
                                  padding: EdgeInsets.only(left: 2.0,right: 8),
                                  child: const Icon(Icons.add,color: PrimaryColor,),
                                ),

                              ],),
                            ),
                          ),
                          Flexible(
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: PrimaryColor)
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                const Padding(
                                  padding: EdgeInsets.only(left: 8.0,right: 2),
                                  child: const Icon(Icons.remove,color: PrimaryColor,),
                                ),
                                const SizedBox(width: 10,),
                                Flexible(child: Text((value[index].atAfternoon.toString()))),
                                const SizedBox(width: 10,),
                                const Padding(
                                  padding: EdgeInsets.only(left: 2.0,right: 8),
                                  child: const Icon(Icons.add,color: PrimaryColor,),
                                ),

                              ],),
                            ),
                          ),
                          Flexible(
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: PrimaryColor)
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                const Padding(
                                  padding: EdgeInsets.only(left: 8.0,right: 2),
                                  child: const Icon(Icons.remove,color: PrimaryColor,),
                                ),
                                const SizedBox(width: 10,),
                                Flexible(child: Text((value[index].atEvening.toString()))),
                                const SizedBox(width: 10,),
                                const Padding(padding: EdgeInsets.only(left: 2.0,right: 8),
                                  child: Icon(Icons.add,color: PrimaryColor,),),


                              ],),
                            ),
                          ),

                        ],
                      ),
                      const SizedBox(height: 10,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                        const Text("Morning"),
                          const SizedBox(width: 5,),
                        const Text("Afternoon"),
                          const SizedBox(width: 5,),
                        const Text("Night"),
                      ],),
                      const SizedBox(height: 10,),
                      Center(
                        child: InkWell(
                          onTap: () {
                            if(isVisible){
                              setState((){
                                isVisible = false;
                              });
                            }else{
                              setState((){
                                isVisible = true;
                              });
                            }
                              print('show');
                              showHide( index);
                          },
                          child: Container(
                            decoration: new BoxDecoration(
                              color: PrimaryColor,
                              border: new Border.all(color: PrimaryColor, width: 1.0),
                              borderRadius: new BorderRadius.circular(30.0),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(left: 10.0,),
                                  child: new Text(
                                    'Show more',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'poppins_regular',
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                                Container(
                                  key: UniqueKey(),
                                  child: showQty[index] ? new  Icon(Icons.keyboard_arrow_down ,size: 22.0,color: Colors.white,):
                                  new  Icon(Icons.keyboard_arrow_right,size: 22.0,color: Colors.white,),
                                ),


                              ],
                            ),
                          ),
                        ),
                      ),
                      showQty[index] ? Column(
                        children: [
                        const SizedBox(height: 10,),
                        Row(
                          children: [
                            Expanded(
                              child: Column(

                                children: [
                                  Row(children: [
                                    Expanded(
                                        child: Text(value[index].medicineWith.toString())),
                                        const Icon(Icons.arrow_drop_down_outlined,color: PrimaryColor,)
                                      ]),
                                ],
                              ),
                            ),
                            Expanded(
                              child: Column(

                                children: [
                                  Row(children: [
                                        Expanded(child: Text(value[index].medicineSchedule.toString())),
                                        const Icon(Icons.arrow_drop_down_outlined,color: PrimaryColor,)
                                      ]),
                                ],
                              ),
                            ),
                          ],
                        ),
                          const SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_10, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),
                          const SizedBox(height: 10,),
                          Row(
                            children: [
                              Expanded(
                                child: Column(

                                  children: [
                                    Row(children: [
                                      Expanded(
                                          child: Text(value[index].startDate.toString())),
                                      const Icon(Icons.arrow_drop_down_outlined,color: PrimaryColor,)
                                    ]),
                                  ],
                                ),
                              ),
                              Expanded(
                                child: Column(

                                  children: [
                                    Row(children: [
                                      Expanded(child: Text(value[index].endDate.toString())),
                                      const Icon(Icons.arrow_drop_down_outlined,color: PrimaryColor,)
                                    ]),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10,),
                        const Divider(
                          thickness: 1, // thickness of the line
                          indent: 0, // empty space to the leading edge of divider.
                          endIndent: 0, // empty space to the trailing edge of the divider.
                          color: grey_10, // The color to use when painting the line.
                          height: 2, // The divider's height extent.
                        ),
                        const SizedBox(height: 10,),
                        TextFormField(
                          key: UniqueKey(),
                          readOnly: true,
                          minLines: 1,
                          maxLines: 5,
                          initialValue: value[index].remark.toString(),
                          keyboardType: TextInputType.multiline,
                          decoration: InputDecoration(
                              labelText: 'Special Remark',
                              labelStyle: const TextStyle(
                                  color: PrimaryColor
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: grey_60,width: 1),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: const BorderSide(
                                      color: grey_20

                                  )
                              )


                          ),
                          /*onChanged: (value){
                            strSpecialRemark = value;
                          },*/
                        ),
                      ],): Container(),

                    ],
                  ),
                ),
              ),
            );
        },
        ),
      ),
    );
  }

  Widget _medicineImg(medicineType) {
    if (medicineType == "Capsule") {
      return Image.asset('images/ic_capsule__off.png', color: PrimaryColor,);
    } else if (medicineType == "Tablet") {
      return Image.asset('images/ic_tablet_onn.png', color: PrimaryColor,);;
    } else if (medicineType == "ML (Syrup)") {
      return Image.asset('images/ic_syrup_off.png', color: PrimaryColor,);
    } else {
      return Image.asset(
        'images/ic_other_medicine_off.png', color: PrimaryColor,);
    }
  }

  Future<String> alertDeletePatientDialog(context) async{
    return await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Container(
              height: 120,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(top: 10.0),
                    child: const Text("Are you sure you want to delete this medicine detail?"),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            print('yes selected');
                            Navigator.of(context).pop();
                            DeleteMedicine();
                          },
                          child: const Text("Yes"),
                          style: ElevatedButton.styleFrom(primary: Colors.red.shade800),
                        ),
                      ),
                      const SizedBox(width: 15),
                      Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              print('no selected');
                              Navigator.of(context).pop();
                            },
                            child: const Text("No", style: TextStyle(color: Colors.black)),
                            style: ElevatedButton.styleFrom(
                              primary: Colors.white,
                            ),
                          ))
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }

  Future DeleteMedicine() async{

    setState((){
      _isLoading = true;
    });

    Map data = {
      'customer_id':customerId,
      'user_id' : userId,
      'con_id' : conId,
      'med_id' : medId,
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/DeleteMediNoteConsultantMedData"),body: data)
    ]).then((response) {
      var jasonData = null;

      if(response[0].statusCode==200){
        jasonData = jsonDecode(response[0].body);
        var response1 = CommonResponse.fromJson(jasonData);

        if(response1.settings.success=="1"){
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message)));
          getConsultationMedicineList("");
        }else{
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message)));
        }
      }else{
        _scaffoldMessengerState.showSnackBar(const SnackBar(content: const Text("Somthing went wrong please try again later.")));
      }

    },onError: (error){
      setState((){
        _isLoading = false;
        Fluttertoast.showToast(msg: error.toString(),textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.CENTER);
      });
    });


  }
  showAlertDialog(BuildContext context) {

    // set up the buttons
    Widget cancelButton = TextButton(
      child: const Text("Cancel"),
      onPressed:  () {},
    );
    Widget continueButton = TextButton(
      child: const Text("Continue"),
      onPressed:  () {},
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: const Text("AlertDialog"),
      content: const Text("Would you like to continue learning how to use Flutter alerts?"),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  NextPage(String medicineId) async {
    final reLoadPage = await Navigator.push(context, MaterialPageRoute(builder: (context) => EditConsultationMedicineActivity(conId,medicineId),));
    if(reLoadPage){
      getConsultationMedicineList("");
    }
  }

}
