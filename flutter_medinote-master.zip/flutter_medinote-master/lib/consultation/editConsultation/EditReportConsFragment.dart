
import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import '../../utils/Counter.dart';

import '../../response/CommonResponse.dart';
import '../../response/ConsultantAttachmentListingResponse.dart';
import '../../utils/AppColors.dart';
import '../../utils/ImageFIles.dart';
import '../../utils/PreferenceManager.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as path;

import '../../utils/VariableBag.dart';

class EditReportConsFragment extends StatefulWidget {
  final String consultantId,isEditable;
  const EditReportConsFragment(this.consultantId, this.isEditable, {Key? key}) : super(key: key);

  @override
  State<EditReportConsFragment> createState() => _EditReportConsFragmentState(consultantId,isEditable);
}

class _EditReportConsFragmentState extends State<EditReportConsFragment> {
  String consultantId,isEditable;
  _EditReportConsFragmentState(this.consultantId,this.isEditable);

  late ScaffoldMessengerState _scaffoldMessengerState;
  late double _width;
  late double _height;
  var _isLoading = false;
  // ignore: prefer_typing_uninitialized_variables
  var userId,searchText="",customerId="",page_index="1";
  var dataList = null;
  late ConsultantAttachmentListingResponse consAttachLisRes;

  var filenameOriginal;
  var todayDate;
  var inputFormat = DateFormat('dd_MM_yyy_HH_mm_ss');
  var fileextention = "";
  var fileName,isDeleteView=false;
  List<ImageFiles> imageFiles = [];

  @override
  void initState() {
    super.initState();

    setPreferenceValue();
    todayDate = inputFormat.format(DateTime.now());
    filenameOriginal = "$todayDate";
  }

  setPreferenceValue() async {
    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {
      userId = value;
      getConsultationAttachmentList("");
    }));

  }

  Future getConsultationAttachmentList(String searchtext) async{

    Map map ={
      'customer_id' : customerId,
      'user_id' : userId,
      'search_text' : searchtext,
      'con_id' : consultantId,
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/MediNoteConsultantAttachmentListing"),body: map)
    ]).then((response) {

      var jasonData  = null;

      setState((){
        _isLoading = false;
      });

      if(response[0].statusCode==200){

        jasonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jasonData);
        var response1 = ConsultantAttachmentListingResponse.fromJson(map);

        if(response1.settings.success=="1"){

          dataList = ConsultantAttachmentListingResponse.fromJson(map);
          consAttachLisRes = dataList;
        }else{
          setState((){
            dataList = null;
          });
        }

      }else{
        _scaffoldMessengerState.showSnackBar(const SnackBar(content: Text("Something went wrong please try again later.")));
      }

    },onError: (error){
      setState((){
        _isLoading = false;
        Fluttertoast.showToast(msg: error.toString(),textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.CENTER);
      });
    });

  }

  @override
  Widget build(BuildContext context) {

    _width = MediaQuery.of(context).size.width;
    _height = MediaQuery.of(context).size.height;

    _scaffoldMessengerState = ScaffoldMessenger.of(context);
    isDeleteView = Provider.of<Counter>(context).getCounter;
    return Scaffold(
      backgroundColor: grey_5,
      body: LoadingOverlay(
        isLoading: _isLoading,
        color: Colors.black54,
        opacity: 0.6,
        child: Padding(
          padding: const EdgeInsets.only(bottom: 8.0,top: 8.0),
          child: Container  (
            width: _width,
            height: _height,
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
              child: Stack(
                children: [
                  Center(
                    child: _isLoading?Container(
                      child: const CircularProgressIndicator(),
                    ): dataList!=null ? BuildMedicineList(context,dataList) : Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: const [
                        Image(width: 100, height: 100, image: AssetImage("images/folder.png"),color: PrimaryColor),
                        SizedBox(
                          height: 10,
                        ),
                        Align(alignment: Alignment.center, child: Text("Data not found",style: TextStyle(color: PrimaryColor,fontFamily: "poppins_regular",fontSize: 20.0),))
                      ],
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: FloatingActionButton(
                          backgroundColor: PrimaryColor,
                          onPressed: ()  {
                            openCamera(consultantId);
                          },
                          child: const Icon(Icons.add,color: Colors.white,)
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: InkWell(
        onTap: () {
          Navigator.pop(context,true);
        },
        child: Container(
          height: 50,
          decoration: BoxDecoration(
              color: PrimaryColor,
              borderRadius: BorderRadius.circular(30)
          ),
          child: const Center(
              child: Text("Save",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 25),)),
        ),
      ),
    );
  }

  Widget BuildMedicineList(BuildContext context,ConsultantAttachmentListingResponse consultantAttachmentListingResponse) {
    var value = consultantAttachmentListingResponse.conAttach[0].conAttach.report;
    return Container(
        child: value != null && value.length>0 ? Padding(
          padding: const EdgeInsets.only(left: 8.0,right: 8,top: 8,bottom: 60),
          child: ListView.builder(

            itemCount: value!=null && value.length>0 ? value.length : 0,
            itemBuilder: (context, index) {
              return Padding(
                  padding: const EdgeInsets.only(bottom: 10.0),
                  child:Card(
                      elevation: 3,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      margin: const EdgeInsets.only(left: 20, top: 20, right: 20),
                      child:  Column(
                          children: [
                            const SizedBox(height: 10,),
                            /* Image.asset("images/pdf.png", fit: BoxFit.contain, width: MediaQuery.of(context).size.width, height: 150),*/
                            Image.network(

                              value[index].reportPath.replaceAll("////", "//"),
                              errorBuilder: (BuildContext context, Object exception,
                                  StackTrace? stackTrace) {
                                return const   Icon(Icons.error,size: 30,color: PrimaryColor,);
                              },
                              height: 250,
                            ),

                            const SizedBox(height: 10,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  child: Padding(
                                    padding: const EdgeInsets.all(7.0),
                                    child: Text(value[index].report, style: const TextStyle(fontFamily: "poppins_regular", fontSize: 12, color: Color(0XFF555555), fontWeight: FontWeight.bold),),
                                  ),
                                ),
                                Visibility(
                                  visible: isDeleteView,
                                  child: InkWell(
                                    onTap: () {
                                      alertDeleteReportDialog(
                                          context,
                                          value[index].reportName,
                                          value[index].reportPath,
                                          value[index].reportNo.toString()
                                      );
                                    },
                                    child: const Padding(
                                      padding: EdgeInsets.only(right: 8.0),
                                      child: Icon(Icons.delete,color: PrimaryColor,size: 30,),
                                    ),
                                  ),
                                )
                              ],
                            ),

                          ])
                  )
              );
            },
          ),
        ) :Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: const [
            Image(width: 100, height: 100, image: AssetImage("images/folder.png"),color: PrimaryColor),
            SizedBox(
              height: 10,
            ),
            Align(alignment: Alignment.center, child: Text("Data not found",style: TextStyle(color: PrimaryColor,fontFamily: "poppins_regular",fontSize: 20.0),))
          ],
        )
    );
  }

  openCamera(conId) {
    permissionServiceCall("FromCamera");
  }

  permissionServiceCall(String type) async {
    await permissionServices(type).then(
          (value) {
        if (value[Permission.storage]!.isGranted && value[Permission.camera]!.isGranted) {
          if(type=="FromCamera") {
            _showChoiceDialog(context);
          }else{
            //_openFile(context);
          }
        }
      },
    );
  }

  Future<Map<Permission, PermissionStatus>> permissionServices(String type) async {
    // You can request multiple permissions at once.
    Map<Permission, PermissionStatus> statuses = await [
      Permission.storage,
      Permission.camera,
      //add more permission to request here.
    ].request();

    if (statuses[Permission.storage]!.isPermanentlyDenied) {
      await openAppSettings().then(
            (value) async {
          if (value) {
            if (await Permission.storage.status.isPermanentlyDenied == true &&
                await Permission.storage.status.isGranted == false) {
              openAppSettings();
              // permissionServiceCall(); /* opens app settings until permission is granted */
            }
          }
        },
      );
    } else {
      if (statuses[Permission.storage]!.isDenied) {
        if(type=="FromCamera") {
          permissionServiceCall(type);
        }else{
          permissionServiceCall(type);
        }
      }
    }

    if (statuses[Permission.camera]!.isPermanentlyDenied) {
      await openAppSettings().then(
            (value) async {
          if (value) {
            if (await Permission.camera.status.isPermanentlyDenied == true &&
                await Permission.camera.status.isGranted == false) {
              openAppSettings();
              // permissionServiceCall(); /* opens app settings until permission is granted */
            }
          }
        },
      );
      //openAppSettings();
      //setState(() {});
    } else {
      if (statuses[Permission.camera]!.isDenied) {
        if(type=="FromCamera") {
          permissionServiceCall(type);
        }else{
          permissionServiceCall(type);
        }
      }
    }
    /*{Permission.camera: PermissionStatus.granted, Permission.storage: PermissionStatus.granted}*/
    return statuses;
  }

  Future<void> _showChoiceDialog(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text(
              "Choose option",
              style: TextStyle(color: Colors.blue),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: [
                  const Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      _openGallery(context);
                    },
                    title: const Text("Gallery"),
                    leading: const Icon(
                      Icons.account_box,
                      color: Colors.blue,
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      _openCamera(context);
                    },
                    title: const Text("Camera"),
                    leading: const Icon(
                      Icons.camera,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

  void _openGallery(BuildContext context) async {
    imageFiles.clear();
    final pickedFile = await ImagePicker().getImage(
      source: ImageSource.gallery,
      imageQuality: 85,
    );
    final bytes = (await pickedFile?.readAsBytes())?.lengthInBytes;
    final kb = (bytes! / 1024);
    final mb = (kb / 1024);
    log('KB ==> $kb MB ==> $mb');
    if(mb<10) {
      setState(() {
        filenameOriginal= "SalesOrder_$todayDate";
        final File _file = File(pickedFile!.path.toString());
        fileextention = path.extension(_file.path);
        log('Original path: ${pickedFile.path} ');
        fileName='$filenameOriginal$fileextention';
        log('New path: $fileName ');
        imageFiles.add(ImageFiles(fileName, pickedFile.path.toString(), fileextention.toString()));

        uploadImage(imageFiles);
      });
    }else{
      Fluttertoast.showToast(msg: "Please select image less than or equal to 10 MB",gravity: ToastGravity.CENTER,toastLength: Toast.LENGTH_SHORT,textColor: Colors.white,backgroundColor: Colors.red);
    }
    Navigator.pop(context);
  }

  void _openCamera(BuildContext context) async {
    imageFiles.clear();
    final pickedFile = await ImagePicker().getImage(
      source: ImageSource.camera,
      imageQuality: 85,
    );
    final bytes = (await pickedFile?.readAsBytes())?.lengthInBytes;
    final kb = (bytes! / 1024);
    final mb = (kb / 1024);
    log('KB ==> $kb MB ==> $mb');

    if(mb<10) {
      setState(() {
        filenameOriginal= "SalesOrder_$todayDate";
        final File _file = File(pickedFile!.path.toString());
        fileextention = path.extension(_file.path);
        log('Original path: ${pickedFile.path} ');
        fileName='$filenameOriginal$fileextention';
        log('New path: $fileName ');
        imageFiles.add(ImageFiles(fileName, pickedFile.path.toString(), fileextention.toString()));
        uploadImage(imageFiles);
      });
    }else{
      Fluttertoast.showToast(msg: "Please select image less than or equal to 10 MB",gravity: ToastGravity.CENTER,toastLength: Toast.LENGTH_SHORT,textColor: Colors.white,backgroundColor: Colors.red);
    }
    Navigator.pop(context);
  }

  void uploadImage(List<ImageFiles> imageFiles) {
    if(imageFiles.isNotEmpty){
      uploadmultipleimage(imageFiles);
    }
  }

  Future uploadmultipleimage(List imageFiles) async {

    setState((){
      _isLoading = true;
    });

    var request = http.MultipartRequest("POST",Uri.parse(BASE_URL+"MobileApp/SaveMediNoteConsultantAttachment"));
    request.fields['customer_id'] = customerId;
    request.fields['user_id'] = userId;
    request.fields['con_id'] = consultantId;
    request.fields['attach_called'] = "TestReport";
    request.fields['attach_type'] = "Report";

    for(int i=0; i < imageFiles.length; i++){
      request.files.add(http.MultipartFile(
          'files',
          File(imageFiles[i].path).readAsBytes().asStream(),
          File(imageFiles[i].path).lengthSync(),
          filename: imageFiles[i].path.split("/").last));
    }
    var response = await request.send();

    if(response.statusCode== 200){
      setState((){
        _isLoading = false;
      });

      Fluttertoast.showToast(msg: "Upload Successfully.",textColor: Colors.white,backgroundColor: Colors.green,gravity: ToastGravity.CENTER);
    }else{
      setState((){
        _isLoading = false;
      });
      Fluttertoast.showToast(msg: "File not found.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.CENTER);
    }
    getConsultationAttachmentList("");
  }

  Future<String> alertDeleteReportDialog(context, String prescription, String reportPath, String reportNo) async{
    return await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Container(
              height: 120,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(top: 10.0),
                    child: Text("Are you sure you want to delete this prescription detail?"),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            print('yes selected');
                            Navigator.of(context).pop();
                            DeleteReportt(prescription,reportPath,reportNo);
                          },
                          child: const Text("Yes"),
                          style: ElevatedButton.styleFrom(primary: Colors.red.shade800),
                        ),
                      ),
                      const SizedBox(width: 15),
                      Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              print('no selected');
                              Navigator.of(context).pop();
                            },
                            child: const Text("No", style: TextStyle(color: Colors.black)),
                            style: ElevatedButton.styleFrom(
                              primary: Colors.white,
                            ),
                          ))
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }

  Future DeleteReportt(String prescription, String reportPath, String reportNo) async{

    setState((){
      _isLoading = true;
    });

    Map data = {
      'customer_id':customerId,
      'user_id' : userId,
      'con_id' : consultantId,
      'AttachNo' : reportNo,
      'fileName' : reportPath,
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/DeleteMediNoteConsultantAttachment"),body: data)
    ]).then((response) {
      var jasonData = null;

      if(response[0].statusCode==200){
        jasonData = jsonDecode(response[0].body);
        var response1 = CommonResponse.fromJson(jasonData);

        if(response1.settings.success=="1"){
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message)));
          getConsultationAttachmentList("");
        }else{
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message)));
        }
      }else{
        _scaffoldMessengerState.showSnackBar(const SnackBar(content: Text("Somthing went wrong please try again later.")));
      }

    },onError: (error){
      setState((){
        _isLoading = false;
        Fluttertoast.showToast(msg: error.toString(),textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.CENTER);
      });
    });


  }

}
