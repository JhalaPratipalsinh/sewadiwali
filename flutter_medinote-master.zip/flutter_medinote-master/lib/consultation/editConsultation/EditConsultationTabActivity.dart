
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_medinote/consultation/editConsultation/EditDetailConsFragment.dart';
import 'package:flutter_medinote/consultation/editConsultation/EditMedicineConsFragment.dart';
import 'package:flutter_medinote/consultation/editConsultation/EditPrescriptionConsFragment.dart';
import 'package:flutter_medinote/consultation/editConsultation/EditReportConsFragment.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;

import '../../response/CommonResponse.dart';
import '../../utils/AppColors.dart';
import '../../utils/Counter.dart';
import '../../utils/PreferenceManager.dart';
import '../../utils/VariableBag.dart';

class EditConsultationTabActivity extends StatefulWidget {

  final String consultantId;
  const EditConsultationTabActivity(this.consultantId, {Key? key}) : super(key: key);

  @override
  State<EditConsultationTabActivity> createState() => _EditConsultationTabActivityState(consultantId);

}

class _EditConsultationTabActivityState extends State<EditConsultationTabActivity> with TickerProviderStateMixin {


  final String consultantId;

  _EditConsultationTabActivityState(this.consultantId);
  var _isLoading = false,userId,customerId="";
  late ScaffoldMessengerState _scaffoldMessengerState;

  late TabController  _tabController;
  var isEditMod = false,isEditable="1";
  var myMenuItems = <String>[
    'Edit',
    'Delete',
  ];
  void onSelect(item){
    switch(item){
      case "Edit":

          isEditMod = true;
          disableView("2",context);
        break;
      case "Delete":
        print("Delet click");
        alertDeletePatientDialog(context);

        break;
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    //disableView("1");
    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {
      userId = value;
    })
    );
  }

  @override
  Widget build(BuildContext context) {

    _scaffoldMessengerState = ScaffoldMessenger.of(context);

    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: grey_5,

      appBar: AppBar(title: Text("Edit Consultation"),backgroundColor: PrimaryColor,
        actions: [
          PopupMenuButton(
            onSelected: onSelect,
              itemBuilder: (BuildContext context) {
              return myMenuItems.map((String choice) {
                return PopupMenuItem<String>(
                  value: choice,
                    child: Text(choice)
                );
              }).toList();
              },
          )
        ],
      ),
      body: Column(
        children: [
          Padding(padding: const EdgeInsets.only(top: 15.0,left: 10,right: 10),
            child: Container(
              height: 40,
              decoration: BoxDecoration(color: grey_20, borderRadius: BorderRadius.circular(25),),
              child: TabBar(
                  controller: _tabController,
                  indicator: BoxDecoration(color: PrimaryColor, borderRadius:BorderRadius.circular(25)),
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.black,
                  tabs: const [
                    Tab(text: "DETAIL"),
                    Tab(text:"MEDICINE"),
                    Tab(text:"PRESCRIPTION"),
                    Tab(text:"REPORT"),
                  ]),
            ),
          ),
          Expanded(
            child: TabBarView(
                controller: _tabController,
                children: [
                  EditDetailConsFragment(_tabController,consultantId,isEditable),
                  EditMedicineConsFragment(_tabController,consultantId,isEditable),
                  EditPrescriptionConsFragment(_tabController,consultantId,isEditable),
                  EditReportConsFragment(consultantId,isEditable),
                ]),
          ),
        ],
      ),
    );
  }

  Future disableView(String isEdit, BuildContext context) async{
    //1 disable,2 editable
    Provider.of<Counter>(context, listen: false).incrementCounter();

    /*if(isEdit=="2"){
        isEditable = "2";
        context.read<EditDetailConsFragmentState>().increment(isEditable);

       // ani.doSomething();
    }else{
      //isEditable = "1";
    }*/
  }

  Future<bool> alertDeletePatientDialog(context) async{
    return await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: Container(
              height: 120,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(top: 10.0),
                    child: Text("Are you sure you want to delete this consultation detail?"),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            print('yes selected');
                            Navigator.of(context).pop();
                            DeletePatient();
                          },
                          child: Text("Yes"),
                          style: ElevatedButton.styleFrom(primary: Colors.red.shade800),
                        ),
                      ),
                      SizedBox(width: 15),
                      Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              print('no selected');
                              Navigator.of(context).pop();
                            },
                            style: ElevatedButton.styleFrom(
                              primary: Colors.white,
                            ),
                            child: const Text("No", style: TextStyle(color: Colors.black)),
                          ))
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }

  Future DeletePatient() async{

    setState((){
      _isLoading = true;
    });
    Map data = {
      'customer_id' : "",
      'user_id' : userId,
      'con_id' : widget.consultantId,
    };

    final response = await http.post(Uri.parse(BASE_URL+"MobileApp/DeleteMediNoteConsultantData"),body: data);

    setState((){
      _isLoading = true;
    });
    if(response!=null){
      var jsonData = null;
      if(response.statusCode==200){
        jsonData = jsonDecode(response.body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = CommonResponse.fromJson(map);
        if(response1.settings.success == "1"){
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));

          Navigator.pop(context,true);

        }else{
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));

          print("add Vision  response success  not arrive");
        }
      }else{
        print("add vision response 200 not arrive");
      }
    }else{
      print("add vison response null");
    }



  }


}
