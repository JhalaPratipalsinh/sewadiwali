
import 'package:flutter/material.dart';
import 'package:flutter_medinote/consultation/PrescriptionConsFragment.dart';
import 'package:flutter_medinote/consultation/ReportConsFragment.dart';
import 'package:flutter_medinote/consultation/DetailConsFragment.dart';
import 'package:flutter_medinote/consultation/MedicineConsFragment.dart';
import 'package:flutter_medinote/utils/AppColors.dart';

class AddConsultationTabActivity extends StatefulWidget {
  const AddConsultationTabActivity({Key? key}) : super(key: key);

  @override
  State<AddConsultationTabActivity> createState() => _AddConsultationTabActivityState();
}

class _AddConsultationTabActivityState extends State<AddConsultationTabActivity> with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _tabController = TabController(length:4, vsync: this);
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: grey_5,
      appBar: AppBar(title: const Text("Add Consultation"),backgroundColor: PrimaryColor,),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 15.0,left: 10,right: 10),
            child: Container(
              height: 40,
              decoration: BoxDecoration(
                color: grey_20,
                borderRadius: BorderRadius.circular(25),
              ),
              child: IgnorePointer(
                child: TabBar(
                  controller: _tabController,
                  indicator: BoxDecoration(
                    color: PrimaryColor,
                    borderRadius:BorderRadius.circular(25)
                  ),
                    labelColor: Colors.white,
                    unselectedLabelColor: Colors.black,
                    tabs: const [
                      Tab(text: "DETAIL"),
                      Tab(text:"MEDICINE"),
                      Tab(text:"PRESCRIPTION"),
                      Tab(text:"REPORT"),
                    ]),
              ),
            ),
          ),
          Expanded(
            child: TabBarView(
              physics: NeverScrollableScrollPhysics(),
              controller: _tabController,
                children: [
                  DetailConsFragment(_tabController),
                  MedicineConsFragment(_tabController),
                  PrescriptionConsFragment(_tabController),
                  ReportConsFragment(),
                ]),
          ),
        ],
      ),
    );
  }
}
