
import 'dart:convert';

import 'package:custom_radio_grouped_button/custom_radio_grouped_button.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:http/http.dart' as http;
import '../response/ConsultantMainDataResponse.dart';
import '../response/MedicineListingResponse.dart';
import '../response/SavePatientResponse.dart';
import '../utils/AppColors.dart';
import '../utils/CustomAlertSelectionDialog.dart';
import '../utils/EmployeeTypeHelper.dart';
import '../utils/GetEditTextValueHelper.dart';
import '../utils/PreferenceManager.dart';
import '../utils/VariableBag.dart';

class AddConsultationMedicineActivity extends StatefulWidget {
  final String conId;
  const AddConsultationMedicineActivity(this.conId, {Key? key}) : super(key: key);

  @override
  State<AddConsultationMedicineActivity> createState() => _AddConsultationMedicineActivityState(conId);
}

class _AddConsultationMedicineActivityState extends State<AddConsultationMedicineActivity> {
  late ScaffoldMessengerState _scaffoldMessengerState;
  late double _width,_height;
  var strMeal = "Before Meal" ;
  var isVisible = false;
  var userId,customerId="",medicineId="", medicineName="",strSpecialRemark="",withMeal="",schedule="";
  var _isLoading = false;
  TextEditingController specialController = TextEditingController();
  TextEditingController selectMedicineController = TextEditingController();
  List<EmployeeTypeHelper> medicineList = [];
  List<EmployeeTypeHelper> withWaterMildList = [];
  List<EmployeeTypeHelper> scheduleList = [];
  TextEditingController morningController = TextEditingController();
  TextEditingController afternoonController = TextEditingController();
  TextEditingController nightController = TextEditingController();
  TextEditingController withwatermilkController = TextEditingController();
  TextEditingController scheduleController = TextEditingController();
  TextEditingController startDateController = TextEditingController();
  TextEditingController endDateController = TextEditingController();

  var strMedicineImage;
  String conId;
  _AddConsultationMedicineActivityState(this.conId);
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {
      userId = value;
      getMedicineList();

    }));
    morningController.text = "0";
    afternoonController.text = "0";
    nightController.text = "0";
    startDateController.text = "";
    endDateController.text = "";

    scheduleList.add(EmployeeTypeHelper("Daily", "1", "", false, ""));
    scheduleList.add(EmployeeTypeHelper("Alternate Day", "2", "", false, ""));
    scheduleList.add(EmployeeTypeHelper("Weekly", "3", "", false, ""));
    scheduleList.add(EmployeeTypeHelper("Wheen need", "4", "", false, ""));

    withWaterMildList.add(EmployeeTypeHelper("With Water", "1", "", false, ""));
    withWaterMildList.add(EmployeeTypeHelper("With Milk", "2", "", false, ""));

  }

  Future getMedicineList() async {

    Map data = {
      'customer_id' : customerId,
      'user_id' : userId,
      'filtertext' : "",
      'Select_Valuecode' : ""
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/MedicineListing"),body: data)
    ]).then((response) {
      var jsonData = null;

      if(response[0].statusCode==200){
        jsonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = MedicineListingResponse.fromJson(map);

        if(response1.settings.success=="1"){
          for(int i =0; i<response1.data.length; i++) {
            medicineList.add(EmployeeTypeHelper(response1.data[i].medicineName, response1.data[i].medicineId, "", false,response1.data[i].medicineType));
          }
        }
      }else{
        print("status code wrong");
      }
    },onError: (error){

    });
  }

  @override
  Widget build(BuildContext context) {
    _width = MediaQuery.of(context).size.width;
    _height = MediaQuery.of(context).size.height;

    bool isKeyboardOpen = MediaQuery.of(context).viewInsets.bottom != 0.0;

    _scaffoldMessengerState = ScaffoldMessenger.of(context);

    return Scaffold(
      appBar: AppBar(title: Text("Add Medicine"),backgroundColor: PrimaryColor,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 15.0),
            child: InkWell(
                onTap: (){
                  checkValidation();
                },
                child: Icon(Icons.check)),
          ),
        ],),
      body: LoadingOverlay(
        isLoading: _isLoading,
        color: Colors.black54,
        opacity: 0.6,
        child: Padding(
          padding: const EdgeInsets.only(top: 8.0,bottom: 8),
          child: Container(
            width: _width,
            height: _height,
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10.0),
                        child: Card(
                          elevation: 3,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [

                                Row(
                                  children: [
                                    strMedicineImage!=null? Image.asset(strMedicineImage, width: 40,height: 40,color: PrimaryColor,):Container(),
                                    Flexible(
                                      child: Padding(
                                        padding: const EdgeInsets.only(left: 8.0),
                                        child: TextFormField(
                                          controller: selectMedicineController,
                                          style: TextStyle(fontSize: 15),
                                          readOnly: true,
                                          decoration: InputDecoration(
                                            hintText: "Select medicine*",
                                            suffixIcon: Icon(Icons.arrow_drop_down_outlined,color: PrimaryColor,),
                                            border: InputBorder.none,
                                          ),

                                          onTap: (){
                                            print("click");
                                            openSelectDialog(context,selectMedicineController,medicineList,"Medicine");
                                          },

                                        ),
                                      ),
                                    ),

                                  ],
                                ),
                                SizedBox(height: 10,),
                                const Divider(
                                  thickness: 1, // thickness of the line
                                  indent: 0, // empty space to the leading edge of divider.
                                  endIndent: 0, // empty space to the trailing edge of the divider.
                                  color: grey_10, // The color to use when painting the line.
                                  height: 2, // The divider's height extent.
                                ),
                                SizedBox(height: 10,),
                                CustomRadioButton(
                                  unSelectedBorderColor: grey_90,
                                  selectedBorderColor: PrimaryColor,
                                  height: 25,
                                  width: _width/2.4,
                                  elevation: 0,
                                  absoluteZeroSpacing: true,
                                  unSelectedColor: Colors.white,
                                  defaultSelected: strMeal,
                                  buttonLables: [
                                    'Before Meal',
                                    'After Meal',
                                  ],
                                  buttonValues: [
                                    'Before Meal',
                                    'After Meal',
                                  ],
                                  buttonTextStyle: ButtonTextStyle(
                                      selectedColor: Colors.white,
                                      unSelectedColor: grey_60,
                                      textStyle: TextStyle(fontSize: 16)),
                                  radioButtonValue: (value) {
                                    print(value);
                                    strMeal = value.toString();
                                    print("meal"+strMeal);
                                  },
                                  enableShape: true,
                                  selectedColor: PrimaryColor,
                                ),
                                SizedBox(height: 10,),
                                const Divider(
                                  thickness: 1, // thickness of the line
                                  indent: 0, // empty space to the leading edge of divider.
                                  endIndent: 0, // empty space to the trailing edge of the divider.
                                  color: grey_10, // The color to use when painting the line.
                                  height: 2, // The divider's height extent.
                                ),
                                SizedBox(height: 10,),
                                Text("Frequency"),
                                SizedBox(height: 10,),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Flexible(
                                      child: Container(
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(20),
                                            border: Border.all(color: PrimaryColor)
                                        ),
                                        child: Row(

                                          children: [
                                            InkWell(
                                              onTap:(){
                                                if(morningController.text.toString()=="1"){
                                                  morningController.text = "1/2";
                                                }else if(morningController.text.toString()=="1/2"){
                                                  morningController.text = "0";
                                                }
                                              },
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 8.0),
                                                child: Icon(Icons.remove,color: PrimaryColor,),
                                              ),
                                            ),
                                            Flexible(
                                              child: TextFormField(
                                                controller: morningController,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(fontSize: 15,),
                                                readOnly: true,
                                                decoration: InputDecoration(
                                                  isDense: true,
                                                  contentPadding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                                                  border: InputBorder.none,
                                                ),

                                              ),
                                            ),
                                            InkWell(
                                              onTap: () {
                                                if(morningController.text.toString()=="0"){
                                                  morningController.text = "1/2";
                                                }else if(morningController.text.toString()=="1/2"){
                                                  morningController.text = "1";
                                                }
                                              },
                                              child: Padding(
                                                padding: const EdgeInsets.only(right: 8),
                                                child: Icon(Icons.add,color: PrimaryColor,),
                                              ),
                                            ),

                                          ],),
                                      ),
                                    ),
                                    SizedBox(width: 5,),
                                    Flexible(
                                      child: Container(
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(20),
                                            border: Border.all(color: PrimaryColor)
                                        ),
                                        child: Row(

                                          children: [
                                            InkWell(
                                              onTap:(){
                                                if(afternoonController.text.toString()=="1"){
                                                  afternoonController.text = "1/2";
                                                }else if(afternoonController.text.toString()=="1/2"){
                                                  afternoonController.text = "0";
                                                }
                                              },
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 8.0),
                                                child: Icon(Icons.remove,color: PrimaryColor,),
                                              ),
                                            ),
                                            Flexible(
                                              child: Center(
                                                child: TextFormField(
                                                  controller: afternoonController,
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(fontSize: 15,),
                                                  readOnly: true,
                                                  decoration: InputDecoration(
                                                    isDense: true,
                                                    contentPadding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                                                    border: InputBorder.none,
                                                  ),

                                                ),
                                              ),
                                            ),
                                            InkWell(
                                              onTap: () {
                                                if(afternoonController.text.toString()=="0"){
                                                  afternoonController.text = "1/2";
                                                }else if(afternoonController.text.toString()=="1/2"){
                                                  afternoonController.text = "1";
                                                }
                                              },
                                              child: Padding(
                                                padding: const EdgeInsets.only(right: 8),
                                                child: Icon(Icons.add,color: PrimaryColor,),
                                              ),
                                            ),

                                          ],),
                                      ),
                                    ),
                                    SizedBox(width: 5,),
                                    Flexible(
                                      child: Container(
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(20),
                                            border: Border.all(color: PrimaryColor)
                                        ),
                                        child: Row(

                                          children: [
                                            InkWell(
                                              onTap:(){
                                                if(nightController.text.toString()=="1"){
                                                  nightController.text = "1/2";
                                                }else if(nightController.text.toString()=="1/2"){
                                                  nightController.text = "0";
                                                }
                                              },
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 8.0),
                                                child: Icon(Icons.remove,color: PrimaryColor,),
                                              ),
                                            ),
                                            Flexible(
                                              child: Center(
                                                child: TextFormField(
                                                  controller: nightController,
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(fontSize: 15,),
                                                  readOnly: true,
                                                  decoration: InputDecoration(
                                                    hintText: "0",
                                                    isDense: true,
                                                    contentPadding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                                                    border: InputBorder.none,
                                                  ),

                                                ),
                                              ),
                                            ),
                                            InkWell(
                                              onTap: () {
                                                if(nightController.text.toString()=="0"){
                                                  nightController.text = "1/2";
                                                }else if(nightController.text.toString()=="1/2"){
                                                  nightController.text = "1";
                                                }
                                              },
                                              child: Padding(
                                                padding: const EdgeInsets.only(right: 8),
                                                child: Icon(Icons.add,color: PrimaryColor,),
                                              ),
                                            ),

                                          ],),
                                      ),
                                    ),

                                  ],
                                ),
                                SizedBox(height: 10,),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Text("Morning"),
                                    SizedBox(width: 5,),
                                    Text("Afternoon"),
                                    SizedBox(width: 5,),
                                    Text("Night"),
                                  ],),
                                SizedBox(height: 10,),
                                Center(
                                  child: InkWell(
                                    onTap: () {
                                      if(isVisible){
                                        setState((){
                                          isVisible = false;
                                        });
                                      }else{
                                        setState((){
                                          isVisible = true;
                                        });
                                      }

                                    },
                                    child: Container(
                                      decoration: new BoxDecoration(
                                        color: PrimaryColor,
                                        border: new Border.all(color: PrimaryColor, width: 1.0),
                                        borderRadius: new BorderRadius.circular(30.0),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          const Padding(
                                            padding: EdgeInsets.only(left: 10.0,),
                                            child: Text(
                                              'Show more',
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontFamily: 'poppins_regular',
                                                fontSize: 12,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            key: UniqueKey(),
                                            child: isVisible ? new  Icon(Icons.keyboard_arrow_down ,size: 22.0,color: Colors.white,):
                                            new  Icon(Icons.keyboard_arrow_right,size: 22.0,color: Colors.white,),
                                          ),


                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                Visibility(
                                  visible: isVisible,
                                  child: Column(
                                    children: [
                                      SizedBox(height: 10,),
                                      Row(
                                          children: [
                                            Flexible(
                                              child: TextFormField(
                                                controller: withwatermilkController,
                                                style: TextStyle(fontSize: 15),
                                                readOnly: true,
                                                decoration: InputDecoration(
                                                  hintText: "Water/Milk",
                                                  suffixIcon: Icon(Icons.arrow_drop_down_outlined,color: PrimaryColor,),
                                                  border: InputBorder.none,
                                                ),
                                                onTap: (){
                                                  print("click");
                                                  openSelectDialog(context,withwatermilkController,withWaterMildList,"Medicine With");
                                                },
                                              ),
                                            ),
                                            Flexible(
                                              child: TextFormField(
                                                readOnly: true,
                                                controller: scheduleController,
                                                style: TextStyle(fontSize: 15),
                                                decoration: InputDecoration(
                                                    hintText: "Schedule",
                                                    suffixIcon: Icon(Icons.arrow_drop_down_outlined,color: PrimaryColor),
                                                    border: InputBorder.none
                                                ),
                                                onTap: (){
                                                  print("click");
                                                  openSelectDialog(context,scheduleController,scheduleList,"Medicine Schedule");
                                                },
                                              ),
                                            ),
                                          ]),
                                      const Divider(
                                        thickness: 1, // thickness of the line
                                        indent: 0, // empty space to the leading edge of divider.
                                        endIndent: 0, // empty space to the trailing edge of the divider.
                                        color: grey_10, // The color to use when painting the line.
                                        height: 2, // The divider's height extent.
                                      ),
                                      Row(
                                          children: [
                                            Flexible(
                                              child: TextFormField(
                                                controller:startDateController,
                                                style: TextStyle(fontSize: 15),
                                                readOnly: true,
                                                decoration: InputDecoration(
                                                  hintText: "Start Date",
                                                  suffixIcon: Icon(Icons.arrow_drop_down_outlined,color: PrimaryColor,),
                                                  border: InputBorder.none,
                                                ),
                                                onTap: () async {
                                                  String fromDate = await _showDatePicker(context);
                                                  //_showDatePicker(context);
                                                  startDateController.text = fromDate;
                                                  endDateController.text="";
                                                },
                                              ),
                                            ),
                                            Flexible(
                                              child: TextFormField(
                                                controller: endDateController,
                                                readOnly: true,
                                                style: TextStyle(fontSize: 15),
                                                decoration: InputDecoration(
                                                    hintText: "End Date",
                                                    suffixIcon: Icon(Icons.arrow_drop_down_outlined,color: PrimaryColor),
                                                    border: InputBorder.none
                                                ),
                                                onTap: () async {
                                                  String toDate = await _showDatePicker(context);
                                                  //_showDatePicker(context);
                                                  endDateController.text = toDate;

                                                  String fromDt = startDateController.text;
                                                  String toDt = endDateController.text;

                                                  var newFromDt = new DateFormat("dd/MM/yyyy HH:mm:ss").parse(fromDt+" 00:00:00");
                                                  var newToDt = new DateFormat("dd/MM/yyyy HH:mm:ss").parse(toDt+" 00:00:00");

                                                  var now = new DateTime.now();
                                                  var berlinWallFellDate = new DateTime.utc(1989, 11, 9);

                                                  // 0 denotes being equal positive value greater and negative value being less
                                                  if(newToDt.compareTo(newFromDt)>=0) {
                                                    var t = true;

                                                    var difference = newToDt.difference(newFromDt).inDays;
                                                    difference = difference+1;
                                                    print(difference);
                                                    //dayController.text = difference.toString();

                                                    //strday = difference;
                                                  }else {
                                                    var t = false;

                                                    endDateController.text="";
                                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                      backgroundColor: Colors.red[500],
                                                      content: Text("End date must be greater than Start date"),
                                                    ));
                                                  }
                                                },
                                              ),
                                            ),
                                          ]),
                                      const Divider(
                                        thickness: 1, // thickness of the line
                                        indent: 0, // empty space to the leading edge of divider.
                                        endIndent: 0, // empty space to the trailing edge of the divider.
                                        color: grey_10, // The color to use when painting the line.
                                        height: 2, // The divider's height extent.
                                      ),
                                      SizedBox(height: 10,),
                                      TextFormField(
                                        minLines: 1,
                                        maxLines: 5,
                                        controller: specialController,
                                        keyboardType: TextInputType.multiline,
                                        decoration: InputDecoration(
                                            labelText: 'Special Remark',
                                            labelStyle: TextStyle(
                                                color: PrimaryColor
                                            ),
                                            focusedBorder: OutlineInputBorder(
                                              borderSide: BorderSide(color: grey_60,width: 1),
                                              borderRadius: BorderRadius.circular(10),
                                            ),
                                            enabledBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(10),
                                                borderSide: BorderSide(
                                                    color: grey_20

                                                )
                                            ),
                                        ),
                                        onChanged: (value){
                                          strSpecialRemark = value;
                                        },
                                      ),
                                    ],),
                                ),

                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      /*bottomNavigationBar: isKeyboardOpen?null: Container(
        child: InkWell(
          onTap: () {
            setState(() {
             // onNextPageChangeTapped();
            });
          },
          child: Container(
            height: 50,
            decoration: BoxDecoration(
                color: PrimaryColor,
                borderRadius: BorderRadius.circular(30)
            ),
            child: Center(child: Text("Next",style: TextStyle(color: Colors.white,fontSize: 25,fontWeight: FontWeight.bold),)),
          ),
        ),
      ),*/
    );





  }
  Future checkValidation() async{


    if(selectMedicineController.text.toString()!=null && selectMedicineController.text.toString().length>0 ){
      if(morningController.text.toString()!=null && morningController.text.toString()!="0"
      || afternoonController.text.toString()!=null && afternoonController.text.toString()!="0"
      || nightController.text.toString()!=null && nightController.text.toString()!="0"){

        if(startDateController.text.toString()!=null && startDateController.text.toString().length>0 ){
          if(endDateController.text.toString()!=null && endDateController.text.toString().length>0 ){
            saveMedicine();
          }else{
            Fluttertoast.showToast(msg: "Select end date.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
          }
        }else if(endDateController.text.toString()!=null && endDateController.text.toString().length>0 ){
          if(startDateController.text.toString()!=null && startDateController.text.toString().length>0 ){
            saveMedicine();
          }else{
            Fluttertoast.showToast(msg: "Select start date.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
          }
        }else{
          saveMedicine();
        }
      }else{
        Fluttertoast.showToast(msg: "Select frequency.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
      }
    }else{
      Fluttertoast.showToast(msg: "Select medicine.",textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.BOTTOM);
    }

  }
  Future saveMedicine() async{


      setState((){
        _isLoading = true;
      });

      Map data = {
        'customer_id' :  customerId.toString(),
        'user_id' :  userId.toString(),
        'con_id' :  conId,
        'med_Id' :  medicineId,
        'med_name' :  medicineName,
        'med_qty' :  "",
        'onm' :  morningController.text.toString(),
        'ona' :  afternoonController.text.toString(),
        'onn' :  nightController.text.toString(),
        'b_or_a' :  strMeal,
        'med_with' :  withMeal,
        'med_sch' :  schedule,
        'sd' :  startDateController.text.toString(),
        'ed' :  endDateController.text.toString(),
        'remark' :  strSpecialRemark.toString(),
      };

      await Future.wait([
        http.post(Uri.parse(BASE_URL+"MobileApp/SaveMediNoteConsultantMedData"),body: data)
      ]).then((response){

        var jasonData = null;
        setState((){
          _isLoading = false;
        });
        if(response[0].statusCode==200){
          jasonData = jsonDecode(response[0].body);
          var map = Map<String,dynamic>.from(jasonData);
          var response1 = ConsultantMainDataResponse.fromJson(map);

          if(response1.settings.success=="1"){
            setState((){
              _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));

              //Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=>ListPatientActivity()));
              Navigator.pop(context,true);
            });
          }else{
            setState((){
              _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message, style: TextStyle(fontFamily: "poppins_regular",fontSize: 14))));
            });
          }
        }else{
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Something went wrong please try again later.")));

        }


      }, onError: (error) {
        setState(() {
          _isLoading = false;
        });
        Fluttertoast.showToast(
            msg: error.toString(),
            textColor: Colors.white,
            backgroundColor: Colors.red,
            gravity: ToastGravity.CENTER);
      });
    }
  Future openSelectDialog(BuildContext context, TextEditingController controller, List<EmployeeTypeHelper> dataList, String idtfDialog) async {

    if(idtfDialog=="Medicine"){
      showDialog(
          context: context,
          builder: (BuildContext context) => CustomAlertSelectionDialog(
            idtfDialog: idtfDialog,
            selectedId: "1",
            selectionList: medicineList,
            doneTitle: "Done",
            cancelTitle: "Cancel",
            position: "1",
            onClick: onSelectionClick,
            onCancel: onSelectionCancel,
            rowClickPos: 0,
            relationController:controller,));

    } else if(idtfDialog=="Medicine With"){
      showDialog(
          context: context,
          builder: (BuildContext context) => CustomAlertSelectionDialog(
            idtfDialog: idtfDialog,
            selectedId: "1",
            selectionList: withWaterMildList,
            doneTitle: "Done",
            cancelTitle: "Cancel",
            position: "1",
            onClick: onSelectionClick,
            onCancel: onSelectionCancel,
            rowClickPos: 0,
            relationController:controller,));
    }else if(idtfDialog=="Medicine Schedule"){
      showDialog(
          context: context,
          builder: (BuildContext context) => CustomAlertSelectionDialog(
            idtfDialog: idtfDialog,
            selectedId: "1",
            selectionList: scheduleList,
            doneTitle: "Done",
            cancelTitle: "Cancel",
            position: "1",
            onClick: onSelectionClick,
            onCancel: onSelectionCancel,
            rowClickPos: 0,
            relationController:controller,));
    }

  }

  onSelectionClick(
      String idtfDialog,
      String selectedId,
      String selectionName,
      String position,
      int rowClickPos,
      TextEditingController controller,
      String extraStr) {

    print("extraStr :"+extraStr);

    if(idtfDialog=="Medicine"){
      controller.text = selectionName;
      print(selectedId);
      print(selectionName);
      //Navigator.pop(context);
      medicineId = selectedId;
      medicineName = selectionName;
      print("medicine Id.."+medicineId);
      print("extraStr :"+extraStr);

      String strMedicine = extraStr;

      if(strMedicine=="Capsule"){
        print(strMedicine);
        setState((){
          strMedicineImage = 'images/ic_capsule__off.png';
        });
      }else if(strMedicine=="Tablet"){
        print(strMedicine);
        setState((){
          strMedicineImage = 'images/ic_tablet_onn.png';
        });
      }else if(strMedicine=="ML (Syrup)"){
        print(strMedicine);
        setState((){
          strMedicineImage = 'images/ic_syrup_off.png';
        });
      }else if(strMedicine=="Others"){
        print(strMedicine);
        setState((){
          strMedicineImage = 'images/ic_other_medicine_off.png';
        });

      }
    }else if(idtfDialog=="Medicine With"){

      controller.text = selectionName;
      print(selectedId);
      print(selectionName);
      //Navigator.pop(context);
      withMeal = selectionName;
      print("medicine withMeal.."+withMeal);
      print("extraStr :"+extraStr);

    }else if(idtfDialog=="Medicine Schedule"){

      controller.text = selectionName;
      print(selectedId);
      print(selectionName);
      //Navigator.pop(context);
      schedule = selectionName;
      print("medicine schedule.."+schedule);
      print("extraStr :"+extraStr);

    }






  }

  onSelectionCancel(String p1) {
  }
}

Future<String> _showDatePicker(BuildContext context)async{
  final DateTime? picked=await showDatePicker(
      context: context, initialDate: DateTime.now(),
      firstDate: DateTime(2015, 8),
      lastDate: DateTime(2101));
  if(picked != null)
  {
    return DateFormat("dd/MM/yyyy").format(picked);
  }
  return "";
}

