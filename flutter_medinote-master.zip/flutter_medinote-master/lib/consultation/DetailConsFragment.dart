
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_medinote/response/DiseaseListingResponse.dart';
import 'package:flutter_medinote/response/DoctorListingResponse.dart';
import 'package:flutter_medinote/response/PatientListingResponse.dart';
import 'package:flutter_medinote/utils/AppColors.dart';
import 'package:flutter_medinote/utils/VariableBag.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:loading_overlay/loading_overlay.dart';
import '../response/ConsultantMainDataResponse.dart';
import '../utils/CustomAlertSelectionDialog.dart';
import '../utils/EmployeeTypeHelper.dart';
import '../utils/GetEditTextValueHelper.dart';
import '../utils/PreferenceManager.dart';

class DetailConsFragment extends StatefulWidget {

  final TabController _tabController;

  const DetailConsFragment(this._tabController, {Key? key}) : super(key: key);

  @override
  State<DetailConsFragment> createState() => _DetailConsFragmentState(_tabController);
}

class _DetailConsFragmentState extends State<DetailConsFragment> {

  late ScaffoldMessengerState _scaffoldMessengerState;

  TextEditingController _patientController = TextEditingController();
  TextEditingController _diseaseController = TextEditingController();
  TextEditingController _doctoreController = TextEditingController();
  TextEditingController _dateController = TextEditingController();
  TextEditingController _timeController = TextEditingController();
  var strPatient,strPatientId,strDisease,strDiseaseId,strDoctor,strDoctorId,strSymptoms="",conId;

  final _formkey = GlobalKey<FormState>();
  final _tabController;
  List<EmployeeTypeHelper> patientList = [];
  List<EmployeeTypeHelper> diseaseList = [];
  List<EmployeeTypeHelper> doctorList = [];
  List<GetEditTextValueHelper> arrayList = <GetEditTextValueHelper>[];
  String today1="",todayTime1="";
  var userId,customerId="";
  var _isLoading = false;

  _DetailConsFragmentState(this._tabController);


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    PreferenceManager.instance.getStringValue("userId").then((value) => setState(() {
      userId = value;
      getPatientList();
      getDiseaseList();
      getDoctorList();
      print("User Id = "+userId.toString());

    }));
    DateTime today = DateTime.now();

    today1 = "${today.day}/${today.month}/${today.year}";
    todayTime1 = "${today.hour}:${today.minute}";

    print("init - "+today1);

  }

  Future getPatientList() async {

    Map data = {
      'customer_id' : customerId,
      'user_id' : userId,
      'filtertext' : "",
      'Select_Valuecode' : ""
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/PatientListing"),body: data)
      ]).then((response) {
        var jsonData = null;

        if(response[0].statusCode==200){
          jsonData = jsonDecode(response[0].body);
          var map = Map<String,dynamic>.from(jsonData);
          var response1 = PatientListingResponse.fromJson(map);

          if(response1.settings.success=="1"){
            for(int i =0; i<response1.data.length; i++) {
              patientList.add(EmployeeTypeHelper(response1.data[i].patientName, response1.data[i].patientId, "", false,""));
            }
          }
        }else{
          print("status code wrong");
        }
    },onError: (error){

      setState(() {
        _isLoading = false;
      });
      Fluttertoast.showToast(
          msg: error.toString(), textColor: Colors.white,
          backgroundColor: Colors.red, gravity: ToastGravity.CENTER);

    });
  }
  Future getDiseaseList() async {

    Map data = {
      'customer_id' : customerId,
      'user_id' : userId,
      'filtertext' : "",
      'Select_Valuecode' : ""
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/DiseaseListing"),body: data)
      ]).then((response) {
        var jsonData = null;

        if(response[0].statusCode==200){
          jsonData = jsonDecode(response[0].body);
          var map = Map<String,dynamic>.from(jsonData);
          var response1 = DiseaseListingResponse.fromJson(map);

          if(response1.settings.success=="1"){
            for(int i =0; i<response1.data.length; i++) {
              diseaseList.add(EmployeeTypeHelper(response1.data[i].diseaseName, response1.data[i].diseaseId, "", false,""));
            }
          }
        }else{
          print("status code wrong");
        }
    },onError: (error){

    });
  }
  Future getDoctorList() async {

    Map data = {
      'customer_id' : customerId,
      'user_id' : userId,
      'filtertext' : "",
      'Select_Valuecode' : ""
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/DoctorListing"),body: data)
      ]).then((response) {
        var jsonData = null;

        if(response[0].statusCode==200){
          jsonData = jsonDecode(response[0].body);
          var map = Map<String,dynamic>.from(jsonData);
          var response1 = DoctorListingResponse.fromJson(map);

          if(response1.settings.success=="1"){
            for(int i =0; i<response1.data.length; i++) {
              doctorList.add(EmployeeTypeHelper(response1.data[i].doctorName, response1.data[i].doctorId, "", false,""));
            }
          }
        }else{
          print("status code wrong");
        }
    },onError: (error){

    });
  }


  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    bool isKeyboardOpen = MediaQuery.of(context).viewInsets.bottom != 0.0;

    _scaffoldMessengerState = ScaffoldMessenger.of(context);


    _dateController.text=today1;
    _timeController.text=todayTime1;
    return Scaffold(
      resizeToAvoidBottomInset : false,
      backgroundColor: grey_5,
      body: LoadingOverlay(
        isLoading: _isLoading,
        color: Colors.black54,
        opacity: 0.6,
        child: Padding(
          padding: const EdgeInsets.only(top: 8.0,bottom: 8),
          child: Container(
            width: width,
            height: height,
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Card(
                        elevation: 3,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                width: 120,
                                height: 30,
                                padding: const EdgeInsets.all(3),
                                decoration: const BoxDecoration(
                                  //color: grey_20,
                                    border: Border(
                                      top: BorderSide(color: Colors.grey, width: 1),
                                      left: BorderSide(color: Colors.grey, width: 1),
                                      right: BorderSide(color: Colors.grey, width: 1),
                                      bottom: BorderSide(color: Colors.grey, width: 1),
                                    ),
                                    borderRadius: BorderRadius.all(Radius.circular(10))

                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                        child: Icon(size: 20, Icons.calendar_month_outlined,color: PrimaryColor,)
                                    ),
                                    //Text("15/12/2022",style: TextStyle(color: PrimaryColor),),
                                    Flexible(
                                      child: TextFormField(
                                        readOnly: true,
                                        controller: _dateController,
                                        style: const TextStyle(color: PrimaryColor),
                                        decoration: const InputDecoration(
                                          border: InputBorder.none,
                                          contentPadding: EdgeInsets.symmetric(vertical: 11,)
                                        ),
                                        onTap: ()async{
                                          String toDate = await _showDatePicker(context);
                                          //_showDatePicker(context);
                                          print(toDate);
                                          _dateController.text = toDate;
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                width: 71,
                                height: 30,
                                padding: const EdgeInsets.all(3),
                                decoration: const BoxDecoration(
                                  //color: grey_20,
                                    border: Border(
                                      top: BorderSide(color: Colors.grey, width: 1),
                                      left: BorderSide(color: Colors.grey, width: 1),
                                      right: BorderSide(color: Colors.grey, width: 1),
                                      bottom: BorderSide(color: Colors.grey, width: 1),
                                    ),
                                    borderRadius: BorderRadius.all(Radius.circular(10))

                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(child: Icon(
                                      size: 20,
                                      Icons.access_time_outlined,color: PrimaryColor,)),
                                    //Text("12:13",style: TextStyle(color: PrimaryColor),
                                    // ),
                                    Flexible(
                                      child: TextFormField(
                                        readOnly: true,
                                        controller: _timeController,
                                        style: TextStyle(color: PrimaryColor),
                                        decoration: InputDecoration(
                                          border: InputBorder.none,
                                            contentPadding: EdgeInsets.symmetric(vertical: 11,)
                                        ),
                                        onTap: () async{

                                          TimeOfDay? pickedTime =  await showTimePicker(
                                            initialTime: TimeOfDay.now(),
                                            context: context, //context of current state
                                          );

                                          if(pickedTime != null ){
                                            print(pickedTime.format(context));   //output 10:51 PM
                                            DateTime parsedTime = DateFormat.jm().parse(pickedTime.format(context).toString());
                                            //converting to DateTime so that we can further format on different pattern.
                                            print(parsedTime); //output 1970-01-01 22:53:00.000
                                            String formattedTime = DateFormat('HH:mm').format(parsedTime);
                                            print(formattedTime); //output 14:59:00
                                            //DateFormat() is from intl package, you can format the time on any pattern you need.
                                            _timeController.text = formattedTime;
                                          }else{
                                            print("Time is not selected");
                                          }
                                        },
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        child: SingleChildScrollView(
                          child: Padding(
                            padding: const EdgeInsets.all(10),
                            child: Form(
                              key: _formkey,
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [

                                  //patient
                                  TextFormField(
                                    readOnly: true,
                                    controller: _patientController,
                                    decoration: const InputDecoration(
                                        labelText: "Patient*",
                                        labelStyle: TextStyle(
                                            color: PrimaryColor
                                        ),
                                        enabledBorder: UnderlineInputBorder(
                                          borderSide: BorderSide(color: grey_20),
                                        ),
                                        focusedBorder: UnderlineInputBorder(
                                          borderSide: BorderSide(color: PrimaryColor),
                                        ),
                                        suffixIcon: Icon(Icons.search,color: PrimaryColor,)
                                    ),
                                    validator: (value){
                                      strPatient = value;
                                      if(strPatient==null || strPatient.isEmpty){
                                        return 'Select patient.';
                                      }return null;
                                    },
                                    onTap: (){
                                      print("click");
                                      openSelectDialog(context,_patientController,patientList,"Patient");
                                    },
                                  ),
                                  //disease
                                  TextFormField(
                                    readOnly: true,
                                    controller: _diseaseController,
                                    decoration: InputDecoration(
                                        labelText: "Disease*",
                                        labelStyle: TextStyle(
                                            color: PrimaryColor
                                        ),
                                        enabledBorder: UnderlineInputBorder(
                                          borderSide: BorderSide(color: grey_20),
                                        ),
                                        focusedBorder: UnderlineInputBorder(
                                          borderSide: BorderSide(color: PrimaryColor),
                                        ),
                                        suffixIcon: Icon(Icons.search,color: PrimaryColor,)
                                    ),
                                    validator: (value){
                                      strDisease = value;
                                      if(strDisease==null || strDisease.isEmpty){
                                        return 'Select disease.';
                                      }return null;
                                    },
                                    onTap: (){
                                      print("click");
                                      openSelectDialog(context,_diseaseController,diseaseList,"Disease");
                                    },
                                  ),
                                  //doctor
                                  TextFormField(
                                    readOnly: true,
                                    controller: _doctoreController,
                                    decoration: InputDecoration(
                                        labelText: "Doctor*",
                                        labelStyle: TextStyle(
                                            color: PrimaryColor
                                        ),
                                        enabledBorder: UnderlineInputBorder(
                                          borderSide: BorderSide(color: grey_20),
                                        ),
                                        focusedBorder: UnderlineInputBorder(
                                          borderSide: BorderSide(color: PrimaryColor),
                                        ),
                                        suffixIcon: Icon(Icons.search,color: PrimaryColor,)
                                    ),
                                    validator: (value){
                                      strDoctor = value;
                                      if(strDoctor==null || strDoctor.isEmpty){
                                        return 'Select doctor.';
                                      }return null;
                                    },
                                    onTap: (){
                                      print("click");
                                      openSelectDialog(context,_doctoreController,doctorList,"Doctor");
                                    },
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 15.0),
                                    child: TextFormField(
                                      minLines: 2,
                                      maxLines: 5,
                                      keyboardType: TextInputType.multiline,
                                      decoration: InputDecoration(
                                          labelText: 'Symptoms',
                                          labelStyle: TextStyle(color: PrimaryColor),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(color: grey_60,width: 1),
                                            borderRadius: BorderRadius.circular(10),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.circular(10),
                                              borderSide: BorderSide(color: grey_20)
                                          )


                                      ),
                                      onChanged: (value){
                                        strSymptoms = value;
                                      },
                                    ),
                                  ),

                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: isKeyboardOpen?null: Container(
        child: InkWell(
          onTap: () {
            setState(() {
              onNextPageChangeTapped();
            });
          },
          child: Container(
            height: 50,
            decoration: BoxDecoration(
              color: PrimaryColor,
              borderRadius: BorderRadius.circular(30)
            ),
            child: Center(child: Text("Next",style: TextStyle(color: Colors.white,fontSize: 25,fontWeight: FontWeight.bold),)),
          ),
        ),
      ),
    );
  }

  void onNextPageChangeTapped() {
    //_tabController.animateTo((_tabController.index + 1) % 4);
    if(_formkey.currentState!.validate()){
      saveDetailFirstPageData();
    }
  }

  Future saveDetailFirstPageData() async {

    var  date = _dateController.text.toString();
    var  time = _timeController.text.toString();

    print("save date : "+date);
    print("save time : "+time);
    setState((){
      _isLoading = true;
    });

    Map data ={
      'customer_id':customerId,
      'con_id':"",
      'user_id':userId,
      'sym_name':strSymptoms,
      'dis_Id':strDiseaseId,
      'dis_name':strDisease,
      'patient_Id':strPatientId,
      'patient_name':strPatient,
      'dr_Id':strDoctorId,
      'dr_name':strDoctor,
      'date':date,
      'time':time,
    };

    await Future.wait([
      http.post(Uri.parse(BASE_URL+"MobileApp/SaveMediNoteConsultantMainData"),body: data)
    ]).then((response){

      var jsonData = null;

      setState((){
        _isLoading = false;
      });

      if(response[0].statusCode==200){
        jsonData = jsonDecode(response[0].body);
        var map = Map<String,dynamic>.from(jsonData);
        var response1 = ConsultantMainDataResponse.fromJson(map);

        if(response1.settings.success=="1"){
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message)));

          print("Click");
          //_pageController.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.bounceOut);
          _tabController.animateTo((_tabController.index + 1) % 4); // Switch tabs
          conId = response1.data[0].conId.toString();
          PreferenceManager.instance.setStringValue("conId", conId);
          print("cons Id = "+conId.toString());
        }else{
          _scaffoldMessengerState.showSnackBar(SnackBar(content: Text(response1.settings.message)));
        }
      }else{
        _scaffoldMessengerState.showSnackBar(SnackBar(content: Text("Something went wrong please try again later.")));

      }

    },onError: (error){
      setState((){
        _isLoading = false;
        Fluttertoast.showToast(msg: error.toString(),textColor: Colors.white,backgroundColor: Colors.red,gravity: ToastGravity.CENTER);
      });
    });



  }

  Future openSelectDialog(BuildContext context, TextEditingController controller, List<EmployeeTypeHelper> dataList, String idtfDialog) async {

    if(idtfDialog=="Patient"){
      showDialog(
          context: context,
          builder: (BuildContext context) => CustomAlertSelectionDialog(
            idtfDialog: idtfDialog,
            selectedId: "1",
            selectionList: patientList,
            doneTitle: "Done",
            cancelTitle: "Cancel",
            position: "1",
            onClick: onSelectionClick,
            onCancel: onSelectionCancel,
            rowClickPos: 0,
            relationController:controller,));
    }else if(idtfDialog=="Disease"){
      showDialog(
          context: context,
          builder: (BuildContext context) => CustomAlertSelectionDialog(
            idtfDialog: idtfDialog,
            selectedId: "1",
            selectionList: diseaseList,
            doneTitle: "Done",
            cancelTitle: "Cancel",
            position: "1",
            onClick: onSelectionClick,
            onCancel: onSelectionCancel,
            rowClickPos: 0,
            relationController:controller,));
    }else if(idtfDialog=="Doctor"){
      showDialog(
          context: context,
          builder: (BuildContext context) => CustomAlertSelectionDialog(
            idtfDialog: idtfDialog,
            selectedId: "1",
            selectionList: doctorList,
            doneTitle: "Done",
            cancelTitle: "Cancel",
            position: "1",
            onClick: onSelectionClick,
            onCancel: onSelectionCancel,
            rowClickPos: 0,
            relationController:controller,));
    }

  }

  onSelectionClick(
      String idtfDialog,
      String selectedId,
      String selectionName,
      String position,
      int rowClickPos,
      TextEditingController controller,
      String extraStr) {

    if(idtfDialog=="Patient"){
      controller.text = selectionName;
      print(selectedId);
      print(selectionName);
     // Navigator.pop(context, arrayList);
      strPatientId = selectedId;
      print("patient Id.."+strPatientId);

    }else if(idtfDialog=="Disease"){
      controller.text = selectionName;
      print(selectedId);
      print(selectionName);
      //Navigator.pop(context, arrayList);
      strDiseaseId = selectedId;
      print("diseaseId.."+strDiseaseId);
    }else if(idtfDialog=="Doctor"){
      controller.text = selectionName;
      print(selectedId);
      print(selectionName);
      //Navigator.pop(context, arrayList);
      strDoctorId = selectedId;
      print("doctorId.."+strDoctorId,);
    }





  }

  onSelectionCancel(String p1) {
  }

  Future<String> _showDatePicker(BuildContext context)async{
    final DateTime? picked=await showDatePicker(
        context: context, initialDate: DateTime.now(),
        firstDate: DateTime(2015, 8),
        lastDate: DateTime(2101));
    if(picked != null)
    {
      return DateFormat("dd/MM/yyyy").format(picked);
    }
    return today1;
  }

}
